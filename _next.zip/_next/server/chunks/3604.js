"use strict";
exports.id = 3604;
exports.ids = [3604];
exports.modules = {

/***/ 9611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AL": () => (/* binding */ addNote),
/* harmony export */   "Ti": () => (/* binding */ addToOrderAddress),
/* harmony export */   "ZG": () => (/* binding */ addShowData),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "bn": () => (/* binding */ clearOrder),
/* harmony export */   "co": () => (/* binding */ removeDeliveryDate),
/* harmony export */   "gU": () => (/* binding */ addCoupon),
/* harmony export */   "pZ": () => (/* binding */ addToOrder),
/* harmony export */   "wm": () => (/* binding */ addDataToOrder)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    data: {},
    shops: [],
    showData: [],
    coupon: {}
};
const orderProduct = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "order",
    initialState,
    reducers: {
        addDataToOrder (state, action) {
            state.data = action.payload;
        },
        addToOrderAddress (state, action) {
            state.shops.forEach((item)=>{
                item.delivery_address_id = action.payload.delivery_address_id;
            });
        },
        addToOrder (state, action) {
            const index = state.shops.findIndex((item)=>item.shop_id === action.payload.shop_id);
            if (index >= 0) {
                state.shops[index] = {
                    ...state.shops[index],
                    ...action.payload
                };
            } else {
                state.shops.push(action.payload);
            }
        },
        removeDeliveryDate (state, action) {
            const index = state.shops.findIndex((item)=>item.shop_id === action.payload);
            if (index >= 0) {
                state.shops[index].delivery_date = null;
            }
        },
        addNote (state, action) {
            state.data.note = action.payload;
        },
        addCoupon (state, action) {
            state.coupon = action.payload;
        },
        addShowData (state, action) {
            const index = state.showData.findIndex((item)=>item.shop_id === action.payload.shop_id);
            if (index >= 0) {
                state.showData[index] = action.payload;
            } else {
                state.showData.push(action.payload);
            }
        },
        clearOrder (state, action) {
            state.data = {};
            state.shops = [];
            state.showData = [];
            state.coupon = {};
        }
    }
});
const { addToOrder , addShowData , addDataToOrder , clearOrder , addToOrderAddress , addNote , addCoupon , removeDeliveryDate ,  } = orderProduct.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (orderProduct.reducer);


/***/ }),

/***/ 4982:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RH": () => (/* binding */ clearAddress),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports addToSaved, removeFromSaved */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    savedAddressList: []
};
const savedAddressSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "savedAddress",
    initialState,
    reducers: {
        addToSaved (store, action) {
            const existingIndex = store.savedAddressList.findIndex((item)=>item.id === action.payload.id);
            if (existingIndex >= 0) {
                store.savedAddressList[existingIndex] = {
                    ...action.payload
                };
            } else {
                store.savedAddressList.push({
                    ...action.payload
                });
            }
        },
        removeFromSaved (store, action) {
            store.savedAddressList.map((address)=>{
                if (address.id === action.payload.id) {
                    const nextAddressItems = store.savedAddressList.filter((item)=>item.id !== address.id);
                    store.savedAddressList = nextAddressItems;
                }
                return store;
            });
        },
        clearAddress (state) {
            state.savedAddressList = [];
        }
    }
});
const { addToSaved , removeFromSaved , clearAddress  } = savedAddressSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (savedAddressSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;