"use strict";
exports.id = 1497;
exports.ids = [1497];
exports.modules = {

/***/ 1497:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_EyeOffLineIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7008);
/* harmony import */ var remixicon_react_EyeOffLineIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_EyeOffLineIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2394);
/* harmony import */ var remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);





const InputPassword = ({ label ="" , placeholder ="" , onChange =()=>{} , name ="" , value , onBlur , className ="" ,  })=>{
    const { 0: inputType , 1: setInputType  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const handleClick = ()=>{
        setInputType(!inputType);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `form-item ${className}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "label",
                children: tl(label)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                id: "password",
                name: name,
                onChange: (e)=>onChange(e),
                type: inputType ? "password" : "text",
                placeholder: tl(placeholder),
                value: value,
                onBlur: onBlur,
                autoComplete: "new-password"
            }),
            inputType ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_EyeOffLineIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                size: 20,
                className: "suffix",
                onClick: handleClick
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                size: 20,
                className: "suffix",
                onClick: handleClick
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputPassword);


/***/ })

};
;