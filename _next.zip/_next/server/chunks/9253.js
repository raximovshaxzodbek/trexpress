"use strict";
exports.id = 9253;
exports.ids = [9253];
exports.modules = {

/***/ 9253:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3006);
/* harmony import */ var remixicon_react_Filter3LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2595);
/* harmony import */ var remixicon_react_Filter3LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Filter3LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6982);
/* harmony import */ var remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _search_filter_vertical__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4131);
/* harmony import */ var _drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7671);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8942);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_drawer__WEBPACK_IMPORTED_MODULE_7__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_8__]);
([_drawer__WEBPACK_IMPORTED_MODULE_7__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ProductSection = ({ children , title ="" , href =null , icon , sort =false , filter =false , total =0 , brandList , className ="" ,  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { layout , setLayout , setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_8__/* .MainContext */ .T);
    const click = ()=>{
        setOpen(true);
        setDrawerTitle("Filter");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "product-section",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "section-header",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "title",
                        children: [
                            icon && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "icon",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_constants_images__WEBPACK_IMPORTED_MODULE_3__/* .DiscountIcon */ .R8, {})
                            }),
                            tl(title)
                        ]
                    }),
                    href && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: href,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            className: "see-all",
                            children: tl("See all")
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `section-content-wrapper ${className}`,
                children: [
                    filter && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_search_filter_vertical__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        brandList: brandList
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "container-full",
                        children: [
                            sort && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "sort-header",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "total-count",
                                        children: `${total} ${tl("products")}`
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "sort-box",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "filter-mobile",
                                                onClick: click,
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Filter3LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        size: 16
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                        children: tl("Filter")
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "all-products-sort",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(antd__WEBPACK_IMPORTED_MODULE_10__.Select, {
                                                    defaultValue: "Sort by",
                                                    options: [
                                                        {
                                                            value: "described",
                                                            label: "Described"
                                                        },
                                                        {
                                                            value: "lowerPrice",
                                                            label: "Lower price"
                                                        },
                                                        {
                                                            value: "The highest price",
                                                            label: "The highest price"
                                                        },
                                                        {
                                                            value: "The newest",
                                                            label: "The newest"
                                                        },
                                                        {
                                                            value: "Most sold",
                                                            label: "Most sold"
                                                        },
                                                        {
                                                            value: "Highest rated",
                                                            label: "Highest rated"
                                                        }, 
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "section-content",
                                children: children
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_drawer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                header: true,
                open: open,
                setOpen: setOpen,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_search_filter_vertical__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    brandList: brandList,
                    className: "mobile-filter"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductSection);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ vertical)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/accordion/index.js
var accordion = __webpack_require__(7952);
// EXTERNAL MODULE: ./components/accordion/accordion-details.js
var accordion_details = __webpack_require__(4021);
// EXTERNAL MODULE: ./components/accordion/accordion-summary.js
var accordion_summary = __webpack_require__(6694);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/loader/category.js
var loader_category = __webpack_require__(9919);
;// CONCATENATED MODULE: ./components/search-filter/vertical/by-category.js







const ByCategory = ({ category , handleFilter  })=>{
    const router = (0,router_.useRouter)();
    const { 0: idList , 1: setIdList  } = (0,external_react_.useState)([]);
    const { 0: subIdList , 1: setSubIdList  } = (0,external_react_.useState)([]);
    const currentCategory = category.flatMap((item)=>item.children);
    const x = currentCategory.find((item)=>item.id == router.query.category_id);
    const px = currentCategory.find((item)=>item.parent_id == router.query.category_id);
    const y = {};
    const a = {};
    if (x || px) {
        if (x) {
            y = category.find((item)=>item.id == x?.parent_id);
        } else {
            y = category.find((item)=>item.id == px?.parent_id);
        }
    } else {
        const nextCategory = currentCategory.flatMap((item)=>item.children);
        a = nextCategory.find((item)=>item?.id == router.query.category_id);
        y = currentCategory.find((item)=>item.id == a?.parent_id);
    }
    const handleClick = (key)=>{
        const includes = idList.includes(key);
        if (includes) {
            setIdList(idList.filter((item)=>item !== key));
        } else {
            setIdList([
                ...idList,
                key
            ]);
        }
    };
    const handleSubClick = (key)=>{
        const includes = subIdList.includes(key);
        if (includes) {
            setSubIdList(subIdList.filter((item)=>item !== key));
        } else {
            setSubIdList([
                ...subIdList,
                key
            ]);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: category.length === 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(loader_category/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
            className: "by-category",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* default */.Z, {
                idList: idList,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_summary/* default */.Z, {
                        handleFilter: handleFilter,
                        handleClick: handleClick,
                        idList: idList,
                        y: y,
                        children: y?.translation?.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_details/* default */.Z, {
                        children: y?.children?.map((child, key)=>{
                            if (child?.children?.length) {
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* default */.Z, {
                                    idList: subIdList,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_summary/* default */.Z, {
                                            handleFilter: handleFilter,
                                            handleClick: handleSubClick,
                                            idList: subIdList,
                                            y: child,
                                            children: child?.translation?.title
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_details/* default */.Z, {
                                            children: child?.children?.map((child, key)=>{
                                                return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                                    className: router?.query?.category_id == child.id ? "item selected" : "item",
                                                    onClick: ()=>handleFilter({
                                                            category_id: child.id
                                                        }),
                                                    children: child.translation?.title
                                                }, key);
                                            })
                                        })
                                    ]
                                });
                            } else return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: router?.query?.category_id == child.id ? "item selected" : "item",
                                onClick: ()=>handleFilter({
                                        category_id: child.id
                                    }),
                                children: child.translation?.title
                            }, key);
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const by_category = (ByCategory);

// EXTERNAL MODULE: external "remixicon-react/CheckboxBlankLineIcon"
var CheckboxBlankLineIcon_ = __webpack_require__(97);
var CheckboxBlankLineIcon_default = /*#__PURE__*/__webpack_require__.n(CheckboxBlankLineIcon_);
// EXTERNAL MODULE: external "remixicon-react/CheckboxFillIcon"
var CheckboxFillIcon_ = __webpack_require__(266);
var CheckboxFillIcon_default = /*#__PURE__*/__webpack_require__.n(CheckboxFillIcon_);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./components/search-filter/vertical/by-brand.js







const ByBrand = ({ brandList , handleFilter  })=>{
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const router = (0,router_.useRouter)();
    const brand_id = router?.query?.brand_id;
    const { 0: count , 1: setCount  } = (0,external_react_.useState)(10);
    const loadMore = ()=>{
        setCount((prev)=>prev + 10);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: !brandList?.length ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(loader_category/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "by-brand",
            children: [
                brandList?.slice(0, count)?.map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "item",
                        onClick: ()=>handleFilter({
                                brand_id: item.id
                            }),
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "name",
                            children: [
                                brand_id == item.id ? /*#__PURE__*/ (0,jsx_runtime_.jsx)((CheckboxFillIcon_default()), {}) : /*#__PURE__*/ (0,jsx_runtime_.jsx)((CheckboxBlankLineIcon_default()), {}),
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                                    children: item.title
                                })
                            ]
                        })
                    }, item.uuid);
                }),
                brandList?.length > 10 && /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "load-more",
                    onClick: loadMore,
                    children: tl("Load more")
                })
            ]
        })
    });
};
/* harmony default export */ const by_brand = (ByBrand);

// EXTERNAL MODULE: external "rc-slider"
var external_rc_slider_ = __webpack_require__(1817);
var external_rc_slider_default = /*#__PURE__*/__webpack_require__.n(external_rc_slider_);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__(3053);
// EXTERNAL MODULE: ./utils/hooks/useDebounce.js
var useDebounce = __webpack_require__(5053);
;// CONCATENATED MODULE: ./components/search-filter/vertical/by-price.js






const ByPrice = ({ handleFilter  })=>{
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const cookies = (0,external_nookies_.parseCookies)();
    const currency_rate = cookies?.currency_rate;
    const currency_symbol = cookies?.currency_symbol;
    const { 0: range , 1: setRange  } = (0,external_react_.useState)(null);
    const { 0: sort , 1: setSort  } = (0,external_react_.useState)(null);
    const { 0: showRange , 1: setShowRange  } = (0,external_react_.useState)([
        0,
        100000 * currency_rate
    ]);
    const debouncedRange = (0,useDebounce/* default */.Z)(range, 1000);
    const handleChange = (value)=>{
        setRange(value);
        setShowRange(value);
    };
    (0,external_react_.useEffect)(()=>{
        if (debouncedRange) {
            handleFilter({
                range: range
            });
        }
    }, [
        debouncedRange
    ]);
    const handleByPrice = (value)=>{
        setSort(value);
        handleFilter({
            sort: value
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "by-price",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "title",
                children: tl("Price")
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "price-type",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: sort === "asc" ? "item selected" : "item",
                        onClick: ()=>handleByPrice("asc"),
                        children: tl("By low price")
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: sort === "desc" ? "item selected" : "item",
                        onClick: ()=>handleByPrice("desc"),
                        children: tl("By high price")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "price-rage",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                        children: `${currency_symbol} ${showRange ? showRange[0] : 0}`
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                        children: `${currency_symbol} ${showRange ? showRange[1] : 0}`
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)((external_rc_slider_default()), {
                className: "slider",
                range: true,
                allowCross: false,
                defaultValue: [
                    1,
                    showRange[1]
                ],
                min: 1,
                max: 10000 * currency_rate,
                onChange: (value)=>handleChange(value)
            })
        ]
    });
};
/* harmony default export */ const by_price = (ByPrice);

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "qs"
var external_qs_ = __webpack_require__(7104);
var external_qs_default = /*#__PURE__*/__webpack_require__.n(external_qs_);
;// CONCATENATED MODULE: ./components/search-filter/vertical/index.js












const VerticalFilter = ({ className , brandList  })=>{
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const router = (0,router_.useRouter)();
    const { 0: idList , 1: setIdList  } = (0,external_react_.useState)([
        "category",
        "size",
        "color",
        "brand"
    ]);
    const category = (0,external_react_redux_.useSelector)((state)=>state.category.categoryList);
    const routeHref = router.route.split("/");
    const handleClick = (key)=>{
        const includes = idList.includes(key);
        if (includes) {
            setIdList(idList.filter((item)=>item !== key));
        } else {
            setIdList([
                ...idList,
                key
            ]);
        }
    };
    const handleFilter = ({ brand_id , category_id , range =[] , sort  })=>{
        const id = router.query.id;
        const prevBrandId = router.query.brand_id;
        const prevCategoryId = router.query.category_id;
        const prevFrom = router.query.price_from;
        const prevTo = router.query.price_to;
        const prevSort = router.query.sort;
        const str = external_qs_default().stringify({
            brand_id: brand_id == prevBrandId ? undefined : brand_id ? brand_id : prevBrandId,
            category_id: category_id ? category_id : prevCategoryId,
            price_from: range[0] ? range[0] : prevFrom,
            price_to: range[1] ? range[1] : prevTo,
            sort: sort ? sort : prevSort,
            column_price: sort || prevSort ? "price" : undefined
        });
        if (router.pathname === "/all-product") {
            router.push(`/${routeHref[routeHref.length - 1]}?${str}`);
        } else if (!id) {
            router.push(`/stores/${routeHref[routeHref.length - 1]}?${str}`);
        } else {
            router.push(`/stores/${id}/${routeHref[routeHref.length - 1]}?${str}`);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `filter-vertical ${className}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* default */.Z, {
                idList: idList,
                id: "category",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_summary/* default */.Z, {
                        handleClick: handleClick,
                        idList: idList,
                        id: "category",
                        children: tl("Categories")
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_details/* default */.Z, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(by_category, {
                            handleFilter: handleFilter,
                            category: category
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(accordion/* default */.Z, {
                idList: idList,
                id: "brand",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_summary/* default */.Z, {
                        handleClick: handleClick,
                        idList: idList,
                        id: "brand",
                        children: tl("Brand")
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_details/* default */.Z, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(by_brand, {
                            handleFilter: handleFilter,
                            brandList: brandList
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)(by_price, {
                handleFilter: handleFilter
            })
        ]
    });
};
/* harmony default export */ const vertical = (VerticalFilter);


/***/ }),

/***/ 5053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useDebounce)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useDebounce(value, delay) {
    const { 0: debouncedValue , 1: setDebouncedValue  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const handler = setTimeout(()=>{
            setDebouncedValue(value);
        }, delay);
        return ()=>{
            clearTimeout(handler);
        };
    }, [
        value
    ]);
    return debouncedValue;
};


/***/ })

};
;