"use strict";
exports.id = 5080;
exports.ids = [5080];
exports.modules = {

/***/ 4767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ AddressApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class AddressApi {
    static endpoint = "/api/v1/dashboard/user/addresses";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static create(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static update(id, data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].PUT */ .ZP.PUT, data);
    }
    static delete(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].DELETE */ .ZP.DELETE);
    }
}


/***/ }),

/***/ 5080:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _map_get_position__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7291);
/* harmony import */ var _components_map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6931);
/* harmony import */ var remixicon_react_NavigationFillIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6977);
/* harmony import */ var remixicon_react_NavigationFillIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_NavigationFillIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_main_address__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4767);
/* harmony import */ var _utils_getCurrentLocation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7978);
/* harmony import */ var _form_input_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8999);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3590);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8942);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const EnterAddress = ({ setIsOpen , setOpen =()=>{} , editAddress , setEditAddress =()=>{} ,  })=>{
    const { 0: title , 1: setTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: address , 1: setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const { getUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__/* .MainContext */ .T);
    const addAddress = ()=>{
        if (!title) {
            react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(tl("Please enter address title"));
        } else {
            _api_main_address__WEBPACK_IMPORTED_MODULE_5__/* .AddressApi.create */ .I.create({
                title: `${title}`,
                address: address?.address,
                location: `${address?.location.lat},${address?.location.lng}`,
                active: 0
            }).then(()=>{
                setOpen(false);
                setIsOpen(null);
                setEditAddress(false);
            }).catch((error)=>{
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(error.response?.data?.message);
            }).finally(()=>{
                getUser();
                setTitle("");
            });
        }
    };
    const updateAddress = ()=>{
        _api_main_address__WEBPACK_IMPORTED_MODULE_5__/* .AddressApi.update */ .I.update(editAddress?.id, {
            title: `${title}`,
            address: value,
            location: `${address.location.lat},${address.location.lng}`,
            active: 0
        }).then(()=>{
            setOpen(false);
            setEditAddress(false);
        }).catch((error)=>{
            console.log(error);
            react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(error.response?.data?.message);
        }).finally(()=>{
            getUser();
            setTitle("");
            setValue("");
        });
    };
    const onFinish = ()=>{
        if (editAddress) {
            updateAddress();
        } else {
            addAddress();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setTitle(editAddress?.title);
        setValue(editAddress?.address);
    }, [
        editAddress
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setValue(address?.address);
    }, [
        address
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "enter-address",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "row",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    placeholder: "Address name",
                    label: "Name",
                    onChange: (e)=>setTitle(e.target.value),
                    value: title
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "enter-input",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "get-location",
                        onClick: ()=>(0,_utils_getCurrentLocation__WEBPACK_IMPORTED_MODULE_6__/* .getCurrentLocation */ .v)({
                                setAddress
                            }),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_NavigationFillIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                size: 20
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Define")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_map_get_position__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        setValue: setValue,
                        value: value,
                        setAddress: setAddress
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "get-location",
                        type: "submit",
                        onClick: onFinish,
                        children: tl("Submit")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "google-map",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_map__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    address: address,
                    setAddress: setAddress
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EnterAddress);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ getCurrentLocation)
/* harmony export */ });
/* harmony import */ var _getLocation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2150);

// Step 1: Get user coordinates
function getCurrentLocation({ setAddress  }) {
    var options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };
    function success(pos) {
        var crd = pos.coords;
        let lat = crd.latitude.toString();
        let lng = crd.longitude.toString();
        (0,_getLocation__WEBPACK_IMPORTED_MODULE_0__/* .getLocationObj */ .l)({
            location: {
                lat,
                lng
            },
            setAddress
        });
    }
    function error(err) {
        console.warn(`ERROR(${err.code}): ${err.message}`);
    }
    navigator.geolocation.getCurrentPosition(success, error, options);
}


/***/ })

};
;