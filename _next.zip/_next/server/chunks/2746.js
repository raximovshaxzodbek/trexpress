"use strict";
exports.id = 2746;
exports.ids = [2746];
exports.modules = {

/***/ 2746:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_GoogleFillIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2986);
/* harmony import */ var remixicon_react_GoogleFillIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_GoogleFillIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_FacebookFillIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1584);
/* harmony import */ var remixicon_react_FacebookFillIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FacebookFillIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_AppleFillIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(816);
/* harmony import */ var remixicon_react_AppleFillIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_AppleFillIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2045);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _services_auth__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4368);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8942);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__, _services_auth__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__, react_toastify__WEBPACK_IMPORTED_MODULE_11__]);
([_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__, _services_auth__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__, react_toastify__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const SocialAuth = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { googleSignIn , facebookSignIn  } = (0,_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__/* .useAuth */ .aC)();
    const { getUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__/* .MainContext */ .T);
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const handleGoogleSignIn = async (e)=>{
        e.preventDefault();
        try {
            await googleSignIn().then((res)=>{
                _services_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"].post */ .Z.post("/api/v1/auth/google/callback", {
                    name: res.user.displayName,
                    email: res.user.email,
                    id: res.user.uid,
                    avatar: res.user.photoURL
                }).then((response)=>{
                    (0,nookies__WEBPACK_IMPORTED_MODULE_9__.setCookie)(null, "access_token", response.data.data.access_token, {
                        maxAge: 30 * 24 * 60 * 60,
                        path: "/"
                    });
                    getUser();
                    if (router.query.invite) {
                        router.push(`/invite/${router.query.invite}`);
                    } else router.push("/");
                }).catch((error)=>{
                    console.log(error);
                    react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error(error.response?.data?.message);
                });
            });
        } catch (error) {
            console.log(error.message);
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error(error.message);
        }
    };
    const handleFacebookSignIn = async (e)=>{
        e.preventDefault();
        try {
            await facebookSignIn().then((res)=>{
                _services_auth__WEBPACK_IMPORTED_MODULE_8__/* ["default"].post */ .Z.post("/api/v1/auth/google/callback", {
                    name: res.user.displayName,
                    email: res.user.email,
                    id: res.user.uid,
                    avatar: res.user.photoURL
                }).then((response)=>{
                    (0,nookies__WEBPACK_IMPORTED_MODULE_9__.setCookie)(null, "access_token", response.data.data.access_token, {
                        maxAge: 30 * 24 * 60 * 60,
                        path: "/"
                    });
                    getUser();
                    console.log("Hello");
                    if (router.query.invite) {
                        router.push(`/invite/${router.query.invite}`);
                    } else router.push("/");
                }).catch((error)=>{
                    console.log(error);
                    react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error(error.response?.data?.message);
                });
            });
        } catch (error) {
            console.log("Hello");
            console.log(error.message);
            react_toastify__WEBPACK_IMPORTED_MODULE_11__.toast.error(error.message);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "auth-social",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "social-item google",
                onClick: handleGoogleSignIn,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_GoogleFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                        size: 22
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                        children: tl("Continue with Google")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "social-item facebook",
                onClick: handleFacebookSignIn,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_FacebookFillIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    size: 22
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialAuth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;