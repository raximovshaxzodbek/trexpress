"use strict";
exports.id = 2637;
exports.ids = [2637];
exports.modules = {

/***/ 8049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ BannerApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class BannerApi {
    static endpoint = "/api/v1/rest/banners";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/paginate", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static getProduct(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}/products`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static liked(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}/liked`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST);
    }
}


/***/ }),

/***/ 2637:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
/* harmony import */ var remixicon_react_ThumbUpLineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8288);
/* harmony import */ var remixicon_react_ThumbUpLineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ThumbUpLineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_main_banner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8049);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7821);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8942);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_3__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const LookCard = ({ product  })=>{
    const { setContent , setOpen , setLookId , setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__/* .MainContext */ .T);
    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: lookId , 1: setId  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const handleClick = (product)=>{
        setContent("show-look");
        setOpen(true);
        setLookId(product.id);
        setDrawerTitle(product?.translation?.title);
    };
    const handleLiked = (e, id)=>{
        e.stopPropagation();
        setId(id);
        if (lookId === id) {
            setCount((prev)=>prev - 1);
        } else {
            setCount((prev)=>prev + 1);
        }
        _api_main_banner__WEBPACK_IMPORTED_MODULE_5__/* .BannerApi.liked */ .b.liked(id).then((res)=>{}).catch((error)=>{
            console.log(error);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error(error.response.data.message);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (product) {
            setCount(product?.likes);
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "look-card",
        onClick: ()=>handleClick(product),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                src: _constants__WEBPACK_IMPORTED_MODULE_6__/* .imgBaseUrl */ .XW + product.img,
                alt: "look"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "btn-group",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "like-btn product-count",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "label",
                            children: `${product.products?.length} ${tl("products")}`
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "like-btn",
                        onClick: (e)=>handleLiked(e, product.id),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_ThumbUpLineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "label",
                                children: count
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LookCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;