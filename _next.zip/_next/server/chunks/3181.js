"use strict";
exports.id = 3181;
exports.ids = [3181];
exports.modules = {

/***/ 3181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);


const axiosService = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://admin.rentinn.uz",
    headers: {
        "X-Custom-Header": "lEWGIQU",
        Accept: "application/json; charset=utf-8",
        Authorization: `Bearer 27|2MAPUfBolv9JsCjSYzlnuww4y7Uhelm6a4HF1V8d`
    },
    timeout: 8000
});
axiosService.interceptors.request.use(function(config) {
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)();
    const currency_id = cookies?.currency_id;
    const language_id = cookies?.language_id;
    const language_locale = cookies?.language_locale;
    config.params = {
        lang: language_locale,
        language_id,
        currency_id,
        ...config.params
    };
    // Do something before request is sent
    return config;
}, function(error) {
    // Do something with request error
    return Promise.reject(error);
});
// Add a response interceptor
axiosService.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosService);


/***/ })

};
;