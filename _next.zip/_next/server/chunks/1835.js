"use strict";
exports.id = 1835;
exports.ids = [1835];
exports.modules = {

/***/ 1835:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7821);
/* harmony import */ var _redux_slices_user__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9134);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3788);
/* harmony import */ var _redux_slices_order__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9611);
/* harmony import */ var _redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3212);
/* harmony import */ var _redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4982);
/* harmony import */ var _redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7169);
/* harmony import */ var _redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7508);
/* harmony import */ var remixicon_react_UserSearchLineIcon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3596);
/* harmony import */ var remixicon_react_UserSearchLineIcon__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_UserSearchLineIcon__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var remixicon_react_LogoutCircleRLineIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2324);
/* harmony import */ var remixicon_react_LogoutCircleRLineIcon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LogoutCircleRLineIcon__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9418);
/* harmony import */ var remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8249);
/* harmony import */ var remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4565);
/* harmony import */ var remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8942);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_9__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_17__]);
([_redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_9__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const UserAvatar = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_19__.useTranslation)();
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_20__.parseCookies)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.user.data);
    const { setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_17__/* .MainContext */ .T);
    const isEmpty = Object.keys(user ? user : {}).length === 0;
    const dropdownItems = [
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_UserSearchLineIcon__WEBPACK_IMPORTED_MODULE_12___default()), {}),
            label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                children: tl("Profile Settings")
            }),
            suffix: null,
            href: "/settings"
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_15___default()), {}),
            label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                children: tl("Be seller")
            }),
            suffix: null,
            href: "/be-seller"
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_14___default()), {}),
            label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                children: tl("Order history")
            }),
            suffix: null,
            href: "/order-history"
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_16___default()), {}),
            label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                children: tl("Your invite")
            }),
            suffix: null,
            href: "/invite"
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_LogoutCircleRLineIcon__WEBPACK_IMPORTED_MODULE_13___default()), {}),
            label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                onClick: logOut,
                children: tl("Log Out")
            }),
            suffix: null,
            href: "/"
        }, 
    ];
    const logOut = ()=>{
        dispatch((0,_redux_slices_user__WEBPACK_IMPORTED_MODULE_5__/* .clearUser */ .pn)());
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_6__/* .clearCart */ .LL)());
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_6__/* .clearOrderShops */ .F)());
        dispatch((0,_redux_slices_order__WEBPACK_IMPORTED_MODULE_7__/* .clearOrder */ .bn)());
        dispatch((0,_redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_8__/* .clearSavedStore */ .Wo)());
        dispatch((0,_redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_9__/* .clearAddress */ .RH)());
        dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_10__/* .clearList */ .vy)());
        dispatch((0,_redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_11__/* .clearViewedList */ .ZC)());
        setAddress([]);
        document.cookie = "access_token" + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
        document.cookie = "userLocation" + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
        router.push("/");
    };
    const findHTTPS = user?.img?.includes("https");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: !isEmpty && cookies?.access_token && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "user",
            children: [
                findHTTPS ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    src: user.img,
                    alt: "Avatar"
                }) : user.img ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    src: _constants__WEBPACK_IMPORTED_MODULE_4__/* .imgBaseUrl */ .XW + user.img,
                    alt: "Avatar"
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "square avatar",
                    children: user.firstname?.slice(0, 1)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "dropdown",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "dropdown-items",
                        children: dropdownItems.map((data, key)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_18___default()), {
                                href: data.href,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "dropdown-item",
                                    onClick: data.href === "/" ? logOut : ()=>{},
                                    children: [
                                        data.icon,
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: data.label
                                        }),
                                        data.suffix && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "suffix",
                                            children: data.suffix
                                        })
                                    ]
                                })
                            }, key);
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAvatar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;