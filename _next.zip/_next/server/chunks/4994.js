"use strict";
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 4994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const formatDuration = (seconds)=>{
    const min = Math.floor(seconds / 60);
    let sec = seconds - min * 60;
    if (sec < 10) {
        sec = `0${sec}`;
    }
    return {
        min,
        sec
    };
};
function Countdown({ isTimeOver , setIsTimeOver  }) {
    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(60 * 5);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let timer;
        if (!isTimeOver) {
            setCount(60 * 5);
            timer = setInterval(()=>{
                setCount((counter)=>{
                    const updatedCounter = counter - 1;
                    if (updatedCounter === 0) {
                        setIsTimeOver(true);
                        return 0;
                    }
                    return updatedCounter;
                });
            }, 1000);
        }
        return ()=>clearInterval(timer);
    }, [
        isTimeOver
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        children: [
            formatDuration(count).min,
            ":",
            formatDuration(count).sec
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Countdown);


/***/ })

};
;