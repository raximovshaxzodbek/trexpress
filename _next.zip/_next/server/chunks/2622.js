"use strict";
exports.id = 2622;
exports.ids = [2622];
exports.modules = {

/***/ 9722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports GET, POST, PATCH, PUT, DELETE */
const GET = "GET";
const POST = "POST";
const PATCH = "PATCH";
const PUT = "PUT";
const DELETE = "DELETE";
const HTTPMethods = {
    GET: "GET",
    POST: "POST",
    PATCH: "PATCH",
    PUT: "PUT",
    DELETE: "DELETE"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HTTPMethods);


/***/ }),

/***/ 2622:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ mainCaller)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);



function mainCaller(path, method = _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, data, headers, params = {}) {
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)();
    const access_token = cookies.access_token;
    const currency_id = cookies?.currency_id;
    const language_id = cookies?.language_id;
    const language_locale = cookies?.language_locale;
    const _headers = {
        Accept: "application/json; charset=utf-8",
        Authorization: `Bearer ${decodeURI(access_token)}`,
        ...headers
    };
    const options = {
        method,
        url: "https://admin.rentinn.uz" + path
    };
    if (method === "GET") {
        params.lang = language_locale;
        params.language_id = language_id;
        params.currency_id = params.currency_id ? params.currency_id : currency_id;
    }
    options.params = params;
    if (data) {
        options.data = data;
        if (data instanceof FormData) {
            _headers["Content-type"] = "multipart/form-data";
        } else {
            _headers["Content-type"] = "application/json; charset=utf-8";
        }
    }
    options.headers = _headers;
    return axios__WEBPACK_IMPORTED_MODULE_0___default()(options).then((r)=>r.data);
};


/***/ })

};
;