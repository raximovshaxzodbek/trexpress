"use strict";
exports.id = 3788;
exports.ids = [3788];
exports.modules = {

/***/ 3788:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bq": () => (/* binding */ decreaseCart),
/* harmony export */   "F": () => (/* binding */ clearOrderShops),
/* harmony export */   "LL": () => (/* binding */ clearCart),
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "gm": () => (/* binding */ replaceStock),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "j_": () => (/* binding */ getTotals)
/* harmony export */ });
/* unused harmony exports addToOrdered, setOrderData, calculateProduct */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    cartItems: [],
    orderedData: [],
    data: {
        product_total: 0,
        tax: 0,
        order_tax: 0,
        order_total: 0
    },
    cartTotalAmount: 0,
    cartTotalQuantity: 0
};
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {
        addToOrdered (state, action) {
            state.orderedData = action.payload;
        },
        setOrderData (state, action) {
            state.data = {
                ...state.data,
                ...action.payload
            };
        },
        addToCart (state, action) {
            const stockIndex = state.cartItems.findIndex((item)=>item.stockId.id === action.payload.stockId.id);
            if (stockIndex >= 0) {
                state.cartItems[stockIndex] = {
                    ...state.cartItems[stockIndex],
                    qty: state.cartItems[stockIndex].qty + 1
                };
            } else {
                let tempProductItem = {
                    ...action.payload,
                    qty: action.payload.min_qty
                };
                state.cartItems.push(tempProductItem);
            }
        },
        replaceStock (state, action) {
            const { payload  } = action;
            state.cartItems = payload.map((item)=>{
                const stock = state.cartItems.find((el)=>el.id === item.id);
                return {
                    ...stock,
                    qty: item.quantity,
                    stockId: {
                        ...stock.stockId,
                        quantity: item.quantity
                    }
                };
            });
        },
        decreaseCart (state, action) {
            const stockIndex = state.cartItems.findIndex((item)=>item.stockId.id === action.payload.stockId.id);
            if (state.cartItems[stockIndex].qty > action.payload.min_qty) {
                state.cartItems[stockIndex].qty -= 1;
            } else if (state.cartItems[stockIndex].qty === action.payload.min_qty) {
                const nextCartItems = state.cartItems.filter((item)=>item.stockId.id !== action.payload.stockId.id);
                state.cartItems = nextCartItems;
            }
        },
        removeFromCart (state, action) {
            state.cartItems.map((cartItem)=>{
                if (cartItem.stockId.id === action.payload.stockId.id) {
                    const nextCartItems = state.cartItems.filter((item)=>item.stockId.id !== action.payload.stockId.id);
                    state.cartItems = nextCartItems;
                }
                return state;
            });
        },
        getTotals (state, action) {
            calculatePrice(state);
            let { total , quantity  } = state.cartItems.reduce((cartTotal, cartItem)=>{
                const { stockId , qty  } = cartItem;
                let itemTotal = 0;
                if (stockId.discount) {
                    itemTotal = (stockId.price - stockId.discount) * qty;
                } else {
                    itemTotal = stockId.price * qty;
                }
                cartTotal.total += itemTotal;
                cartTotal.quantity += qty;
                return cartTotal;
            }, {
                total: 0,
                quantity: 0
            });
            total = parseFloat(total.toFixed(2));
            state.cartTotalQuantity = quantity;
            state.cartTotalAmount = total;
        },
        clearCart (state, action) {
            state.cartItems = [];
            state.orderedData = [];
            state.cartTotalAmount = 0;
            state.cartTotalQuantity = 0;
            state.data = {
                user: "",
                address: "",
                currency: "",
                deliveries: [],
                product_total: 0,
                tax: 0,
                order_tax: 0,
                order_total: 0
            };
        },
        clearOrderShops (state) {
            state.cartTotalAmount = 0;
            state.cartTotalQuantity = 0;
            state.orderedData = [];
            state.data = {
                user: "",
                address: "",
                currency: "",
                deliveries: [],
                product_total: 0,
                tax: 0,
                order_tax: 0,
                order_total: 0
            };
        }
    }
});
function calculatePrice(state) {
    let items = [];
    state.cartItems.forEach((item)=>{
        let total_price;
        let productTax;
        let shopTax;
        if (item.stockId.discount) {
            total_price = (item.stockId.price - item.stockId.discount) * item.qty;
        } else {
            total_price = item.stockId.price * item.qty;
        }
        if (item.prevTax == null) item.prevTax = item.tax;
        productTax = total_price * item.prevTax / 100;
        shopTax = total_price * item.shop.tax / 100;
        item.tax = productTax;
        item.total_price = total_price + productTax;
        item.shop_tax = shopTax;
        const newItem = {
            ...item,
            productTax
        };
        items.push(newItem);
    });
    state.cartItems = items;
}
const { addToCart , decreaseCart , removeFromCart , getTotals , clearCart , addToOrdered , clearOrderShops , setOrderData , calculateProduct , replaceStock ,  } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);


/***/ })

};
;