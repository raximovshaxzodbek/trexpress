"use strict";
exports.id = 6931;
exports.ids = [6931];
exports.modules = {

/***/ 6931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var google_maps_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4573);
/* harmony import */ var google_maps_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(google_maps_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_getLocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2150);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7821);







const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_5__.parseCookies)();
let config = null;
if (cookies?.settings) {
    config = JSON.parse(cookies?.settings);
}
const GoogleMap = (props)=>{
    const storeLocations = [];
    let center = {};
    const { 0: selectedPlace , 1: setSelectedPlace  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: activeMarker , 1: setActiveMarker  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: showingInfoWindow , 1: setShowingInfoWindow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const defaultLocation = cookies.userLocation ? cookies.userLocation.split(",") : "41.2646,69.2163".split(",");
    console.log(defaultLocation);
    if (props.stores) {
        props.stores?.map((store)=>{
            storeLocations.push({
                logo: store.logo_img,
                uuid: store.uuid,
                name: store?.translation.title,
                lat: store?.location.latitude,
                lng: store?.location.longitude,
                open_time: store?.open_time,
                close_time: store?.close_time
            });
        });
    }
    if (storeLocations.length > 0) {
        center = storeLocations[0];
    } else if (props.address) {
        center = props.address.location;
    }
    const onMarkerClick = (props, marker)=>{
        setSelectedPlace(props);
        setActiveMarker(marker);
        setShowingInfoWindow(true);
    };
    const onInfoWindowClose = ()=>{
        setActiveMarker(null);
        setShowingInfoWindow(false);
    };
    const onClick = (t, map, coord)=>{
        const { latLng  } = coord;
        const lat = latLng.lat();
        const lng = latLng.lng();
        (0,_utils_getLocation__WEBPACK_IMPORTED_MODULE_4__/* .getLocationObj */ .l)({
            location: {
                lat,
                lng
            },
            setAddress: props.setAddress
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!props.address) {
            (0,_utils_getLocation__WEBPACK_IMPORTED_MODULE_4__/* .getLocationObj */ .l)({
                location: {
                    lat: defaultLocation[0],
                    lng: defaultLocation[1]
                },
                setAddress: props.setAddress
            });
        }
    }, [
        props
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "map-wrapper",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(google_maps_react__WEBPACK_IMPORTED_MODULE_3__.Map, {
            onClick: onClick,
            google: props.google,
            zoom: 10,
            initialCenter: center,
            center: center,
            className: "container map",
            children: [
                storeLocations.length > 0 ? storeLocations.map((loc, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(google_maps_react__WEBPACK_IMPORTED_MODULE_3__.Marker, {
                        name: loc.name,
                        uuid: loc.uuid,
                        logo: loc.logo,
                        open_time: loc.open_time,
                        close_time: loc.close_time,
                        position: {
                            lat: loc.lat,
                            lng: loc.lng
                        },
                        title: loc.name,
                        onClick: onMarkerClick,
                        icon: {
                            url: "https://cdn-icons-png.flaticon.com/32/64/64113.png"
                        }
                    }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(google_maps_react__WEBPACK_IMPORTED_MODULE_3__.Marker, {
                    position: center,
                    icon: {
                        url: "https://cdn-icons-png.flaticon.com/32/64/64113.png"
                    }
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(google_maps_react__WEBPACK_IMPORTED_MODULE_3__.InfoWindow, {
                    marker: activeMarker,
                    onClose: onInfoWindowClose,
                    visible: showingInfoWindow,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "custom-map-pin",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "shop",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "logo",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                        src: _constants__WEBPACK_IMPORTED_MODULE_6__/* .imgBaseUrl */ .XW + activeMarker?.logo
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "data",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: `/stores/${selectedPlace?.uuid}`,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                className: "info-window-link",
                                                children: selectedPlace?.name
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "time",
                                            children: `${selectedPlace?.open_time} - ${selectedPlace?.close_time}`
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,google_maps_react__WEBPACK_IMPORTED_MODULE_3__.GoogleApiWrapper)({
    apiKey: config?.google_map_key ? config.google_map_key : "AIzaSyCvbzi4Otmgjw37UZybZk6cgGKb1QeKsgw",
    libraries: [
        "places"
    ]
})(GoogleMap));


/***/ }),

/***/ 2150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ getLocationObj)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7104);
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_2__);



const getLocationObj = ({ location , setAddress =()=>{}  })=>{
    const cookie = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)();
    let config = null;
    if (cookie?.settings) {
        config = JSON.parse(cookie?.settings);
    }
    let str = qs__WEBPACK_IMPORTED_MODULE_2___default().stringify({
        latlng: `${location?.lat},${location?.lng}`,
        key: config?.google_map_key ? config.google_map_key : "AIzaSyCvbzi4Otmgjw37UZybZk6cgGKb1QeKsgw"
    }, {
        addQueryPrefix: true
    });
    axios__WEBPACK_IMPORTED_MODULE_0___default().get(`https://maps.googleapis.com/maps/api/geocode/json${str}`).then((res)=>{
        setAddress({
            address: res.data.results[0]?.formatted_address,
            location: res.data.results[0]?.geometry?.location
        });
    }).catch((error)=>{
        console.log(error);
    });
};


/***/ })

};
;