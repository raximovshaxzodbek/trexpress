"use strict";
exports.id = 4527;
exports.ids = [4527];
exports.modules = {

/***/ 1371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ ShopApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class ShopApi {
    static endpoint = "/api/v1/rest/shops";
    static get(params) {
        params.perPage = 8;
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/paginate", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static getDelivery(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/deliveries`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getNearby(params = {}) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/nearby", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static create(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`/api/v1/dashboard/user/shops`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static getShop() {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`/api/v1/dashboard/user/shops`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static checkIds(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
}


/***/ }),

/***/ 3725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "n3": () => (/* binding */ getCategory)
/* harmony export */ });
/* unused harmony export categorySlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3181);


const getCategory = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("category/getCategory", async ()=>{
    const response = await _services_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/api/v1/rest/categories/paginate");
    return {
        data: response.data.data
    };
});
const categorySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "category",
    initialState: {
        categoryList: [],
        total: 1
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getCategory.fulfilled, (state, action)=>{
            state.categoryList = action.payload.data;
            state.total = action.payload.totalPages;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (categorySlice.reducer);


/***/ }),

/***/ 7169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IV": () => (/* binding */ addToSaved),
/* harmony export */   "YH": () => (/* binding */ removeFromSaved),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "lj": () => (/* binding */ updateSaved),
/* harmony export */   "vy": () => (/* binding */ clearList)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    savedProductList: []
};
const savedProductSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "savedProduct",
    initialState,
    reducers: {
        addToSaved (store, action) {
            store.savedProductList.push({
                ...action.payload
            });
        },
        removeFromSaved (state, action) {
            state.savedProductList.map((productItem)=>{
                if (productItem.id === action.payload.id) {
                    const nextProductItems = state.savedProductList.filter((item)=>item.id !== productItem.id);
                    state.savedProductList = nextProductItems;
                }
                return state;
            });
        },
        clearList (state, action) {
            state.savedProductList = [];
        },
        updateSaved (state, action) {
            state.savedProductList = action.payload;
        }
    }
});
const { addToSaved , removeFromSaved , clearList , updateSaved  } = savedProductSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (savedProductSlice.reducer);


/***/ }),

/***/ 3212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IV": () => (/* binding */ addToSaved),
/* harmony export */   "Wo": () => (/* binding */ clearSavedStore),
/* harmony export */   "YH": () => (/* binding */ removeFromSaved),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "nJ": () => (/* binding */ updateSavedStore)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    savedStoreList: []
};
const savedStoreSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "savedStore",
    initialState,
    reducers: {
        addToSaved (store, action) {
            store.savedStoreList.push({
                ...action.payload
            });
        },
        removeFromSaved (state, action) {
            state.savedStoreList.map((storeItem)=>{
                if (storeItem.id === action.payload.id) {
                    const nextStoreItems = state.savedStoreList.filter((item)=>item.id !== storeItem.id);
                    state.savedStoreList = nextStoreItems;
                }
                return state;
            });
        },
        clearSavedStore (state) {
            state.savedStoreList = [];
        },
        updateSavedStore (state, action) {
            state.savedStoreList = action.payload;
        }
    }
});
const { addToSaved , removeFromSaved , clearSavedStore , updateSavedStore ,  } = savedStoreSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (savedStoreSlice.reducer);


/***/ }),

/***/ 5780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gw": () => (/* binding */ getSettings),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export storesSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3181);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
// ** Redux Imports

// ** Axios Imports


const getSettings = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("settings/getSettings", async ()=>{
    const response = await _services_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/api/v1/rest/settings");
    return {
        data: response.data.data
    };
});
function createSettings(list) {
    const result = list.map((item)=>({
            [item.key]: item.value
        }));
    return Object.assign({}, ...result);
}
const storesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "settings",
    initialState: {
        data: {}
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getSettings.fulfilled, (state, action)=>{
            const result = createSettings(action.payload.data);
            state.data = result;
            (0,nookies__WEBPACK_IMPORTED_MODULE_2__.setCookie)(null, "settings", JSON.stringify(result), {
                maxAge: 30 * 24 * 60 * 60,
                path: "/"
            });
            (0,nookies__WEBPACK_IMPORTED_MODULE_2__.setCookie)(null, "userLocation", result.location, {
                maxAge: 30 * 24 * 60 * 60,
                path: "/"
            });
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storesSlice.reducer);


/***/ }),

/***/ 9134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "gW": () => (/* binding */ savedUser),
/* harmony export */   "pn": () => (/* binding */ clearUser)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    data: {}
};
const saveUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "user",
    initialState,
    reducers: {
        savedUser (store, action) {
            store.data = action.payload;
        },
        clearUser (store) {
            store.data = {};
        }
    }
});
const { savedUser , clearUser  } = saveUser.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (saveUser.reducer);


/***/ }),

/***/ 4152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OQ": () => (/* binding */ addToViewed),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "vr": () => (/* binding */ markAllList)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    data: []
};
const viewedNotificationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "notification",
    initialState,
    reducers: {
        addToViewed (state, action) {
            const include = state.data.findIndex((item)=>item === action.payload);
            if (!(include >= 0)) {
                state.data.push(action.payload);
            }
        },
        markAllList (state, action) {
            if (state.data.length < action.payload.length) state.data.push(...action.payload);
        }
    }
});
const { addToViewed , markAllList  } = viewedNotificationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (viewedNotificationSlice.reducer);


/***/ }),

/***/ 7508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OQ": () => (/* binding */ addToViewed),
/* harmony export */   "ZC": () => (/* binding */ clearViewedList),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "qt": () => (/* binding */ updateViwed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    viewedProductList: []
};
const viewedProductSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "viewedProduct",
    initialState,
    reducers: {
        addToViewed (state, action) {
            const include = state.viewedProductList.findIndex((item)=>item.id === action.payload.id);
            if (!(include >= 0)) {
                state.viewedProductList.push({
                    ...action.payload
                });
            }
        },
        clearViewedList (state) {
            state.viewedProductList = [];
        },
        updateViwed (state, action) {
            state.viewedProductList = action.payload;
        }
    }
});
const { addToViewed , clearViewedList , updateViwed  } = viewedProductSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (viewedProductSlice.reducer);


/***/ })

};
;