"use strict";
exports.id = 3304;
exports.ids = [3304];
exports.modules = {

/***/ 3304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SEO)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7821);




function SEO({ title , description , image , keywords  }) {
    const settings = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.settings.data);
    const currentURL = window.location.href;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("title", {
                children: title ? title : settings.title ? settings.title : "Site title"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                charSet: "utf-8"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "viewport",
                content: "width=device-width, initial-scale=1"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "robots",
                "data-hid": "robots",
                content: "index, follow"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "googlebot",
                "data-hid": "googlebot",
                content: "index, follow"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "keywords",
                content: keywords
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "name",
                name: "itemprop",
                content: ""
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "og:url",
                property: "og:url",
                content: currentURL
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                property: "og:type",
                content: "website"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                property: "og:title",
                content: currentURL
            }, "ogtitle"),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                property: "og:description",
                content: description
            }, "ogdesc"),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "og:site_name",
                property: "og:site_name",
                content: currentURL
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                property: "og:image",
                content: image || _constants__WEBPACK_IMPORTED_MODULE_3__/* .imgBaseUrl */ .XW + settings["favicon"]
            }, "ogimage"),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "twitter:url",
                name: "twitter:url",
                content: currentURL
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                name: "twitter:card",
                content: "summary"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                name: "twitter:title",
                content: title ? `${title}` : settings.title ? settings.title : "Site title"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                name: "twitter:description",
                content: description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "twitter:creator",
                name: "twitter:creator",
                content: `@${currentURL}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                "data-hid": "twitter:site",
                name: "twitter:site",
                content: `@${currentURL}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("meta", {
                "data-n-head": "ssr",
                name: "twitter:image",
                content: image || _constants__WEBPACK_IMPORTED_MODULE_3__/* .imgBaseUrl */ .XW + settings["favicon"]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("link", {
                rel: "icon",
                href: _constants__WEBPACK_IMPORTED_MODULE_3__/* .imgBaseUrl */ .XW + settings["favicon"]
            })
        ]
    });
};


/***/ }),

/***/ 7821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XW": () => (/* binding */ imgBaseUrl)
/* harmony export */ });
/* unused harmony exports storeFilter, image, color, text */
const imgBaseUrl = `${"https://admin.rentinn.uz"}/storage/images/`;
const storeFilter = [
    {
        id: "all",
        value: "All"
    },
    {
        id: "open",
        value: "Open now"
    },
    {
        id: "always_open",
        value: "Work 24/7"
    },
    {
        id: "new",
        value: "New"
    },
    {
        id: "delivery",
        value: "Pickup"
    }, 
];
const image = "image";
const color = "color";
const text = "text";


/***/ })

};
;