"use strict";
exports.id = 2045;
exports.ids = [2045];
exports.modules = {

/***/ 7730:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _slices_cart__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3788);
/* harmony import */ var _slices_stores__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(302);
/* harmony import */ var _slices_banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1588);
/* harmony import */ var _slices_category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3725);
/* harmony import */ var _slices_savedProduct__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7169);
/* harmony import */ var _slices_savedStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3212);
/* harmony import */ var _slices_viewed_product__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7508);
/* harmony import */ var _slices_viewed_notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4152);
/* harmony import */ var _slices_savedAddress__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4982);
/* harmony import */ var _slices_user__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9134);
/* harmony import */ var _slices_order__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9611);
/* harmony import */ var _slices_chat__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9689);
/* harmony import */ var _slices_settings__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5780);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_slices_savedAddress__WEBPACK_IMPORTED_MODULE_8__]);
_slices_savedAddress__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const rootReducer = {
    user: _slices_user__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP,
    cart: _slices_cart__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP,
    stores: _slices_stores__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
    savedProduct: _slices_savedProduct__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
    savedStore: _slices_savedStore__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
    viewedProduct: _slices_viewed_product__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
    savedAddress: _slices_savedAddress__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP,
    category: _slices_category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
    banners: _slices_banner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
    order: _slices_order__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP,
    notification: _slices_viewed_notification__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP,
    chat: _slices_chat__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP,
    settings: _slices_settings__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rootReducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ey": () => (/* binding */ getBanners),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export bannerSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3181);
// ** Redux Imports

// ** Axios Imports

const getBanners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("banners/getBanners", async (data)=>{
    const response = await _services_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("/api/v1/rest/banners/paginate", data);
    return {
        data: response.data,
        totalPages: response.data.length
    };
});
const bannerSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "banners",
    initialState: {
        data: [],
        total: 1
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getBanners.fulfilled, (state, action)=>{
            state.data = action.payload.data;
            state.total = action.payload.totalPages;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bannerSlice.reducer);


/***/ }),

/***/ 9689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hz": () => (/* binding */ addMessage),
/* harmony export */   "Nv": () => (/* binding */ setChats),
/* harmony export */   "Z": () => (/* binding */ setMessages),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "eb": () => (/* binding */ setCurrentChat),
/* harmony export */   "zR": () => (/* binding */ setNewMessage)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    chats: [],
    messages: [],
    currentChat: null,
    newMessage: ""
};
const chatSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "chat",
    initialState,
    reducers: {
        setChats (state, action) {
            state.chats = action.payload;
        },
        setMessages (state, action) {
            state.messages = action.payload;
        },
        setCurrentChat (state, action) {
            state.currentChat = action.payload;
        },
        addMessage (state, action) {
            state.messages.push(action.payload);
        },
        setNewMessage (state, action) {
            state.newMessage = action.payload;
        }
    }
});
const { setChats , setMessages , setCurrentChat , addMessage , setNewMessage ,  } = chatSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (chatSlice.reducer);


/***/ }),

/***/ 302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports getData, storesSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3181);
// ** Redux Imports

// ** Axios Imports

const getData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("stores/getData", async (data)=>{
    const response = await _services_axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post("/m/shops/shops", data);
    return {
        data: response.data,
        totalPages: response.data.length
    };
});
const storesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "stores",
    initialState: {
        data: [],
        total: 1
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getData.fulfilled, (state, action)=>{
            state.data = action.payload.data;
            state.total = action.payload.totalPages;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storesSlice.reducer);


/***/ }),

/***/ 3071:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ persistor),
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8936);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _rootReducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7730);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4161);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_rootReducer__WEBPACK_IMPORTED_MODULE_2__]);
_rootReducer__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const persistConfig = {
    key: "root",
    version: 1,
    storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_1___default()),
    whitelist: [
        "cart",
        "savedProduct",
        "savedStore",
        "viewedProduct",
        "savedAddress",
        "user",
        "notification",
        "settings", 
    ],
    blacklist: [
        "stores",
        "category",
        "banners",
        "order",
        "chat"
    ]
};
const persistedReducer = (0,redux_persist__WEBPACK_IMPORTED_MODULE_3__.persistReducer)(persistConfig, (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.combineReducers)(_rootReducer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z));
const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.FLUSH,
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.REHYDRATE,
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.PAUSE,
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.PERSIST,
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.PURGE,
                    redux_persist__WEBPACK_IMPORTED_MODULE_3__.REGISTER
                ]
            }
        })
});
const persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_3__.persistStore)(store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6813:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I8": () => (/* binding */ auth),
/* harmony export */   "P4": () => (/* binding */ createChat),
/* harmony export */   "ZP": () => (/* binding */ app),
/* harmony export */   "bG": () => (/* binding */ sendMessage)
/* harmony export */ });
/* unused harmony export db */
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(401);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3745);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1492);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3071);
/* harmony import */ var _redux_slices_chat__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9689);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3590);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_auth__WEBPACK_IMPORTED_MODULE_0__, firebase_app__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_5__]);
([firebase_auth__WEBPACK_IMPORTED_MODULE_0__, firebase_app__WEBPACK_IMPORTED_MODULE_1__, firebase_firestore__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const cookie = (0,nookies__WEBPACK_IMPORTED_MODULE_6__.parseCookies)();
let config = null;
if (cookie?.settings) {
    config = JSON.parse(cookie?.settings);
}
const firebaseConfig = {
    apiKey: config?.api_key ? config?.api_key : "AIzaSyCvbzi4Otmgjw37UZybZk6cgGKb1QeKsgw",
    authDomain: config?.auth_domain ? config?.auth_domain : "goshops-7c405.firebaseapp.com",
    projectId: "goshops-7c405",
    storageBucket: config?.project_id ? config?.project_id : "goshops-7c405.appspot.com",
    messagingSenderId: config?.messaging_sender_id ? config?.messaging_sender_id : "732738074097",
    appId: config?.app_id ? config?.app_id : "1:732738074097:web:de58947609d53efc6fc050",
    measurementId: config?.measurement_id ? config?.measurement_id : "G-SK0FJ6BCPH"
};
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_1__.initializeApp)(firebaseConfig);
const auth = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getAuth)(app);

const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.getFirestore)(app);
(0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.onSnapshot)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(db, "messages"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.orderBy)("created_at", "asc")), (querySnapshot)=>{
    const messages = querySnapshot.docs.map((x)=>({
            id: x.id,
            ...x.data(),
            created_at: String(new Date(x.data().created_at?.seconds * 1000))
        }));
    _redux_store__WEBPACK_IMPORTED_MODULE_3__/* .store.dispatch */ .h.dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_4__/* .setMessages */ .Z)(messages));
});
(0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.onSnapshot)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.query)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(db, "chats"), (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.orderBy)("created_at", "asc")), (querySnapshot)=>{
    const chats = querySnapshot.docs.map((x)=>({
            id: x.id,
            ...x.data(),
            created_at: String(new Date(x.data().created_at?.seconds * 1000))
        }));
    _redux_store__WEBPACK_IMPORTED_MODULE_3__/* .store.dispatch */ .h.dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_4__/* .setChats */ .Nv)(chats));
});
async function sendMessage(payload) {
    try {
        await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(db, "messages"), {
            ...payload,
            created_at: (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.serverTimestamp)()
        });
    } catch (error) {
        react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(error);
    }
}
async function createChat(payload) {
    try {
        await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.addDoc)((0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.collection)(db, "chats"), {
            ...payload,
            created_at: (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_2__.serverTimestamp)()
        });
    } catch (error) {
        react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(error);
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2045:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ho": () => (/* binding */ AuthProvider),
/* harmony export */   "Vo": () => (/* binding */ AuthContext),
/* harmony export */   "aC": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(401);
/* harmony import */ var _services_firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6813);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_auth__WEBPACK_IMPORTED_MODULE_2__, _services_firebase__WEBPACK_IMPORTED_MODULE_3__]);
([firebase_auth__WEBPACK_IMPORTED_MODULE_2__, _services_firebase__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function useAuth() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
}
function AuthProvider({ children  }) {
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_4__.parseCookies)();
    const defaultLocation = cookies.userLocation ? cookies.userLocation.split(",") : "41.2646,69.2163".split(",");
    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: userLocation , 1: setUserLocation  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    function logIn(email, password) {
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithEmailAndPassword)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, email, password);
    }
    function signUp(email, password) {
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.createUserWithEmailAndPassword)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, email, password);
    }
    function logOut() {
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signOut)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8);
    }
    function googleSignIn() {
        const googleAuthProvider = new firebase_auth__WEBPACK_IMPORTED_MODULE_2__.GoogleAuthProvider();
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithPopup)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, googleAuthProvider);
    }
    function facebookSignIn() {
        const facebookAuthProvider = new firebase_auth__WEBPACK_IMPORTED_MODULE_2__.FacebookAuthProvider();
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithPopup)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, facebookAuthProvider);
    }
    function setUpRecaptcha(number) {
        const recaptchaVerifier = new firebase_auth__WEBPACK_IMPORTED_MODULE_2__.RecaptchaVerifier("recaptcha-container", {
            size: "invisible"
        }, _services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8);
        recaptchaVerifier.render();
        return (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.signInWithPhoneNumber)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, number, recaptchaVerifier);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const unsubscribe = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_2__.onAuthStateChanged)(_services_firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I8, (currentuser)=>{
            setUser(currentuser);
        });
        return ()=>{
            unsubscribe();
        };
    }, []);
    const setUserDefaultLocation = (selectedAddress)=>{
        if (selectedAddress) {
            (0,nookies__WEBPACK_IMPORTED_MODULE_4__.setCookie)(null, "userLocation", `${selectedAddress.latitude},${selectedAddress.longitude}`);
            setUserLocation(`${selectedAddress.latitude},${selectedAddress.longitude}`);
        } else if (defaultLocation?.length) {
            (0,nookies__WEBPACK_IMPORTED_MODULE_4__.setCookie)(null, "userLocation", `${defaultLocation[0]},${defaultLocation[1]}`);
            setUserLocation(`${defaultLocation[0]},${defaultLocation[1]}`);
        } else if (Object.keys(navigator.geolocation).length !== 0) {
            navigator.geolocation.getCurrentPosition(function(position1) {
                (0,nookies__WEBPACK_IMPORTED_MODULE_4__.setCookie)(null, "userLocation", `${position1.coords.latitude},${position1.coords.longitude}`);
            });
            setUserLocation(`${position.coords.latitude},${position.coords.longitude}`);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setUserDefaultLocation();
    }, [
        cookies.userLocation
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(AuthContext.Provider, {
        value: {
            user,
            logIn,
            signUp,
            logOut,
            googleSignIn,
            setUpRecaptcha,
            facebookSignIn,
            userLocation,
            setUserDefaultLocation
        },
        children: children
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;