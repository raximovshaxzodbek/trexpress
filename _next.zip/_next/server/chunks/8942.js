"use strict";
exports.id = 8942;
exports.ids = [8942];
exports.modules = {

/***/ 9011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ BlogApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class BlogApi {
    static endpoint = "/api/v1/rest/blogs/paginate";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
}


/***/ }),

/***/ 1997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ BrandApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class BrandApi {
    static endpoint = "/api/v1/rest/brands/paginate";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static create(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static update(id, data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `${id}/`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].PATCH */ .ZP.PATCH, data);
    }
    static delete(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `${id}/`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].DELETE */ .ZP.DELETE);
    }
}


/***/ }),

/***/ 7018:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ getLanguage),
/* harmony export */   "z": () => (/* binding */ getCurrency)
/* harmony export */ });
/* harmony import */ var _services_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4368);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_setCurrency__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2676);
/* harmony import */ var _utils_setLanguage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6000);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_auth__WEBPACK_IMPORTED_MODULE_0__]);
_services_auth__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const getCurrency = (array = ()=>{})=>{
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)();
    const currency_id = cookies.currency_id;
    _services_auth__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/rest/currencies/active").then((res)=>{
        array(res.data.data);
        const defaultCurrency = res.data.data.find((item)=>item.default === true);
        if (!currency_id) {
            (0,_utils_setCurrency__WEBPACK_IMPORTED_MODULE_2__/* .setCurrency */ .N)(defaultCurrency);
        }
    }).catch((error)=>{
        console.log(error);
    });
};
const getLanguage = (array = ()=>{})=>{
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)();
    const language_id = cookies.language_id;
    _services_auth__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/rest/languages/active").then((res)=>{
        array(res.data.data);
        const defaultLanguage = res.data.data.find((item)=>item.default === 1);
        if (!language_id) {
            (0,_utils_setLanguage__WEBPACK_IMPORTED_MODULE_3__/* .setLanguage */ .m)(defaultLanguage);
        }
    }).catch((error)=>{
        console.log(error);
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ ProductApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class ProductApi {
    static endpoint = "/api/v1/rest/products";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/paginate", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getDiscount(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/discount", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getMostSales(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/most-sold", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null);
    }
    static checkIds(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/ids", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
}


/***/ }),

/***/ 4827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ UserApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class UserApi {
    static endpoint = "/api/v1/dashboard/user";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/profile/show`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static update(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/profile/update`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].PUT */ .ZP.PUT, data);
    }
    static export(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/export/order/${id}/pdf`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, {
            responseType: "blob"
        });
    }
    static passwordUpdate(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/profile/password/update`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static getWallet(params = {}) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/wallet/histories`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static firebaseTokenUpdate(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/profile/firebase/token/update`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
}


/***/ }),

/***/ 4368:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3224);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_i18next__WEBPACK_IMPORTED_MODULE_1__]);
_i18next__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const serviceWithOutToken = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://admin.rentinn.uz",
    headers: {
        "X-Custom-Header": "lEWGIQU",
        Accept: "application/json; charset=utf-8"
    }
});
serviceWithOutToken.interceptors.request.use(function(config) {
    // Do something before request is sent
    if (config.method === "get") {
        config.params = {
            lang: _i18next__WEBPACK_IMPORTED_MODULE_1__/* ["default"].language */ .Z.language,
            ...config.params
        };
    }
    return config;
}, function(error) {
    // Do something with request error
    return Promise.reject(error);
});
// Add a response interceptor
serviceWithOutToken.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (serviceWithOutToken);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3224:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__]);
i18next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

i18next__WEBPACK_IMPORTED_MODULE_0__["default"].init({
    resources: {},
    ns: "translation",
    defaultNS: "translation",
    fallbackLng: "en",
    debug: false,
    react: {
        wait: true
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (i18next__WEBPACK_IMPORTED_MODULE_0__["default"]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8942:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ MainContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_main_default_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7018);
/* harmony import */ var _api_main_brand__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1997);
/* harmony import */ var _api_main_product__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4391);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7508);
/* harmony import */ var _redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7169);
/* harmony import */ var _api_main_blog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9011);
/* harmony import */ var _redux_slices_viewed_notification__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4152);
/* harmony import */ var _api_main_user__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4827);
/* harmony import */ var _redux_slices_user__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9134);
/* harmony import */ var _services_auth__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4368);
/* harmony import */ var _redux_slices_settings__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5780);
/* harmony import */ var _api_main_shops__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1371);
/* harmony import */ var _redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3212);
/* harmony import */ var _redux_slices_category__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3725);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_main_default_settings__WEBPACK_IMPORTED_MODULE_3__, _services_auth__WEBPACK_IMPORTED_MODULE_13__]);
([_api_main_default_settings__WEBPACK_IMPORTED_MODULE_3__, _services_auth__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const MainContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
















const MainContextProvider = ({ children  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const productViewedIds = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.viewedProduct.viewedProductList).map((data)=>data.id);
    const productSavedIds = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.savedProduct.savedProductList).map((data)=>data.id);
    const shopIds = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.savedStore.savedStoreList).map((data)=>data.id);
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)();
    const { 0: theme , 1: setTheme  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(cookies.theme ? cookies.theme : "light");
    const { 0: currentCategory , 1: setCurrentCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: price_to , 1: setPriceTo  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: price_from , 1: setPriceFrom  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: category_id , 1: setCategoryId  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: sort , 1: setSort  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("asc");
    const { 0: content , 1: setContent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: layout , 1: setLayout  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("vertical");
    const { 0: shop , 1: setShop  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: priceLoader , 1: setPriceLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: address , 1: setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: currency , 1: setCurrency  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: language , 1: setLanguage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: brandList , 1: setBrandList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: isOpenDropdown , 1: setIsOpenDropdown  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: notificationList , 1: setNotificationList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: drawerTitle , 1: setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Drawer title");
    const { 0: lookId , 1: setLookId  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: checkoutAddress , 1: setCheckoutAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleDrawer = (key)=>{
        setIsOpen(key);
        setOpen(true);
        setContent(null);
    };
    const getBrand = (shop_id, perPage = 6, page = 1)=>{
        _api_main_brand__WEBPACK_IMPORTED_MODULE_4__/* .BrandApi.get */ .X.get({
            perPage,
            page,
            shop_id
        }).then((response)=>{
            setBrandList(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const checkProduct = ()=>{
        if (productSavedIds?.length) _api_main_product__WEBPACK_IMPORTED_MODULE_5__/* .ProductApi.checkIds */ .y.checkIds({
            products: productSavedIds
        }).then((res)=>{
            dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_8__/* .updateSaved */ .lj)(res.data));
            sessionStorage.setItem("checked", "true");
        }).catch((error)=>{
            console.log(error);
        });
    };
    const checkViewedProduct = ()=>{
        if (productViewedIds.length) _api_main_product__WEBPACK_IMPORTED_MODULE_5__/* .ProductApi.checkIds */ .y.checkIds({
            products: productViewedIds
        }).then((res)=>{
            dispatch((0,_redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_7__/* .updateViwed */ .qt)(res.data));
            sessionStorage.setItem("checked_viewed", "true");
        }).catch((error)=>{
            console.log(error);
        });
    };
    const checkShop = ()=>{
        _api_main_shops__WEBPACK_IMPORTED_MODULE_15__/* .ShopApi.checkIds */ .M.checkIds({
            shops: shopIds
        }).then((res)=>{
            dispatch((0,_redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_16__/* .updateSavedStore */ .nJ)(res.data));
            sessionStorage.setItem("checked_store", "true");
        }).catch((error)=>{
            console.log(error);
        });
    };
    const getNotification = ()=>{
        _api_main_blog__WEBPACK_IMPORTED_MODULE_9__/* .BlogApi.get */ .U.get({
            type: "notification",
            perPage: 5
        }).then((res)=>{
            setNotificationList(res.data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    const handleNotification = (value)=>{
        dispatch((0,_redux_slices_viewed_notification__WEBPACK_IMPORTED_MODULE_10__/* .addToViewed */ .OQ)(value));
    };
    const handleMarkAllNotification = (value)=>{
        dispatch((0,_redux_slices_viewed_notification__WEBPACK_IMPORTED_MODULE_10__/* .markAllList */ .vr)(value));
    };
    const getUser = ()=>{
        _api_main_user__WEBPACK_IMPORTED_MODULE_11__/* .UserApi.get */ .W.get().then((res)=>{
            dispatch((0,_redux_slices_user__WEBPACK_IMPORTED_MODULE_12__/* .savedUser */ .gW)(res.data));
            setAddress(res.data.addresses);
        }).catch((error)=>{
            console.log(error);
        });
    };
    const getTranslation = ()=>{
        _services_auth__WEBPACK_IMPORTED_MODULE_13__.serviceWithOutToken.get().then((res)=>{
            console.log(res);
        }).catch((error)=>{
            console.log(error);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const checked = sessionStorage.getItem("checked");
        const chacked_store = sessionStorage.getItem("checked_store");
        const checked_viewed = sessionStorage.getItem("checked_viewed");
        if (currency.length <= 0) (0,_api_main_default_settings__WEBPACK_IMPORTED_MODULE_3__/* .getCurrency */ .z)(setCurrency);
        if (language.length <= 0) (0,_api_main_default_settings__WEBPACK_IMPORTED_MODULE_3__/* .getLanguage */ .G)(setLanguage);
        if (notificationList?.length <= 0) getNotification();
        if (!checked && productSavedIds.length) checkProduct();
        if (!checked_viewed && productViewedIds.length) checkViewedProduct();
        if (!chacked_store && shopIds.length) checkShop();
        dispatch((0,_redux_slices_settings__WEBPACK_IMPORTED_MODULE_14__/* .getSettings */ .Gw)());
        dispatch((0,_redux_slices_category__WEBPACK_IMPORTED_MODULE_17__/* .getCategory */ .n3)());
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)();
        const body = document.getElementsByTagName("body");
        body[0].setAttribute("data-theme", theme);
        body[0].setAttribute("dir", cookies.dir);
    }, [
        theme
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(MainContext.Provider, {
        value: {
            isOpen,
            setIsOpen,
            open,
            setOpen,
            handleDrawer,
            theme,
            setTheme,
            layout,
            setLayout,
            content,
            setContent,
            currentCategory,
            setCurrentCategory,
            price_to,
            setPriceTo,
            price_from,
            setPriceFrom,
            sort,
            setSort,
            category_id,
            setCategoryId,
            shop,
            setShop,
            priceLoader,
            setPriceLoader,
            address,
            setAddress,
            currency,
            setCurrency,
            language,
            setLanguage,
            brandList,
            getBrand,
            isOpenDropdown,
            setIsOpenDropdown,
            notificationList,
            handleNotification,
            handleMarkAllNotification,
            getUser,
            getTranslation,
            drawerTitle,
            setDrawerTitle,
            checkProduct,
            checkViewedProduct,
            lookId,
            setLookId,
            getNotification,
            checkoutAddress,
            setCheckoutAddress
        },
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainContextProvider);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ setCurrency)
/* harmony export */ });
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_0__);

const setCurrency = (currency)=>{
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "currency_id", currency.id, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "currency_symbol", currency.symbol, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "currency_rate", currency.rate, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "currency_title", currency.title, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
};


/***/ }),

/***/ 6000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ setLanguage)
/* harmony export */ });
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_0__);

const setLanguage = (language)=>{
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "language_id", language.id, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
    (0,nookies__WEBPACK_IMPORTED_MODULE_0__.setCookie)(null, "language_locale", language.locale, {
        maxAge: 30 * 24 * 60 * 60,
        path: "/"
    });
};


/***/ })

};
;