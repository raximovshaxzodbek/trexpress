"use strict";
exports.id = 8826;
exports.ids = [8826];
exports.modules = {

/***/ 5770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ OrderApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class OrderApi {
    static endpoint = "/api/v1/dashboard/user/orders";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/paginate", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static create(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static createReview(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/review/${data.id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
    static statusChange(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/${id}/status/change`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, {
            status: "canceled"
        });
    }
}


/***/ }),

/***/ 8564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ PaymentApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class PaymentApi {
    static endpoint = "/api/v1/rest/payments";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
}


/***/ }),

/***/ 8250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ TransactionsApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class TransactionsApi {
    static endpoint = "/api/v1/payments/order/";
    static create(id, data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}${id}/transactions`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
}


/***/ }),

/***/ 3978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2929);
/* harmony import */ var _paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_main_transactions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8250);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3788);
/* harmony import */ var _redux_slices_order__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9611);





function PayPal({ createdOrderData , payment , setCheckoutContent , closeDrawer ,  }) {
    const dispatch = useDipsatch();
    if (!createdOrderData?.price) return "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_1__.PayPalScriptProvider, {
        options: {
            "client-id": payment?.client_id,
            currency: "USD"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_1__.PayPalButtons, {
            createOrder: (data, actions)=>{
                return actions.order.create({
                    purchase_units: [
                        {
                            amount: {
                                value: `${createdOrderData?.price}`
                            }
                        }, 
                    ]
                });
            },
            onApprove: (data, actions)=>{
                return actions.order.capture().then((details)=>{
                    _api_main_transactions__WEBPACK_IMPORTED_MODULE_2__/* .TransactionsApi.create */ .F.create(createdOrderData.id, {
                        payment_sys_id: payment.id
                    }).then(()=>{
                        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__/* .clearOrderShops */ .F)());
                        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_3__/* .clearCart */ .LL)());
                        dispatch((0,_redux_slices_order__WEBPACK_IMPORTED_MODULE_4__/* .clearOrder */ .bn)());
                        closeDrawer(false);
                        setCheckoutContent("status");
                    }).catch((error)=>{
                        console.log(error);
                    });
                });
            }
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PayPal);


/***/ }),

/***/ 6520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ getPrice)
/* harmony export */ });
/* unused harmony export commafy */
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_0__);

const commafy = (num)=>{
    var str = num.toString().split(".");
    if (str[0].length >= 5) {
        str[0] = str[0].replace(/(\d)(?=(\d{3})+$)/g, "$1,");
    }
    if (str[1] && str[1].length >= 5) {
        str[1] = str[1].replace(/(\d{3})/g, "$1 ");
    }
    return str.join(".");
};
const getPrice = (price = 0)=>{
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_0__.parseCookies)();
    if (price) {
        if (cookies.currency_symbol) {
            return `${decodeURI(cookies.currency_symbol)} ${commafy(price.toFixed(2))}`;
        } else {
            return `$ ${commafy(price.toFixed(2))}`;
        }
    } else return "0.00";
};


/***/ })

};
;