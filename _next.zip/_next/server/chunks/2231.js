"use strict";
exports.id = 2231;
exports.ids = [2231];
exports.modules = {

/***/ 2231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8782);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_2__);



const DiscordLoader = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_content_loader__WEBPACK_IMPORTED_MODULE_2___default()), {
        className: "discord-loader",
        height: 400,
        width: 700,
        ...props,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "30",
                rx: "5",
                ry: "5",
                width: "220",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "50",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "140",
                y: "50",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "240",
                y: "50",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "50",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "390",
                y: "50",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "450",
                y: "50",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "70",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "130",
                y: "70",
                rx: "5",
                ry: "5",
                width: "80",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "220",
                y: "70",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "70",
                rx: "5",
                ry: "5",
                width: "100",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "380",
                y: "70",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "440",
                y: "70",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "130",
                rx: "5",
                ry: "5",
                width: "220",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "150",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "140",
                y: "150",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "240",
                y: "150",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "150",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "390",
                y: "150",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "450",
                y: "150",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "170",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "130",
                y: "170",
                rx: "5",
                ry: "5",
                width: "80",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "220",
                y: "170",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "170",
                rx: "5",
                ry: "5",
                width: "100",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "380",
                y: "170",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "440",
                y: "170",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "230",
                rx: "5",
                ry: "5",
                width: "220",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "250",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "140",
                y: "250",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "240",
                y: "250",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "250",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "390",
                y: "250",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "450",
                y: "250",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "270",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "130",
                y: "270",
                rx: "5",
                ry: "5",
                width: "80",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "220",
                y: "270",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "270",
                rx: "5",
                ry: "5",
                width: "100",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "380",
                y: "270",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "440",
                y: "270",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "310",
                rx: "5",
                ry: "5",
                width: "220",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "330",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "140",
                y: "330",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "240",
                y: "330",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "330",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "390",
                y: "330",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "450",
                y: "330",
                rx: "5",
                ry: "5",
                width: "70",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "60",
                y: "350",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "130",
                y: "350",
                rx: "5",
                ry: "5",
                width: "80",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "220",
                y: "350",
                rx: "5",
                ry: "5",
                width: "90",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "320",
                y: "350",
                rx: "5",
                ry: "5",
                width: "100",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "380",
                y: "350",
                rx: "5",
                ry: "5",
                width: "50",
                height: "15"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "440",
                y: "350",
                rx: "5",
                ry: "5",
                width: "60",
                height: "15"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DiscordLoader);


/***/ })

};
;