"use strict";
(() => {
var exports = {};
exports.id = 8257;
exports.ids = [8257];
exports.modules = {

/***/ 6058:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_main_product__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4391);
/* harmony import */ var _components_empty_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1478);
/* harmony import */ var _components_products_section__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9253);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3181);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3006);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3304);
/* harmony import */ var _components_looks_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2637);
/* harmony import */ var _api_main_banner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8049);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_products_section__WEBPACK_IMPORTED_MODULE_5__, _components_looks_card__WEBPACK_IMPORTED_MODULE_10__]);
([_components_products_section__WEBPACK_IMPORTED_MODULE_5__, _components_looks_card__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const LookProduct = ({ lookProduct , setLoader , query  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const { 0: lookProductList , 1: setLookProductList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(lookProduct.data);
    const { 0: page , 1: setPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(2);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(lookProduct.meta?.total);
    const getLookProduct = (perPage = 12, page = 1)=>{
        _api_main_banner__WEBPACK_IMPORTED_MODULE_11__/* .BannerApi.get */ .b.get({
            perPage,
            page,
            shop_id: query.id,
            type: "look"
        }).then((response)=>{
            setTotal(response.meta.total);
            setLookProductList([
                ...lookProductList,
                ...response.data
            ]);
            setLoader(false);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const handlePaginate = ()=>{
        setLoader(true);
        getLookProduct(12, page);
        setPage(page + 1);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_seo__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "all-products",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        icon: false,
                        filter: false,
                        title: "All Looks",
                        sort: false,
                        children: [
                            lookProductList && lookProductList.map((product, key)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_looks_card__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    product: product
                                }, key);
                            }),
                            lookProductList?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_8__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the sale products"
                            })
                        ]
                    }),
                    total > lookProductList?.length && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        onClick: ()=>handlePaginate(page),
                        className: "see-more",
                        children: tl("Load more")
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { query  } = ctx;
    const cookies = nookies__WEBPACK_IMPORTED_MODULE_2___default().get(ctx);
    const language_locale = cookies?.language_locale;
    const resProduct = await _services_axios__WEBPACK_IMPORTED_MODULE_7__/* ["default"].get */ .Z.get(`/api/v1/rest/banners/paginate`, {
        params: {
            perPage: 12,
            page: 1,
            shop_id: query.id,
            lang: language_locale,
            type: "look"
        }
    });
    let lookProduct = resProduct.data;
    return {
        props: {
            lookProduct,
            query
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LookProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 1817:
/***/ ((module) => {

module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 4108:
/***/ ((module) => {

module.exports = require("react-modern-drawer");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5265:
/***/ ((module) => {

module.exports = require("remixicon-react/AddLineIcon");

/***/ }),

/***/ 97:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxBlankLineIcon");

/***/ }),

/***/ 266:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxFillIcon");

/***/ }),

/***/ 1060:
/***/ ((module) => {

module.exports = require("remixicon-react/CloseFillIcon");

/***/ }),

/***/ 2595:
/***/ ((module) => {

module.exports = require("remixicon-react/Filter3LineIcon");

/***/ }),

/***/ 6982:
/***/ ((module) => {

module.exports = require("remixicon-react/PauseFillIcon");

/***/ }),

/***/ 3132:
/***/ ((module) => {

module.exports = require("remixicon-react/SubtractLineIcon");

/***/ }),

/***/ 8288:
/***/ ((module) => {

module.exports = require("remixicon-react/ThumbUpLineIcon");

/***/ }),

/***/ 2021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,1664,3181,3304,2622,4527,8942,3006,7671,1478,9919,1323,9253,2637], () => (__webpack_exec__(6058)));
module.exports = __webpack_exports__;

})();