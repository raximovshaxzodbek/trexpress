(() => {
var exports = {};
exports.id = 9352;
exports.ids = [9352];
exports.modules = {

/***/ 4020:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_InformationLineIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2564);
/* harmony import */ var remixicon_react_InformationLineIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_InformationLineIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_TruckLineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4658);
/* harmony import */ var remixicon_react_TruckLineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_TruckLineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5225);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_StarLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(872);
/* harmony import */ var remixicon_react_StarLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StarLineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7821);
/* harmony import */ var _redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3212);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8942);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_9__]);
_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const LgBanner = ({ handleContent , data  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const savedStores = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.savedStore.savedStoreList);
    const savedStore = savedStores.find((store)=>store.id === data?.id);
    const { setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_9__/* .MainContext */ .T);
    const saved = ()=>{
        if (savedStore?.id === data?.id) {
            dispatch((0,_redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_7__/* .removeFromSaved */ .YH)(data));
        } else {
            dispatch((0,_redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_7__/* .addToSaved */ .IV)(data));
        }
    };
    const click = ({ title , key  })=>{
        setDrawerTitle(title);
        handleContent(key);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "banner-lg",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                className: "banner-lg-img",
                src: _constants__WEBPACK_IMPORTED_MODULE_6__/* .imgBaseUrl */ .XW + data.background_img,
                alt: "Baner"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "logo",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    src: _constants__WEBPACK_IMPORTED_MODULE_6__/* .imgBaseUrl */ .XW + data.logo_img
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "banner-lg-footer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "store-name",
                        children: data.translation?.title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "reaction",
                        onClick: ()=>click({
                                key: "store-info",
                                title: tl("Store info")
                            }),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_InformationLineIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                                size: 20
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Store info")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "reaction",
                        onClick: ()=>click({
                                key: "delivery-time",
                                title: tl("Delivery time")
                            }),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_TruckLineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                size: 20
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Delivery time")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "reaction",
                        onClick: saved,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                size: 20,
                                color: savedStore && "#61DC00"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Saved")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "reaction",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarLineIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                size: 20
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: data.rating_avg ? parseInt(data.rating_avg).toFixed(1) : "0.0"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LgBanner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 679:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3015);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7821);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _redux_slices_banner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1588);
/* harmony import */ var _loader_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(854);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_3__, swiper__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_3__, swiper__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const SmBanner = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const bannerList = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.banners.data.data);
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!bannerList?.length) {
            dispatch((0,_redux_slices_banner__WEBPACK_IMPORTED_MODULE_7__/* .getBanners */ .Ey)({
                params: {
                    perPage: 8,
                    page: 1,
                    active: 1,
                    type: "banner"
                }
            }));
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.Swiper, {
        spaceBetween: 17,
        slidesPerView: 3,
        breakpoints: {
            0: {
                slidesPerView: 1
            },
            360: {
                slidesPerView: 1.15
            },
            375: {
                slidesPerView: 1.2
            },
            412: {
                slidesPerView: 1.3
            },
            450: {
                slidesPerView: 1.5
            },
            550: {
                slidesPerView: 2
            },
            768: {
                slidesPerView: 2.5
            },
            945: {
                slidesPerView: 3
            }
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false
        },
        modules: [
            swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay
        ],
        children: bannerList ? bannerList?.map((banner, key)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                    href: `/banner/${banner.id}`,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        className: "sm-banner-wrapper",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "banner-sm",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                    src: _constants__WEBPACK_IMPORTED_MODULE_4__/* .imgBaseUrl */ .XW + banner.img,
                                    alt: "Banner"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "category",
                                    children: banner.translation?.title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "read-more",
                                    children: tl("see more")
                                })
                            ]
                        })
                    })
                })
            }, key);
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_loader_image__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_loader_image__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_loader_image__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SmBanner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3006);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9054);




const LookBanner = ()=>{
    const windowSize = (0,_utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "look-banner",
        children: windowSize.width > 412 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
            src: _constants_images__WEBPACK_IMPORTED_MODULE_2__/* .images.Look */ .Wc.Look,
            alt: "look banner"
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    src: _constants_images__WEBPACK_IMPORTED_MODULE_2__/* .images.LookMobile */ .Wc.LookMobile,
                    alt: "look banner"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "banner-content",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "title",
                            children: "BEST LOOK"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "description",
                            children: "If you have comments, questions, or issues, our Guides"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LookBanner);


/***/ }),

/***/ 8848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_getImg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7603);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);





const BrandCard = ({ brand  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: `/stores/all-brand/${brand?.id}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
            className: "brand-card",
            children: brand.img ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                src: (0,_utils_getImg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(brand.img),
                alt: "Logo"
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "no-image",
                children: tl("No image")
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandCard);


/***/ }),

/***/ 854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8782);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_2__);



const ImageLoader = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        style: {
            marginBottom: "14px"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_content_loader__WEBPACK_IMPORTED_MODULE_2___default()), {
            speed: 1,
            width: "100%",
            height: 230,
            viewBox: "0 0 100% 230",
            backgroundColor: "#ffffff",
            foregroundColor: "#ededed",
            ...props,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "0",
                y: "0",
                rx: "15",
                ry: "15",
                width: "100%",
                height: "230"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageLoader);


/***/ }),

/***/ 2984:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ delivery_time)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-calendar"
const external_react_calendar_namespaceObject = require("react-calendar");
var external_react_calendar_default = /*#__PURE__*/__webpack_require__.n(external_react_calendar_namespaceObject);
// EXTERNAL MODULE: ./node_modules/react-calendar/dist/Calendar.css
var Calendar = __webpack_require__(8434);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./components/stores/delivery-time.js





function DeliveryTime({ storeDetail  }) {
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const { 0: value , 1: onChange  } = (0,external_react_.useState)(new Date());
    const getDeliveryTime = ()=>{
        const timeArray = [];
        let start = parseInt(storeDetail?.open_time?.slice(0, 2));
        let end = parseInt(storeDetail?.close_time?.slice(0, 2));
        for(start; start <= end; start++){
            timeArray.push({
                id: `${start}:00`,
                value: `${tl("up to")} ${start}:00`
            });
        }
        return timeArray;
    };
    const timeArray = getDeliveryTime();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "delivery-time",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)((external_react_calendar_default()), {
                onChange: onChange,
                value: value
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "delivery-date-wrapper",
                children: timeArray?.map((item, key)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "delivery-date",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "month",
                                children: value.toString()?.slice(0, 15)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "time",
                                children: item.value
                            })
                        ]
                    }, key);
                })
            })
        ]
    });
}
/* harmony default export */ const delivery_time = (DeliveryTime);


/***/ }),

/***/ 6887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6487);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6419);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_rating__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _form_msg_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7317);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_6__);







const StoreRate = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "store-rate",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "content",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "left",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_msg_input__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "add-rate",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "comment",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                                placeholder: "Full name"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "add-rating",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_rating__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                className: "rating-star",
                                                initialRating: 0,
                                                emptySymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {}),
                                                fullSymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    color: "#FFB800"
                                                }),
                                                onClick: (value)=>console.log(value)
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "right",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "rate-slider",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: "5"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            onChange: (value)=>console.log(value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "rate-slider",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: "4"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            onChange: (value)=>console.log(value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "rate-slider",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: "3"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            onChange: (value)=>console.log(value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "rate-slider",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: "2"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            onChange: (value)=>console.log(value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "rate-slider",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "label",
                                            children: "1"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            onChange: (value)=>console.log(value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "final-rate",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_rating__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            className: "rating-star",
                                            initialRating: 0,
                                            emptySymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {}),
                                            fullSymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                color: "#FFB800"
                                            }),
                                            onClick: (value)=>console.log(value)
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: "4.0 out of 5.0"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "btn-group",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "btn-dark",
                        children: tl("Send")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "btn-default",
                        children: tl("Clear")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoreRate);


/***/ }),

/***/ 2415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ store_info)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "remixicon-react/MapPin2FillIcon"
const MapPin2FillIcon_namespaceObject = require("remixicon-react/MapPin2FillIcon");
var MapPin2FillIcon_default = /*#__PURE__*/__webpack_require__.n(MapPin2FillIcon_namespaceObject);
// EXTERNAL MODULE: external "remixicon-react/TimeFillIcon"
var TimeFillIcon_ = __webpack_require__(3718);
var TimeFillIcon_default = /*#__PURE__*/__webpack_require__.n(TimeFillIcon_);
;// CONCATENATED MODULE: external "remixicon-react/ServiceFillIcon"
const ServiceFillIcon_namespaceObject = require("remixicon-react/ServiceFillIcon");
var ServiceFillIcon_default = /*#__PURE__*/__webpack_require__.n(ServiceFillIcon_namespaceObject);
;// CONCATENATED MODULE: external "remixicon-react/RoadMapFillIcon"
const RoadMapFillIcon_namespaceObject = require("remixicon-react/RoadMapFillIcon");
var RoadMapFillIcon_default = /*#__PURE__*/__webpack_require__.n(RoadMapFillIcon_namespaceObject);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./components/stores/store-info.js








function StoreInfo() {
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const shop = (0,external_react_redux_.useSelector)((state)=>state.savedStore.currentStore);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "store-info",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "info-item",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "icon",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((MapPin2FillIcon_default()), {
                            size: 20
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "title",
                                children: shop?.translation?.title
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "description",
                                children: shop?.translation?.address
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "info-item",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "icon",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((TimeFillIcon_default()), {
                            size: 20
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "title",
                                children: `${shop.open_time} — ${shop.close_time}`
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "description",
                                children: tl("Working hours")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "info-item",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "icon",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((ServiceFillIcon_default()), {
                            size: 20
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "title",
                                children: tl("Delivery \u2014 Pick up")
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "description",
                                children: tl("Delivery type")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "info-item",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "icon",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)((RoadMapFillIcon_default()), {
                            size: 20
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "title",
                                children: `${shop?.delivery_range} km`
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "description",
                                children: tl("Delivery range")
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const store_info = (StoreInfo);


/***/ }),

/***/ 2200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_banner_banner_lg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4020);
/* harmony import */ var _components_banner_banner_sm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(679);
/* harmony import */ var _components_products_section__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9253);
/* harmony import */ var _components_products_card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9237);
/* harmony import */ var _components_brands_card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8848);
/* harmony import */ var _components_drawer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7671);
/* harmony import */ var _components_stores_rate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6887);
/* harmony import */ var _components_stores_delivery_time__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2984);
/* harmony import */ var _components_stores_store_info__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2415);
/* harmony import */ var _api_main_brand__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1997);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3181);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_empty_data__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1478);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3006);
/* harmony import */ var _api_main_product__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4391);
/* harmony import */ var _components_loader_product__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6634);
/* harmony import */ var _components_products_horizontal__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4150);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3304);
/* harmony import */ var _components_banner_mega_sale__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8190);
/* harmony import */ var _components_looks_card__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(2637);
/* harmony import */ var _api_main_banner__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8049);
/* harmony import */ var _components_banner_look__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_banner_banner_lg__WEBPACK_IMPORTED_MODULE_3__, _components_banner_banner_sm__WEBPACK_IMPORTED_MODULE_4__, _components_products_section__WEBPACK_IMPORTED_MODULE_5__, _components_drawer__WEBPACK_IMPORTED_MODULE_8__, _components_looks_card__WEBPACK_IMPORTED_MODULE_22__]);
([_components_banner_banner_lg__WEBPACK_IMPORTED_MODULE_3__, _components_banner_banner_sm__WEBPACK_IMPORTED_MODULE_4__, _components_products_section__WEBPACK_IMPORTED_MODULE_5__, _components_drawer__WEBPACK_IMPORTED_MODULE_8__, _components_looks_card__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

























const Store = ({ storeDetail  })=>{
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: content , 1: setContent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: brandList , 1: setBrandList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: lookProduct , 1: setLookProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: discountList , 1: setDiscountList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: mostSales , 1: setMostSales  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: news , 1: setNews  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const viewedProduct = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.viewedProduct.viewedProductList);
    const handleContent = (key)=>{
        setContent(key);
        setOpen(true);
    };
    const getBrand = (perPage = 6, page = 1)=>{
        _api_main_brand__WEBPACK_IMPORTED_MODULE_12__/* .BrandApi.get */ .X.get({
            perPage,
            page,
            shop_id: storeDetail.id
        }).then((response)=>{
            setBrandList(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const getBanner = (perPage = 4, page = 1)=>{
        _api_main_banner__WEBPACK_IMPORTED_MODULE_23__/* .BannerApi.get */ .b.get({
            perPage,
            page,
            shop_id: storeDetail.id,
            type: "look"
        }).then((response)=>{
            setLookProduct(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const getDiscountProduct = (perPage = 4, page = 1)=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_17__/* .ProductApi.getDiscount */ .y.getDiscount({
            perPage,
            page,
            shop_id: storeDetail.id
        }).then((response)=>{
            setDiscountList(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const getMostSales = (perPage = 4, page = 1)=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_17__/* .ProductApi.getMostSales */ .y.getMostSales({
            perPage,
            page,
            shop_id: storeDetail.id
        }).then((response)=>{
            setMostSales(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const getNews = (perPage = 3, page = 1)=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_17__/* .ProductApi.get */ .y.get({
            perPage,
            page,
            shop_id: storeDetail.id,
            sort: "desc",
            column: "created_at"
        }).then((response)=>{
            setNews(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getBrand();
        getDiscountProduct();
        getMostSales();
        getNews();
        getBanner();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_seo__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                title: storeDetail?.translation?.title,
                description: storeDetail?.translation?.description,
                keywords: storeDetail?.translation?.description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "store",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_banner_banner_lg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        handleContent: handleContent,
                        data: storeDetail
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_banner_banner_sm__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "New products",
                        href: `/stores/${storeDetail.id}/news`,
                        children: [
                            news ? news.map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_horizontal__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                    product: product
                                }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                ]
                            }),
                            news?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the news products"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_banner_mega_sale__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "Top sales",
                        href: `/stores/${storeDetail.id}/top-sales`,
                        children: [
                            mostSales ? mostSales.slice(0, 8).map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_card__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    product: product
                                }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                ]
                            }),
                            mostSales?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the viewed products",
                                text2: "To select items, go to the stores"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        icon: true,
                        title: "Discount",
                        href: `/stores/${storeDetail.id}/sales`,
                        children: [
                            discountList ? discountList.map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_card__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    product: product
                                }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                ]
                            }),
                            discountList?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the sale products"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "Lookbooks",
                        href: `/stores/${storeDetail.id}/look-product`,
                        className: "look-product-section",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_banner_look__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {}),
                            lookProduct?.length > 0 ? lookProduct.map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_looks_card__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                    product: product
                                }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the look products",
                                text2: "To select items, go to the stores"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "Viewed products",
                        href: "/stores/viewed-product",
                        children: viewedProduct.length > 0 ? viewedProduct.slice(0, 4).map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_card__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                product: product
                            }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                            text1: "There are no items in the viewed products",
                            text2: "To select items, go to the stores"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        icon: false,
                        title: "Brands",
                        href: "/stores/all-brand",
                        children: [
                            brandList ? brandList.map((brand, key)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_brands_card__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    brand: brand
                                }, key);
                            }) : "",
                            brandList?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_16__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the brand"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_drawer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        title: "Rating store",
                        open: open,
                        setOpen: setOpen,
                        children: [
                            content === "store-rate" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_stores_rate__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                            content === "delivery-time" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_stores_delivery_time__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                storeDetail: storeDetail
                            }),
                            content === "store-info" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_stores_store_info__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { query  } = ctx;
    const cookies = nookies__WEBPACK_IMPORTED_MODULE_2___default().get(ctx);
    const currency_id = cookies?.currency_id;
    const language_id = cookies?.language_id;
    const language_locale = cookies?.language_locale;
    const resStore = await _services_axios__WEBPACK_IMPORTED_MODULE_13__/* ["default"].get */ .Z.get(`/api/v1/rest/shops/${query.id}`, {
        params: {
            perPage: 0,
            page: 1,
            currency_id,
            language_id,
            lang: language_locale
        }
    });
    let storeDetail = resStore.data.data;
    return {
        props: {
            storeDetail
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8434:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 3612:
/***/ ((module) => {

"use strict";
module.exports = require("autosize");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 7104:
/***/ ((module) => {

"use strict";
module.exports = require("qs");

/***/ }),

/***/ 1817:
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

"use strict";
module.exports = require("react-content-loader");

/***/ }),

/***/ 9709:
/***/ ((module) => {

"use strict";
module.exports = require("react-i18next");

/***/ }),

/***/ 4108:
/***/ ((module) => {

"use strict";
module.exports = require("react-modern-drawer");

/***/ }),

/***/ 6419:
/***/ ((module) => {

"use strict";
module.exports = require("react-rating");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5265:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/AddLineIcon");

/***/ }),

/***/ 5225:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Bookmark3LineIcon");

/***/ }),

/***/ 8710:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Chat1FillIcon");

/***/ }),

/***/ 97:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CheckboxBlankLineIcon");

/***/ }),

/***/ 266:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CheckboxFillIcon");

/***/ }),

/***/ 1060:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CloseFillIcon");

/***/ }),

/***/ 2595:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Filter3LineIcon");

/***/ }),

/***/ 1257:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Heart3FillIcon");

/***/ }),

/***/ 9348:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Heart3LineIcon");

/***/ }),

/***/ 6582:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/HeartLineIcon");

/***/ }),

/***/ 2564:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/InformationLineIcon");

/***/ }),

/***/ 6982:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/PauseFillIcon");

/***/ }),

/***/ 8244:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/StarFillIcon");

/***/ }),

/***/ 872:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/StarLineIcon");

/***/ }),

/***/ 6487:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/StarSmileFillIcon");

/***/ }),

/***/ 3132:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/SubtractLineIcon");

/***/ }),

/***/ 8288:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ThumbUpLineIcon");

/***/ }),

/***/ 3718:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/TimeFillIcon");

/***/ }),

/***/ 2923:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/TimeLineIcon");

/***/ }),

/***/ 4658:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/TruckLineIcon");

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,1664,3181,3304,2622,4527,8942,3006,7671,1478,9919,1323,9253,9237,4150,9054,6634,7317,1397,2637], () => (__webpack_exec__(2200)));
module.exports = __webpack_exports__;

})();