"use strict";
(() => {
var exports = {};
exports.id = 278;
exports.ids = [278];
exports.modules = {

/***/ 8848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_getImg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7603);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_4__);





const BrandCard = ({ brand  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: `/stores/all-brand/${brand?.id}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
            className: "brand-card",
            children: brand.img ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                src: (0,_utils_getImg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(brand.img),
                alt: "Logo"
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "no-image",
                children: tl("No image")
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandCard);


/***/ }),

/***/ 8589:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_main_brand__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1997);
/* harmony import */ var _components_brands_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8848);
/* harmony import */ var _components_empty_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1478);
/* harmony import */ var _components_products_section__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9253);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3006);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3181);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3304);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_products_section__WEBPACK_IMPORTED_MODULE_6__]);
_components_products_section__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const AllBrand = ({ setLoader , data  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const { 0: brandList , 1: setBrandList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data.data);
    const { 0: page , 1: setPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(2);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(data.meta.total);
    const getBrand = (perPage = 12, page = 1, sort = "asc")=>{
        _api_main_brand__WEBPACK_IMPORTED_MODULE_3__/* .BrandApi.get */ .X.get({
            perPage,
            page,
            sort
        }).then((response)=>{
            setTotal(response.meta.total);
            setBrandList([
                ...brandList,
                ...response.data
            ]);
            setLoader(false);
        }).catch((error)=>{
            console.error(error);
        });
    };
    const handlePaginate = ()=>{
        setLoader(true);
        getBrand(12, page);
        setPage(page + 1);
    };
    const handleSort = (sort)=>{
        setLoader(true);
        _api_main_brand__WEBPACK_IMPORTED_MODULE_3__/* .BrandApi.get */ .X.get({
            perPage: 12,
            page: 1,
            sort
        }).then((response)=>{
            setLoader(false);
            setBrandList(response.data);
        }).catch((error)=>{
            console.error(error);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_seo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "all-brand",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        handleSort: handleSort,
                        total: total,
                        title: "All Brands",
                        sort: brandList?.length ? true : false,
                        children: [
                            brandList ? brandList.map((brand, key)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_brands_card__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    brand: brand
                                }, key);
                            }) : "",
                            brandList?.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                image: _constants_images__WEBPACK_IMPORTED_MODULE_7__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                text1: "There are no items in the brand"
                            })
                        ]
                    }),
                    total / 12 >= page && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        onClick: ()=>handlePaginate(page),
                        className: "see-more",
                        children: tl("Load more")
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const cookies = nookies__WEBPACK_IMPORTED_MODULE_2___default().get(ctx);
    const language_id = cookies?.language_id;
    const language_locale = cookies?.language_locale;
    const res = await _services_axios__WEBPACK_IMPORTED_MODULE_8__/* ["default"].get */ .Z.get("/api/v1/rest/brands/paginate", {
        params: {
            perPage: 12,
            page: 1,
            language_id,
            lang: language_locale
        }
    });
    const data = await res.data;
    return {
        props: {
            data
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllBrand);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7821);

const getImg = (src)=>{
    return _constants__WEBPACK_IMPORTED_MODULE_0__/* .imgBaseUrl */ .XW + src;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getImg);


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 1817:
/***/ ((module) => {

module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 4108:
/***/ ((module) => {

module.exports = require("react-modern-drawer");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5265:
/***/ ((module) => {

module.exports = require("remixicon-react/AddLineIcon");

/***/ }),

/***/ 97:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxBlankLineIcon");

/***/ }),

/***/ 266:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxFillIcon");

/***/ }),

/***/ 1060:
/***/ ((module) => {

module.exports = require("remixicon-react/CloseFillIcon");

/***/ }),

/***/ 2595:
/***/ ((module) => {

module.exports = require("remixicon-react/Filter3LineIcon");

/***/ }),

/***/ 6982:
/***/ ((module) => {

module.exports = require("remixicon-react/PauseFillIcon");

/***/ }),

/***/ 3132:
/***/ ((module) => {

module.exports = require("remixicon-react/SubtractLineIcon");

/***/ }),

/***/ 2021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,1664,3181,3304,2622,4527,8942,3006,7671,1478,9919,1323,9253], () => (__webpack_exec__(8589)));
module.exports = __webpack_exports__;

})();