"use strict";
(() => {
var exports = {};
exports.id = 7931;
exports.ids = [7931];
exports.modules = {

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 1235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const stripe = __webpack_require__(8174)("sk_test_51LaGXyLrMlc0ddAAFGTcyYkpVuaASL6XyY0djSEbnbhjFmaD51n1SL7hakh7UkjubMnykJ1wrH15QfbEWN7byuIG00kMcA2yxg");
async function CreateStripeSession(req, res) {
    let { amount , order_id  } = req.body;
    const paymentIntent = await stripe.paymentIntents.create({
        amount: parseFloat(amount.toFixed(2)) * 100,
        currency: "usd",
        payment_method_types: [
            "card"
        ],
        metadata: {
            order_id: order_id
        }
    });
    res.json({
        paymentIntent: paymentIntent
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateStripeSession);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1235));
module.exports = __webpack_exports__;

})();