"use strict";
(() => {
var exports = {};
exports.id = 9299;
exports.ids = [9299];
exports.modules = {

/***/ 4871:
/***/ ((module) => {

module.exports = require("razorpay");

/***/ }),

/***/ 3918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const Razorpay = __webpack_require__(4871);
async function CreateRazorpayOrder(req, res) {
    const { amount  } = req.body;
    let instance = new Razorpay({
        key_id: "rzp_test_TMPwvQpYGAIMbU",
        key_secret: "npv8RgJl8tOaVbEvUBm3oFzM"
    });
    const order = await instance.orders.create({
        amount: parseFloat(amount.toFixed(2)) * 100,
        currency: "INR",
        receipt: "receipt#1",
        notes: {
            key1: "value3",
            key2: "value2"
        }
    });
    res.json({
        order: order
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateRazorpayOrder);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3918));
module.exports = __webpack_exports__;

})();