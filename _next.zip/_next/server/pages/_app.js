(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 8049:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ BannerApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class BannerApi {
    static endpoint = "/api/v1/rest/banners";
    static get(params) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + "/paginate", _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET, null, null, params);
    }
    static getId(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static getProduct(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}/products`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].GET */ .ZP.GET);
    }
    static liked(id) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint + `/${id}/liked`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST);
    }
}


/***/ }),

/***/ 1226:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8942);
/* harmony import */ var _utils_hooks_useClickOutside__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8237);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9054);
/* harmony import */ var _search_filter_vertical_helper_laptop_category__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5827);
/* harmony import */ var _search_filter_vertical_helper_mobile_category__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5622);
/* harmony import */ var remixicon_react_LayoutGridLineIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9090);
/* harmony import */ var remixicon_react_LayoutGridLineIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LayoutGridLineIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__, _utils_hooks_useClickOutside__WEBPACK_IMPORTED_MODULE_3__, _search_filter_vertical_helper_laptop_category__WEBPACK_IMPORTED_MODULE_5__, _search_filter_vertical_helper_mobile_category__WEBPACK_IMPORTED_MODULE_6__]);
([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__, _utils_hooks_useClickOutside__WEBPACK_IMPORTED_MODULE_3__, _search_filter_vertical_helper_laptop_category__WEBPACK_IMPORTED_MODULE_5__, _search_filter_vertical_helper_mobile_category__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Category = ()=>{
    const { t: tl  } = useTranslation();
    const windowSize = useWindowSize();
    const { isOpenDropdown , setIsOpenDropdown  } = useContext(MainContext);
    return /*#__PURE__*/ _jsxs("div", {
        className: "category-wrapper",
        children: [
            /*#__PURE__*/ _jsxs("button", {
                onClick: ()=>setIsOpenDropdown(true),
                children: [
                    /*#__PURE__*/ _jsx(LayoutGridLineIcon, {
                        size: 20
                    }),
                    tl("All")
                ]
            }),
            /*#__PURE__*/ _jsx(OutsideAlerter, {
                children: /*#__PURE__*/ _jsx("div", {
                    className: `category-content-wrapper ${isOpenDropdown ? "visible" : ""}`,
                    children: windowSize?.width > 540 ? /*#__PURE__*/ _jsx(LaptopCategory, {}) : /*#__PURE__*/ _jsx(MobileCategory, {})
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Category)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Channel)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "moment"
var external_moment_ = __webpack_require__(2245);
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./components/chat/chat-date.js




const ChatDate = ({ date  })=>{
    const isCurrentDay = external_moment_default()(date, "DD-MM-YYYY").isSame(external_moment_default()(), "day");
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
        className: "chat-date",
        "data-date": isCurrentDay ? tl("Today") : external_moment_default()(date, "DD-MM-YYYY").format("D MMM")
    });
};
/* harmony default export */ const chat_date = (ChatDate);

;// CONCATENATED MODULE: ./components/chat/admin-message.js



const AdminMessage = ({ text , time  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
        className: "admin-message-wrapper",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "admin-message",
            children: [
                text,
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "time",
                    children: external_moment_default()(new Date(time)).format("HH:mm")
                })
            ]
        })
    });
};
/* harmony default export */ const admin_message = (AdminMessage);

// EXTERNAL MODULE: external "remixicon-react/CheckDoubleLineIcon"
var CheckDoubleLineIcon_ = __webpack_require__(991);
var CheckDoubleLineIcon_default = /*#__PURE__*/__webpack_require__.n(CheckDoubleLineIcon_);
;// CONCATENATED MODULE: ./components/chat/user-message.js




const UserMessage = ({ text , time , status =""  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
        className: "user-sms-wrapper",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "user-message",
            children: [
                text,
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "time",
                    children: external_moment_default()(new Date(time)).format("HH:mm")
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                    className: "double-check",
                    children: status === "pending" ? "" : /*#__PURE__*/ (0,jsx_runtime_.jsx)((CheckDoubleLineIcon_default()), {
                        size: 16
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const user_message = (UserMessage);

;// CONCATENATED MODULE: ./components/chat/channel.js





function Channel({ groupMessages , messageEndRef  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "chat-box",
        children: [
            groupMessages.map((item, key)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        item.date !== "Invalid date" ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(chat_date, {
                            date: item.date
                        }) : "",
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "sms-box",
                            children: item.messages.map((item)=>Boolean(item.sender) ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(user_message, {
                                    text: item.chat_content,
                                    time: item.created_at,
                                    status: item.status
                                }, item.id) : /*#__PURE__*/ (0,jsx_runtime_.jsx)(admin_message, {
                                    text: item.chat_content,
                                    time: item.created_at
                                }, item.id))
                        })
                    ]
                }, key)),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                ref: messageEndRef
            })
        ]
    });
};


/***/ }),

/***/ 1434:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Chat)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1380);
/* harmony import */ var _chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _channel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1341);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _redux_slices_chat__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9689);
/* harmony import */ var _services_firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6813);
/* harmony import */ var _utils_scrollTo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6198);
/* harmony import */ var _utils_getMessages__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8953);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_firebase__WEBPACK_IMPORTED_MODULE_6__]);
_services_firebase__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function Chat({ windowSize  }) {
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const messageEndRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { chats , currentChat , newMessage  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.chat, react_redux__WEBPACK_IMPORTED_MODULE_4__.shallowEqual);
    const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.data, react_redux__WEBPACK_IMPORTED_MODULE_4__.shallowEqual);
    const groupMessages = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>(0,_utils_getMessages__WEBPACK_IMPORTED_MODULE_8__/* .getMessages */ ._)(state.chat), react_redux__WEBPACK_IMPORTED_MODULE_4__.shallowEqual);
    const myChat = chats.find((item)=>item?.user?.id == user.id);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }, [
        inputRef,
        currentChat
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (user && chats) {
            if (myChat) {
                dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_5__/* .setCurrentChat */ .eb)(myChat));
            } else {
                (0,_services_firebase__WEBPACK_IMPORTED_MODULE_6__/* .createChat */ .P4)({
                    shop_id: -1,
                    user: {
                        id: user.id,
                        firstname: user.firstname,
                        lastname: user.lastname,
                        img: user.img
                    }
                });
            }
        }
    }, [
        myChat
    ]);
    const handleOnChange = (value)=>{
        dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_5__/* .setNewMessage */ .zR)(value));
    };
    const handleOnSubmit = ()=>{
        const trimmedMessage = newMessage.replace(/\&nbsp;/g, "").replace(/<[^>]+>/g, "").trim();
        const payload = {
            chat_content: trimmedMessage,
            chat_id: currentChat?.id,
            sender: 1,
            unread: true
        };
        if (trimmedMessage) {
            (0,_services_firebase__WEBPACK_IMPORTED_MODULE_6__/* .sendMessage */ .bG)(payload);
            dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_5__/* .setNewMessage */ .zR)(""));
            dispatch((0,_redux_slices_chat__WEBPACK_IMPORTED_MODULE_5__/* .addMessage */ .Hz)({
                ...payload,
                status: "pending"
            }));
            const topPosition = messageEndRef.current.offsetTop;
            const container = document.querySelector(".message-list .scrollbar-container");
            (0,_utils_scrollTo__WEBPACK_IMPORTED_MODULE_7__/* .scrollTo */ .X)(container, topPosition - 30, 600);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        style: {
            height: windowSize.width > 768 ? "100vh" : "90vh"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__.MainContainer, {
            responsive: true,
            className: "chat-container rounded",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__.ChatContainer, {
                className: "chat-container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__.MessageList, {
                        className: "message-list",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_channel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            groupMessages: groupMessages,
                            messageEndRef: messageEndRef
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_chatscope_chat_ui_kit_react__WEBPACK_IMPORTED_MODULE_2__.MessageInput, {
                        ref: inputRef,
                        value: newMessage,
                        onChange: handleOnChange,
                        onSend: handleOnSubmit,
                        placeholder: tl("Message"),
                        className: "chat-input",
                        attachButton: false
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./utils/hooks/useWindowSize.js
var useWindowSize = __webpack_require__(9054);
// EXTERNAL MODULE: ./components/accordion/index.js
var components_accordion = __webpack_require__(7952);
// EXTERNAL MODULE: ./components/accordion/accordion-details.js
var accordion_details = __webpack_require__(4021);
// EXTERNAL MODULE: ./components/accordion/accordion-summary.js
var accordion_summary = __webpack_require__(6694);
// EXTERNAL MODULE: ./components/loader/category.js
var category = __webpack_require__(9919);
;// CONCATENATED MODULE: ./components/footer/UpFooter.js


const someArr = new Array(14).fill(0).map((el, index)=>{
    if (index % 2 === 0) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
            children: "Lorem ipsum"
        });
    } else return /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
        children: "Lorem"
    });
});
const firstCol = [
    someArr
];
const secondCol = [
    someArr
];
const thirdCol = [
    someArr
];
const fourCol = [
    someArr
];
const fifthCol = [
    someArr
];
const UpFooter = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mainUpFooter",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                            children: "Popular brands, stores and products"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "upFooter",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upFooterItem",
                            children: firstCol
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upFooterItem",
                            children: secondCol
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upFooterItem",
                            children: thirdCol
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upFooterItem",
                            children: fourCol
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upFooterItem",
                            children: fifthCol
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./public/assets/icons/playMarket.png
/* harmony default export */ const playMarket = ({"src":"/_next/static/media/playMarket.28e0cc41.png","height":2000,"width":3000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAXUlEQVR42mOAg9M94gzYgOi+RywgWmnnh+kMl3YeYfglqM+AAo79Z2EAgVP/Zzlvf/v/7jbv//9vMniDhP6d42BmqN58H6wg+ND76UfqVh/5z8Cgz4ANXPbNx+oGAPK6IS0JNgWQAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/icons/appleStoreLogo.png
/* harmony default export */ const appleStoreLogo = ({"src":"/_next/static/media/appleStoreLogo.4341456d.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAUUlEQVR42i3KsQ1AQABA0XdcdGozKIyhtgWV0iIqG9hAbwKzaDUnuVz+z68+EFVoAALYtKiyRqvTLAKDlHkAJskrORCh85WnhxqL22VHoAQQfuXcENejAWKIAAAAAElFTkSuQmCC"});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/footer/index.js














const Footer = ()=>{
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const windowSize = (0,useWindowSize/* default */.Z)();
    const settings = (0,external_react_redux_.useSelector)((state)=>state.settings.data);
    const { 0: idList , 1: setIdList  } = (0,external_react_.useState)([]);
    const handleClick = (key)=>{
        const includes = idList.includes(key);
        if (includes) {
            setIdList(idList.filter((item)=>item !== key));
        } else {
            setIdList([
                ...idList,
                key
            ]);
        }
    };
    const accordion = [];
    new Array(6).fill("Lorem ipsum").forEach((el, index)=>accordion.push(/*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_details/* default */.Z, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                href: settings[""],
                target: "_blank",
                children: el
            }, index)
        })));
    const makeColumns = (num)=>{
        return new Array(num).fill("Lorem").map((el, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    href: "/",
                    target: "_blank",
                    children: el
                })
            }, index));
    };
    const firstCol = makeColumns(6);
    const secondCol = makeColumns(4);
    const thirdCol = makeColumns(5);
    const fourCol = makeColumns(4);
    const fifthCol = makeColumns(8);
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "footer",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(UpFooter, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "allUnderFooter",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                            className: "upperFooter",
                            children: windowSize.width > 768 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "footerCols",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                className: "title",
                                                children: "Safin24"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                                style: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    height: 200
                                                },
                                                children: firstCol
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                className: "title",
                                                children: "About us"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                                style: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    height: 200
                                                },
                                                children: secondCol
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                className: "title",
                                                children: "Social Media"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                                style: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    height: 200
                                                },
                                                children: thirdCol
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                className: "title",
                                                children: "Lorem Ipsum"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                                style: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    height: 200
                                                },
                                                children: fourCol
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("h1", {
                                                className: "title",
                                                children: "Help"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                                                style: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    height: 200
                                                },
                                                children: fifthCol
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(components_accordion/* default */.Z, {
                                id: "",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(accordion_summary/* default */.Z, {
                                        children: "Lorem"
                                    }),
                                    accordion
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "footerDown",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "secOne",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "store",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                                    src: appleStoreLogo,
                                                    alt: "Picture of the author",
                                                    width: 30,
                                                    height: 30
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    href: "https://www.apple.com/ru/app-store/",
                                                    target: "_blank",
                                                    className: "hrefPlayMarketAppStore",
                                                    children: [
                                                        "\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0432 ",
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("strong", {
                                                            children: "App Store"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "store",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)((image_default()), {
                                                    src: playMarket,
                                                    alt: "Picture of the author",
                                                    width: 40,
                                                    height: 30
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    href: "https://play.google.com/store/games?hl=ru&gl=US&pli=1",
                                                    target: "_blank",
                                                    className: "hrefPlayMarketAppStore",
                                                    children: [
                                                        "\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0432 ",
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("br", {}),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("strong", {
                                                            children: "Play Market"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "secTwo",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                            children: "\xa9 2023 Eezy Inc. All rights reserved"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                            children: "| Terms of Use | Privacy and Policy"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const footer = (Footer);


/***/ }),

/***/ 1536:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_SendPlaneLineIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3455);
/* harmony import */ var remixicon_react_SendPlaneLineIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_SendPlaneLineIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_ArrowDownSLineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4237);
/* harmony import */ var remixicon_react_ArrowDownSLineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ArrowDownSLineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5265);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_CheckDoubleLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(991);
/* harmony import */ var remixicon_react_CheckDoubleLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_CheckDoubleLineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8942);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2045);
/* harmony import */ var _utils_getLocation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2150);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_6__, _utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_8__]);
([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_6__, _utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const SelectAddress = ({ setOpen =()=>{}  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_10__.parseCookies)();
    const { isOpen , setIsOpen , handleDrawer , address , getUser , setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_6__/* .MainContext */ .T);
    const { setUserDefaultLocation , userLocation  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_8__/* .AuthContext */ .Vo);
    const { 0: defaultAddress , 1: setDefaultAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const newUserLocation = userLocation?.split(",");
    const cuurentAddress = address?.find((item)=>item.location.latitude === newUserLocation[0] || item.location.longitude === newUserLocation[1]);
    const click = ()=>{
        setDrawerTitle("Enter a delivery address");
        setIsOpen("enter-address");
    };
    const handleAddress = (e, item)=>{
        e.stopPropagation();
        setUserDefaultLocation(item.location);
        setOpen(false);
        setIsOpen(null);
    };
    const getAddressObj = ()=>{
        const loc = cookies?.userLocation ? cookies?.userLocation : "41.2646,69.2163".split(",");
        if (!defaultAddress && loc[0]) {
            (0,_utils_getLocation__WEBPACK_IMPORTED_MODULE_9__/* .getLocationObj */ .l)({
                location: {
                    lat: loc[0],
                    lng: loc[1]
                },
                setAddress: setDefaultAddress
            });
        }
        return defaultAddress;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (address.length === 0 && cookies.access_token) {
            getUser();
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (address.length === 0) getAddressObj();
    }, [
        address
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: isOpen === "enter-address" ? "select-address active" : "select-address",
        onClick: click,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_SendPlaneLineIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                size: 20,
                className: "send-plane"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "labelSelectAddress",
                children: cuurentAddress ? cuurentAddress.address : defaultAddress?.address
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_ArrowDownSLineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                size: 20,
                className: "arrow-down"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "enter-address",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "add-address-btn",
                        onClick: ()=>handleDrawer("enter-address"),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                size: 20
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Add new address")
                            })
                        ]
                    }),
                    address?.map((item, key)=>{
                        const lat_lng = `${item.location.latitude},${item.location.longitude}`;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "address-list",
                            onClick: (e)=>handleAddress(e, item),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    children: item.address
                                }),
                                lat_lng === userLocation && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_CheckDoubleLineIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    className: "suffix"
                                })
                            ]
                        }, key);
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectAddress);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8782);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_2__);



const ImageLoader = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        style: {
            marginBottom: "14px"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_content_loader__WEBPACK_IMPORTED_MODULE_2___default()), {
            speed: 1,
            width: "100%",
            height: 230,
            viewBox: "0 0 100% 230",
            backgroundColor: "#ffffff",
            foregroundColor: "#ededed",
            ...props,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", {
                x: "0",
                y: "0",
                rx: "15",
                ry: "15",
                width: "100%",
                height: "230"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageLoader);


/***/ }),

/***/ 4213:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Loader = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "loader-wrapper",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "lds-ripple",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loader);


/***/ }),

/***/ 552:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_Message3LineIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2182);
/* harmony import */ var remixicon_react_Message3LineIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Message3LineIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
react_toastify__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const RippleButton = ({ onClick  })=>{
    const cookie = (0,nookies__WEBPACK_IMPORTED_MODULE_3__.parseCookies)();
    const handleCLick = ()=>{
        if (cookie?.access_token) {
            onClick(true);
        } else {
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error("Please login first");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "ripple-btn",
        onClick: handleCLick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Message3LineIcon__WEBPACK_IMPORTED_MODULE_2___default()), {})
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RippleButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1716:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _products_look__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7747);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3015);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7821);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8942);
/* harmony import */ var _api_main_banner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8049);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3590);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3788);
/* harmony import */ var _loader_discord_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2231);
/* harmony import */ var _loader_image__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(854);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3877);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_3__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_7__, swiper__WEBPACK_IMPORTED_MODULE_13__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_3__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_7__, swiper__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const LookDetail = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const { 0: lookProduct , 1: setLookProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: productList , 1: setProductList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { lookId  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__/* .MainContext */ .T);
    const { 0: orderProduct , 1: setOrderProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const getLook = ()=>{
        _api_main_banner__WEBPACK_IMPORTED_MODULE_6__/* .BannerApi.getId */ .b.getId(lookId).then((res)=>{
            setLookProduct(res.data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    const getLookProducts = ()=>{
        _api_main_banner__WEBPACK_IMPORTED_MODULE_6__/* .BannerApi.getProduct */ .b.getProduct(lookId).then((res)=>{
            setProductList(res.data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLookProduct(null);
        setProductList(null);
        setOrderProduct([]);
        if (lookId) {
            getLook();
            getLookProducts();
        }
    }, [
        lookId
    ]);
    const buyAll = ()=>{
        const condition = (element)=>element.currentStock.quantity < 1 || !element.currentStock.quantity;
        const notEnough = orderProduct.some((element)=>condition(element));
        const notEnoughProduct = orderProduct.filter((element)=>condition(element));
        if (notEnough) {
            notEnoughProduct.map((data)=>{
                react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.error(`${data.translation.title} out of stock`);
            });
        } else {
            orderProduct.forEach((product)=>{
                dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__/* .addToCart */ .Xq)({
                    product_id: product.id,
                    id: product.currentStock?.id,
                    translation: product.translation,
                    extras: product.selectExtras ? [
                        product.selectExtras
                    ] : [],
                    img: product.img,
                    stockId: product.currentStock,
                    min_qty: product.min_qty,
                    max_qty: product.max_qty,
                    tax: product.tax,
                    price: product.currentStock?.price,
                    shop_tax: product.shop.tax,
                    discount: product.currentStock?.discount ? product.currentStock?.discount : 0,
                    stocks: product.stocks,
                    shop: {
                        id: product.shop.id,
                        translation: product.shop.translation,
                        logo: product.shop.logo_img,
                        tax: product.shop.tax,
                        close_time: product.shop.close_time,
                        open_time: product.shop.open_time,
                        location: product.shop.location
                    }
                }));
                dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_10__/* .getTotals */ .j_)());
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "look-detail-wrapper",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "look-detail-img",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.Swiper, {
                    slidesPerView: 1,
                    pagination: true,
                    modules: [
                        swiper__WEBPACK_IMPORTED_MODULE_13__.Pagination
                    ],
                    children: lookProduct ? lookProduct?.galleries?.map((img, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                src: _constants__WEBPACK_IMPORTED_MODULE_4__/* .imgBaseUrl */ .XW + img.path
                            })
                        }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_loader_image__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                })
            }),
            productList ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "look-detail-product-list",
                children: [
                    productList?.map((product, key)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_products_look__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            index: key,
                            orderProduct: orderProduct,
                            setOrderProduct: setOrderProduct,
                            product: product
                        }, key);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "description",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "title",
                                children: tl("Description")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "content",
                                children: lookProduct?.translation.description
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "btn-success",
                        onClick: buyAll,
                        children: tl("Buy all products")
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_loader_discord_loader__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
            productList?.length === 0 && "Not product"
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LookDetail);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6098:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ MenuList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(62);
/* harmony import */ var remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3006);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3015);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4009);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8942);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7821);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__]);
([swiper__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_8__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const MenuList = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const { 0: changeScroll , 1: ssetChangeScroll  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("none");
    const { 0: display , 1: setDisplay  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("none");
    const { 0: num , 1: setNum  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const { 0: arr , 1: setArr  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(()=>{
        (async ()=>{
            axios__WEBPACK_IMPORTED_MODULE_12___default().get(`https://admin.rentinn.uz/api/v1/rest/categories/paginate`).then((res)=>setArr(res.data.data)).catch((err)=>console.log(err));
        })();
    });
    console.log(arr);
    const someArr = new Array(10).fill("Lorem ipsum").map((el, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
            children: el
        }, index));
    const allArr = new Array(6).fill(someArr).map((el)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "eachColHover",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                    children: "Lorem"
                }),
                el
            ]
        }));
    const { ref , inView  } = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_8__.useInView)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const prev = document.getElementsByClassName("swiper-button-prev")[0];
        inView ? prev.style = "opacity:0" : prev.style = "opacity:1";
    }, [
        inView
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "menuListWrapper",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "menuListContainer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "categoriesList",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_7__.Swiper, {
                            mousewheel: true,
                            scrollbar: true,
                            slidesPerView: 4,
                            spaceBetween: 30,
                            freeMode: true,
                            navigation: true,
                            modules: [
                                swiper__WEBPACK_IMPORTED_MODULE_6__.Mousewheel,
                                swiper__WEBPACK_IMPORTED_MODULE_6__.FreeMode,
                                swiper__WEBPACK_IMPORTED_MODULE_6__.Navigation
                            ],
                            className: "swiperCategoriesList",
                            children: arr && arr.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_7__.SwiperSlide, {
                                    onMouseLeave: ()=>setDisplay("none"),
                                    onMouseOver: ()=>setDisplay("grid"),
                                    onClick: ()=>setNum(index),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                        children: item.keywords
                                    })
                                }, index))
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "sideBtns",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/stores/often-buy",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "btn sideBtn link",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "label",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                size: 32,
                                                color: "#61DC00"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                                children: tl("Often buy")
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/stores/profitable",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "btn sideBtn link",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "label",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_constants_images__WEBPACK_IMPORTED_MODULE_5__/* .CheeseLineIcon */ .D6, {}),
                                            tl("Advantageous")
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                onMouseOver: ()=>setDisplay("grid"),
                onMouseLeave: ()=>setDisplay("none"),
                className: "skeletonBetween"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                onMouseOver: ()=>setDisplay("grid"),
                onMouseLeave: ()=>setDisplay("none"),
                className: "menuHover",
                style: {
                    display: `${display}`
                },
                children: allArr
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5229:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8743);
/* harmony import */ var remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(907);
/* harmony import */ var remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5225);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_ShoppingCartLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7481);
/* harmony import */ var remixicon_react_ShoppingCartLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ShoppingCartLineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var remixicon_react_HeartLineIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6582);
/* harmony import */ var remixicon_react_HeartLineIcon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_HeartLineIcon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4078);
/* harmony import */ var remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _sidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9678);
/* harmony import */ var _drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7671);
/* harmony import */ var _form_select_address__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1536);
/* harmony import */ var _mobile__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9497);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9054);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8942);
/* harmony import */ var _avatar__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1835);
/* harmony import */ var _utils_getPrice__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6520);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _search_filter__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(608);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _MenuList__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6098);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_drawer__WEBPACK_IMPORTED_MODULE_10__, _form_select_address__WEBPACK_IMPORTED_MODULE_11__, _mobile__WEBPACK_IMPORTED_MODULE_12__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__, _avatar__WEBPACK_IMPORTED_MODULE_17__, _search_filter__WEBPACK_IMPORTED_MODULE_20__, _MenuList__WEBPACK_IMPORTED_MODULE_22__]);
([_drawer__WEBPACK_IMPORTED_MODULE_10__, _form_select_address__WEBPACK_IMPORTED_MODULE_11__, _mobile__WEBPACK_IMPORTED_MODULE_12__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__, _avatar__WEBPACK_IMPORTED_MODULE_17__, _search_filter__WEBPACK_IMPORTED_MODULE_20__, _MenuList__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const Navbar = ({ handleContent  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_13__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_21__.useRouter)();
    const { 0: mobileWidth , 1: setMobileWidth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_19__.parseCookies)();
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.user.data);
    const settings = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.settings.data);
    const notification = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.notification.data);
    const { notificationList , handleNotification , handleMarkAllNotification , setDrawerTitle ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__/* .MainContext */ .T);
    const isEmpty = Object.keys(user ? user : {}).length === 0;
    const cartTotalAmount = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.cart.cartTotalAmount);
    const windowSize = (0,_utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)();
    const click = (key)=>{
        setDrawerTitle("My order");
        handleContent(key);
    };
    const readed = (item)=>{
        const readed = notification.includes(item.id);
        return readed;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.body.clientWidth < 1200 ? setMobileWidth(true) : setMobileWidth(false);
    }, [
        document.body.clientWidth
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "navbar",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "left",
                        children: [
                            mobileWidth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "burger-btn",
                                onClick: ()=>setOpen(true),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {})
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: "/",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: "logo",
                                    children: "Safin24"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_search_filter__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                className: router.pathname === "/products/[id]" ? "inner-store" : ""
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "right",
                        children: [
                            (isEmpty || !cookies?.access_token) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: "/auth/sign-in",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "login-btn",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            size: 20
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: tl("Login")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                href: "/stores/liked-product",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "square",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_HeartLineIcon__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            size: 20
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: tl("Favorite")
                                        })
                                    ]
                                })
                            }),
                            user?.wallet && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "wallet",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        size: 20
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                        className: "amount",
                                        children: tl("Basket")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "cart-amount",
                                onClick: ()=>click("order-list"),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_ShoppingCartLineIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        size: 20
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                        children: tl("Basket")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_avatar__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_drawer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                header: false,
                open: open,
                setOpen: setOpen,
                direction: "left",
                size: 585,
                className: "mobile-sidebar",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_sidebar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        setOpen: setOpen
                    }),
                    windowSize?.width < 769 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_mobile__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        setOpen: setOpen
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_MenuList__WEBPACK_IMPORTED_MODULE_22__/* .MenuList */ .q, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9497:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _form_select_address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1536);
/* harmony import */ var remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(907);
/* harmony import */ var remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_AddCircleFillIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(160);
/* harmony import */ var remixicon_react_AddCircleFillIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_AddCircleFillIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_QrScanLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6292);
/* harmony import */ var remixicon_react_QrScanLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_QrScanLineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4078);
/* harmony import */ var remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1406);
/* harmony import */ var remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5225);
/* harmony import */ var remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9348);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var remixicon_react_PercentLineIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2271);
/* harmony import */ var remixicon_react_PercentLineIcon__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_PercentLineIcon__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2394);
/* harmony import */ var remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var remixicon_react_Wallet2LineIcon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4136);
/* harmony import */ var remixicon_react_Wallet2LineIcon__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Wallet2LineIcon__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var remixicon_react_ImageLineIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1967);
/* harmony import */ var remixicon_react_ImageLineIcon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ImageLineIcon__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var remixicon_react_UserSettingsLineIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3281);
/* harmony import */ var remixicon_react_UserSettingsLineIcon__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_UserSettingsLineIcon__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9418);
/* harmony import */ var remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var remixicon_react_CustomerService2LineIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4926);
/* harmony import */ var remixicon_react_CustomerService2LineIcon__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_CustomerService2LineIcon__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8743);
/* harmony import */ var remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _redux_slices_user__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9134);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3788);
/* harmony import */ var _redux_slices_order__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9611);
/* harmony import */ var _redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3212);
/* harmony import */ var _redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4982);
/* harmony import */ var _redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(7169);
/* harmony import */ var _redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(7508);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7821);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _utils_getPrice__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(6520);
/* harmony import */ var remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(8249);
/* harmony import */ var remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(4565);
/* harmony import */ var remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(8942);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_form_select_address__WEBPACK_IMPORTED_MODULE_2__, _redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_23__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_33__]);
([_form_select_address__WEBPACK_IMPORTED_MODULE_2__, _redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_23__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_33__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



































const MobileNav = ({ setOpen  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_28__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_18__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_32__.useRouter)();
    const { setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_33__/* .MainContext */ .T);
    const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_18__.useSelector)((state)=>state.user.data);
    const isEmpty = Object.keys(user).length === 0;
    const logOut = ()=>{
        dispatch((0,_redux_slices_user__WEBPACK_IMPORTED_MODULE_19__/* .clearUser */ .pn)());
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_20__/* .clearCart */ .LL)());
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_20__/* .clearOrderShops */ .F)());
        dispatch((0,_redux_slices_order__WEBPACK_IMPORTED_MODULE_21__/* .clearOrder */ .bn)());
        dispatch((0,_redux_slices_savedStore__WEBPACK_IMPORTED_MODULE_22__/* .clearSavedStore */ .Wo)());
        dispatch((0,_redux_slices_savedAddress__WEBPACK_IMPORTED_MODULE_23__/* .clearAddress */ .RH)());
        dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_24__/* .clearList */ .vy)());
        dispatch((0,_redux_slices_viewed_product__WEBPACK_IMPORTED_MODULE_25__/* .clearViewedList */ .ZC)());
        setAddress([]);
        document.cookie = "access_token" + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
        document.cookie = "userLocation" + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
        router.push("/");
    };
    const routes = [
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Notification4LineIcon__WEBPACK_IMPORTED_MODULE_6___default()), {
                size: 22
            }),
            href: "/notification",
            label: "Notification",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Bookmark3LineIcon__WEBPACK_IMPORTED_MODULE_8___default()), {
                size: 22
            }),
            href: "/saved-store",
            label: "Saved stores",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_9___default()), {
                size: 22
            }),
            href: "/stores/liked-product",
            label: "Liked products",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_PercentLineIcon__WEBPACK_IMPORTED_MODULE_10___default()), {
                size: 22
            }),
            href: "/stores/discount-product",
            label: "Discount",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_EyeLineIcon__WEBPACK_IMPORTED_MODULE_11___default()), {
                size: 22
            }),
            href: "/stores/viewed-product",
            label: "Viewed products",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Wallet2LineIcon__WEBPACK_IMPORTED_MODULE_12___default()), {
                size: 22
            }),
            href: "/wallet-history",
            label: "Wallet history",
            show: Object.keys(user).length
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_ImageLineIcon__WEBPACK_IMPORTED_MODULE_13___default()), {
                size: 22
            }),
            href: "/blog",
            label: "Blog",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_UserSettingsLineIcon__WEBPACK_IMPORTED_MODULE_14___default()), {
                size: 22
            }),
            href: "/settings",
            label: "Profile settings",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_FileListLineIcon__WEBPACK_IMPORTED_MODULE_15___default()), {
                size: 22
            }),
            href: "/order-history",
            label: "Order history",
            show: Object.keys(user).length
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StoreLineIcon__WEBPACK_IMPORTED_MODULE_30___default()), {}),
            label: "Be seller",
            href: "/be-seller",
            show: true
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_LinksLineIcon__WEBPACK_IMPORTED_MODULE_31___default()), {}),
            label: "Your invite",
            show: true,
            href: "/invite"
        },
        {
            icon: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_LoginCircleLineIcon__WEBPACK_IMPORTED_MODULE_17___default()), {
                size: 22
            }),
            href: "/",
            label: "Log out",
            show: Object.keys(user).length
        }, 
    ];
    const handleCLick = (href)=>{
        setOpen(false);
        if (href === "/") logOut();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "navbar-mobile",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "navbar",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "left",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "burger-btn",
                            onClick: ()=>setOpen(false),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {})
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "right",
                        children: [
                            user?.wallet && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "wallet",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Wallet3LineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        size: 20
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "amount",
                                        children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_29__/* .getPrice */ .a)(user?.wallet?.price)
                                    })
                                ]
                            }),
                            !isEmpty && (user.img ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "user",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                    className: "avatar",
                                    src: _constants__WEBPACK_IMPORTED_MODULE_26__/* .imgBaseUrl */ .XW + user.img,
                                    alt: "Avatar"
                                })
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "square avatar",
                                children: user.firstname?.slice(0, 1)
                            }))
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "mobile-select-address",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_select_address__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    setOpen: setOpen
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "nav-links",
                children: routes.filter((item)=>item.show).map((route, key)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_27___default()), {
                        href: route.href,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            className: "link",
                            onClick: ()=>handleCLick(route.href),
                            children: [
                                route.icon,
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    children: tl(route.label)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    size: 22,
                                    className: "suffix"
                                })
                            ]
                        })
                    }, key);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileNav);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9695:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _products_order_product__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7531);
/* harmony import */ var remixicon_react_DeleteBin3LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6449);
/* harmony import */ var remixicon_react_DeleteBin3LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_DeleteBin3LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _supplier__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1548);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3788);
/* harmony import */ var _empty_data__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1478);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3006);
/* harmony import */ var _utils_getPrice__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6520);
/* harmony import */ var _api_main_product__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4391);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_products_order_product__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_13__]);
([_products_order_product__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const OrderList = ({ setOpen  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const { 0: counter , 1: setCounter  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.cart, react_redux__WEBPACK_IMPORTED_MODULE_7__.shallowEqual);
    const getGroupById = (flattenExtras = [])=>{
        let result = [];
        flattenExtras.forEach((r)=>{
            if (!result[r.shop?.id]) {
                result[r.shop?.id] = [];
            }
            result[r.shop?.id].push(r);
        });
        return result;
    };
    const getFinnalyCheck = ()=>{
        let totalDiscount = 0;
        let total_price = 0;
        let totalTax = 0;
        let vatTax = 0;
        let shopTax = 0;
        showProduct.forEach((item)=>{
            item.forEach((data)=>{
                if (data.stockId.discount) {
                    totalDiscount += data.stockId.discount * data.qty;
                }
                vatTax += data.tax;
                shopTax += data.shop_tax;
                total_price += data.total_price - data.tax;
                totalTax += data.productTax + data.total_price * data.shop.tax / 100;
            });
        });
        return {
            totalDiscount,
            total_price,
            totalTax,
            vatTax,
            shopTax
        };
    };
    const showProduct = getGroupById(cart.cartItems).filter((item)=>item.length > 0);
    const cratProductIds = [
        ...new Set(cart?.cartItems.map((item)=>item.product_id)), 
    ];
    const checkProduct = ()=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_12__/* .ProductApi.checkIds */ .y.checkIds({
            products: cratProductIds
        }).then(({ data  })=>{
            let quantities = [];
            showProduct.flat().forEach((item)=>{
                const product = data.find((el)=>el.id === item.product_id);
                const stock = product?.stocks.find((el)=>el.id === item.id);
                if (!stock) {
                    dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .removeFromCart */ .h2)(item));
                    dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .getTotals */ .j_)());
                    react_toastify__WEBPACK_IMPORTED_MODULE_13__.toast.warn(`${item.translation.title} ${tl("out of stock")}`);
                    setCounter((prev)=>prev + 1);
                    return;
                }
                if (stock.quantity < item.qty) {
                    quantities.push({
                        id: stock.id,
                        quantity: stock.quantity
                    });
                }
            });
            if (quantities.length) {
                dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .replaceStock */ .gm)(quantities));
                dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .getTotals */ .j_)());
            }
        }).catch((error)=>{
            console.log(error);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (cratProductIds?.length > 0) checkProduct();
    }, []);
    const { totalDiscount , total_price , vatTax , shopTax  } = getFinnalyCheck();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "order-list",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "order-list-header",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "product-count",
                        children: `${cart?.cartTotalQuantity} ${tl("products")}`
                    }),
                    counter > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "product-count",
                        children: `${counter} ${tl("out.of.stock.message")}`
                    }),
                    cart?.cartTotalQuantity > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "btn-secondary",
                        onClick: ()=>dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_8__/* .clearCart */ .LL)()),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_DeleteBin3LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Delete all")
                            })
                        ]
                    })
                ]
            }),
            cart?.cartTotalQuantity === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_empty_data__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                setOpen: setOpen,
                btn: true,
                image: _constants_images__WEBPACK_IMPORTED_MODULE_10__/* .images.CartEmpty */ .Wc.CartEmpty,
                text1: "There are no items in the my order",
                text2: "To select items, go to the stores"
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "content",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "products-lists",
                        children: showProduct?.map((product, key)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "product-list-item",
                                children: [
                                    product.map((orderedProduct, key)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_products_order_product__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            orderedProduct: orderedProduct
                                        }, key);
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_supplier__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        shop: product[0].shop,
                                        products: product
                                    })
                                ]
                            }, key);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "total-amoun-wrapper",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "total-amount",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "amount-item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "key",
                                                children: tl("Total product price")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "value",
                                                children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_11__/* .getPrice */ .a)(total_price + totalDiscount)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "amount-item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "key",
                                                children: tl("Discount")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "value",
                                                children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_11__/* .getPrice */ .a)(totalDiscount)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "amount-item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "key",
                                                children: tl("VAT Tax")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "value",
                                                children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_11__/* .getPrice */ .a)(vatTax)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "amount-item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "key",
                                                children: tl("Shop tax")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "value",
                                                children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_11__/* .getPrice */ .a)(shopTax)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "amount-item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "key",
                                                children: tl("Total amount")
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "value",
                                                children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_11__/* .getPrice */ .a)(total_price + vatTax + shopTax)
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/checkout",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                    className: "btn-success",
                                    children: tl("Go to checkuot")
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ look)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "remixicon-react/AddLineIcon"
var AddLineIcon_ = __webpack_require__(5265);
var AddLineIcon_default = /*#__PURE__*/__webpack_require__.n(AddLineIcon_);
// EXTERNAL MODULE: external "remixicon-react/Heart3FillIcon"
var Heart3FillIcon_ = __webpack_require__(1257);
var Heart3FillIcon_default = /*#__PURE__*/__webpack_require__.n(Heart3FillIcon_);
// EXTERNAL MODULE: external "remixicon-react/Heart3LineIcon"
var Heart3LineIcon_ = __webpack_require__(9348);
var Heart3LineIcon_default = /*#__PURE__*/__webpack_require__.n(Heart3LineIcon_);
// EXTERNAL MODULE: external "remixicon-react/SubtractLineIcon"
var SubtractLineIcon_ = __webpack_require__(3132);
var SubtractLineIcon_default = /*#__PURE__*/__webpack_require__.n(SubtractLineIcon_);
// EXTERNAL MODULE: ./constants/index.js
var constants = __webpack_require__(7821);
// EXTERNAL MODULE: ./redux/slices/cart.js
var cart = __webpack_require__(3788);
// EXTERNAL MODULE: ./redux/slices/savedProduct.js
var savedProduct = __webpack_require__(7169);
;// CONCATENATED MODULE: ./utils/getGroupById.js
const getGroupByExtraGroupId = (flattenExtras = [])=>{
    let result = [];
    flattenExtras.forEach((r)=>{
        if (!result[r.extra_group_id]) {
            result[r.extra_group_id] = [];
        }
        result[r.extra_group_id].push(r);
    });
    return result;
};

// EXTERNAL MODULE: ./utils/getPrice.js
var getPrice = __webpack_require__(6520);
// EXTERNAL MODULE: ./utils/removeDuplicate.js
var removeDuplicate = __webpack_require__(8550);
;// CONCATENATED MODULE: ./components/products/look.js
















const ProductLook = ({ product , setOrderProduct , orderProduct , index  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { t: tl  } = (0,external_react_i18next_.useTranslation)();
    const { 0: selectExtras , 1: setSelectExtras  } = (0,external_react_.useState)();
    const currentStock = product.stocks.filter((element)=>element?.extras[0]?.id === selectExtras?.id)[0];
    const cartItems = (0,external_react_redux_.useSelector)((state)=>state.cart.cartItems);
    const findFromCart = cartItems.find((item)=>item.id === currentStock?.id);
    const likedProducts = (0,external_react_redux_.useSelector)((state)=>state.savedProduct.savedProductList);
    const isLiked = likedProducts.find((lp)=>lp.id === product?.id);
    const flattenExtras = product.stocks.flatMap((stock)=>stock.extras);
    const result = (0,removeDuplicate/* getUnique */.d)(getGroupByExtraGroupId(flattenExtras).filter((item)=>item.length > 0)[0]);
    const handelAddToCart = ()=>{
        dispatch((0,cart/* addToCart */.Xq)({
            product_id: product.id,
            id: currentStock?.id,
            translation: product.translation,
            extras: [
                selectExtras
            ],
            img: product.img,
            stockId: currentStock,
            min_qty: product.min_qty,
            max_qty: product.max_qty,
            tax: product.tax,
            price: currentStock?.price,
            shop_tax: product.shop.tax,
            discount: currentStock?.discount ? currentStock?.discount : 0,
            stocks: product.stocks,
            shop: {
                id: product.shop.id,
                translation: product.shop.translation,
                logo: product.shop.logo_img,
                tax: product.shop.tax,
                close_time: product.shop.close_time,
                open_time: product.shop.open_time,
                location: product.shop.location
            }
        }));
        dispatch((0,cart/* getTotals */.j_)());
    };
    const removeCart = ()=>{
        dispatch((0,cart/* removeFromCart */.h2)(findFromCart));
        dispatch((0,cart/* getTotals */.j_)());
    };
    (0,external_react_.useEffect)(()=>{
        if (result) {
            setSelectExtras(result[0]);
        }
    }, []);
    (0,external_react_.useEffect)(()=>{
        if (currentStock) {
            const list = orderProduct;
            list[index] = {
                currentStock,
                ...product,
                selectExtras
            };
            setOrderProduct(list);
        }
    }, [
        currentStock
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "product-look-wrapper",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "product-look-img",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("img", {
                    src: constants/* imgBaseUrl */.XW + product?.img
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "data-wrapper",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "product-look-data",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "product-name",
                                children: product?.translation?.title
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                className: "product-extras",
                                children: result?.map((item, key)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                                        className: selectExtras?.id === item.id ? "item active" : "item",
                                        onClick: ()=>setSelectExtras(item),
                                        children: item?.value
                                    }, key);
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "action-btns",
                                children: [
                                    lookPrice(currentStock, product),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "btn saved",
                                        children: [
                                            isLiked ? /*#__PURE__*/ (0,jsx_runtime_.jsx)((Heart3FillIcon_default()), {
                                                size: 24,
                                                color: "#000",
                                                onClick: ()=>dispatch((0,savedProduct/* removeFromSaved */.YH)(product))
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)((Heart3LineIcon_default()), {
                                                size: 24,
                                                onClick: ()=>dispatch((0,savedProduct/* addToSaved */.IV)(product))
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                                                children: tl("Saved")
                                            })
                                        ]
                                    }),
                                    findFromCart?.id === currentStock?.id ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        className: "btn add-to-cart",
                                        onClick: removeCart,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)((SubtractLineIcon_default()), {
                                                size: 20
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                                                children: tl("Remove from cart")
                                            })
                                        ]
                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("button", {
                                        disabled: currentStock?.quantity > 0 ? false : true,
                                        className: "btn add-to-cart",
                                        onClick: handelAddToCart,
                                        children: currentStock?.quantity > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)((AddLineIcon_default()), {
                                                    size: 20
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                                                    children: tl("Add to cart")
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("label", {
                                            children: tl("out of stock")
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    lookPrice(currentStock, product)
                ]
            })
        ]
    });
};
const lookPrice = (currentStock, product)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
        className: "product-look-price",
        children: currentStock?.discount ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "old-price",
                    children: (0,getPrice/* getPrice */.a)(currentStock?.price)
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                    children: (0,getPrice/* getPrice */.a)(currentStock?.price - product.stocks[0]?.discount)
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
            children: (0,getPrice/* getPrice */.a)(currentStock?.price)
        })
    });
};
/* harmony default export */ const look = (ProductLook);


/***/ }),

/***/ 7531:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hex_color_to_color_name__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5448);
/* harmony import */ var hex_color_to_color_name__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hex_color_to_color_name__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_DeleteBinLineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8553);
/* harmony import */ var remixicon_react_DeleteBinLineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_DeleteBinLineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9348);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1257);
/* harmony import */ var remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5265);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3132);
/* harmony import */ var remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7821);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3788);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7169);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _utils_getPrice__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6520);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_12__]);
react_toastify__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const OrderProduct = ({ orderedProduct  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_13__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useDispatch)();
    const likedProducts = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.savedProduct.savedProductList);
    const isLiked = likedProducts.find((lp)=>lp.id === orderedProduct?.id);
    const remove = ()=>{
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .removeFromCart */ .h2)(orderedProduct));
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .getTotals */ .j_)());
    };
    const handleDec = ()=>{
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .decreaseCart */ .Bq)(orderedProduct));
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .getTotals */ .j_)());
    };
    const handleInc = ()=>{
        if (orderedProduct.qty >= orderedProduct.max_qty) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn(`${tl("You can buy only")} ${orderedProduct.max_qty} ${tl("products")}`);
        } else if (orderedProduct.qty >= orderedProduct.stockId.quantity) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.warn(`${tl("You can buy only")} ${orderedProduct.stockId.quantity} ${tl("products")}`);
        } else {
            dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .addToCart */ .Xq)(orderedProduct));
            dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_9__/* .getTotals */ .j_)());
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "order-product",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "product-data",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "left",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: _constants__WEBPACK_IMPORTED_MODULE_8__/* .imgBaseUrl */ .XW + orderedProduct?.img,
                            alt: "Product"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "liked",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                size: 22
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "center-right",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "name",
                                    children: orderedProduct?.translation.title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "size-color",
                                    children: [
                                        orderedProduct.extras?.map((item, key)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                children: item?.group.type === "text" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: "size",
                                                    children: `${item.group.translation?.title}: ${item.value}`
                                                })
                                            }, key);
                                        }),
                                        orderedProduct.extras?.map((item, key)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                children: item?.group.type === "color" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: "color",
                                                    children: `${tl("Color")}: ${(0,hex_color_to_color_name__WEBPACK_IMPORTED_MODULE_2__.GetColorName)(item.value)}`
                                                })
                                            }, key);
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "action-btn",
                                    children: [
                                        isLiked ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "btn-item save",
                                            onClick: ()=>dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_11__/* .removeFromSaved */ .YH)(orderedProduct)),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    size: 24,
                                                    color: "#000"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: tl("Saved")
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "btn-item save",
                                            onClick: ()=>dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_11__/* .addToSaved */ .IV)(orderedProduct)),
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    size: 24
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: tl("Saved")
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "btn-item",
                                            onClick: remove,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_DeleteBinLineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    size: 20
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: tl("Delete")
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "right",
                            children: [
                                orderedProduct.stockId.discount ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "price",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                            className: "current",
                                            children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_14__/* .getPrice */ .a)(orderedProduct.stockId.price - orderedProduct.stockId.discount)
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "old",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_14__/* .getPrice */ .a)(orderedProduct.stockId.price)
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: "discount",
                                                    children: `${(orderedProduct.stockId.discount / orderedProduct.stockId.price * 100).toFixed(2)} %`
                                                })
                                            ]
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "current",
                                    children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_14__/* .getPrice */ .a)(orderedProduct.stockId.price)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "counter-btn",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                            className: "increment",
                                            onClick: handleDec,
                                            disabled: orderedProduct.qty === orderedProduct.min_qty ? true : false,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                size: 14
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                            children: orderedProduct?.qty
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                            className: "decrement",
                                            onClick: handleInc,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                size: 14
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrderProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2045);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3071);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3590);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8942);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_5__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__]);
([_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_4__, react_toastify__WEBPACK_IMPORTED_MODULE_5__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Providers = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_redux__WEBPACK_IMPORTED_MODULE_3__.Provider, {
        store: _redux_store__WEBPACK_IMPORTED_MODULE_4__/* .store */ .h,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_6__.PersistGate, {
            loading: null,
            persistor: _redux_store__WEBPACK_IMPORTED_MODULE_4__/* .persistor */ .D,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_utils_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_2__/* .AuthProvider */ .Ho, {
                        children: children
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_toastify__WEBPACK_IMPORTED_MODULE_5__.ToastContainer, {
                        newestOnTop: true
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Providers);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5529:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PushNotification)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3590);
/* harmony import */ var _utils_getNotification__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3536);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_5__, _utils_getNotification__WEBPACK_IMPORTED_MODULE_6__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_5__, _utils_getNotification__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function PushNotification() {
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const audioPlayer = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const { 0: notificationData , 1: setNotificationData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const settings = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.settings.data, react_redux__WEBPACK_IMPORTED_MODULE_4__.shallowEqual);
    const notify = ()=>{
        audioPlayer.current.play();
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast)(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "notification-body",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "title",
                    children: `${tl("Order")}_${notificationData?.title}`
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "text",
                    children: notificationData?.body
                })
            ]
        }), {
            hideProgressBar: true,
            className: "custom-toast"
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (notificationData?.title) {
            notify();
        }
    }, [
        notificationData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (Object.keys(settings).length) (0,_utils_getNotification__WEBPACK_IMPORTED_MODULE_6__/* .getNotification */ .v)({
            vapid_key: settings.vapid_key,
            setNotificationData
        });
    }, [
        notificationData,
        Object.keys(settings).length
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "notification",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("audio", {
            allow: "autoplay",
            ref: audioPlayer,
            src: "./assets/media/web_whatsapp.mp3"
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7954:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6982);
/* harmony import */ var remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_PauseFillIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8942);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__]);
_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const FilterContent = ()=>{
    const { t: tl  } = useTranslation();
    const cookies = parseCookies();
    const currency_symbol = cookies.currency_symbol;
    const category = useSelector((state)=>state.category.categoryList);
    const { setLayout , layout , category_id , setCategoryId , sort , setSort  } = useContext(MainContext);
    const { 0: range , 1: setRange  } = useState(null);
    const { 0: showRange , 1: setShowRange  } = useState([
        0,
        1000000
    ]);
    const handleChange = (value)=>{
        setRange(value);
        setShowRange(value);
    };
    return /*#__PURE__*/ _jsxs("div", {
        className: "filter-content",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "title",
                children: tl("category")
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "categories",
                children: category?.data?.filter((item)=>item.translation !== null)?.map((item, key)=>{
                    return /*#__PURE__*/ _jsx("div", {
                        className: item.id === category_id ? "item active" : "item",
                        onClick: ()=>setCategoryId(item.id),
                        children: item.translation?.title
                    }, key);
                })
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "price",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "label",
                        children: "Price"
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "low-high",
                        children: [
                            /*#__PURE__*/ _jsx("span", {
                                className: sort === "asc" ? "active" : "",
                                onClick: ()=>setSort("asc"),
                                children: tl("By low price")
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                className: sort === "desc" ? "active" : "",
                                onClick: ()=>setSort("desc"),
                                children: tl("By high price")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "filter-slider",
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        className: "price-rage",
                        children: [
                            /*#__PURE__*/ _jsx("span", {
                                children: `${currency_symbol} ${showRange ? showRange[0] : 0}`
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                children: `${currency_symbol} ${showRange ? showRange[1] : 0}`
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx(Slider, {
                        range: true,
                        allowCross: false,
                        defaultValue: [
                            1,
                            showRange[1]
                        ],
                        min: 1,
                        max: 1000000,
                        onChange: (value)=>handleChange(value)
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "filter-layout",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "title",
                        children: tl("layouts")
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "layout-item",
                        children: [
                            /*#__PURE__*/ _jsx("span", {
                                onClick: ()=>setLayout("vertical"),
                                className: layout === "vertical" && "active",
                                children: /*#__PURE__*/ _jsx(PauseFillIcon, {})
                            }),
                            /*#__PURE__*/ _jsx("span", {
                                onClick: ()=>setLayout("horizontal"),
                                className: layout === "horizontal" ? "horizontal active" : "horizontal",
                                children: /*#__PURE__*/ _jsx(PauseFillIcon, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FilterContent)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 608:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_MapPinLineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1713);
/* harmony import */ var remixicon_react_MapPinLineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_MapPinLineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_Search2LineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8428);
/* harmony import */ var remixicon_react_Search2LineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Search2LineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var remixicon_react_EqualizerFillIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(865);
/* harmony import */ var remixicon_react_EqualizerFillIcon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_EqualizerFillIcon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var remixicon_react_FileListFillIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3843);
/* harmony import */ var remixicon_react_FileListFillIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FileListFillIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var remixicon_react_Store3FillIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6359);
/* harmony import */ var remixicon_react_Store3FillIcon__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Store3FillIcon__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var remixicon_react_ArrowLeftSLineIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1116);
/* harmony import */ var remixicon_react_ArrowLeftSLineIcon__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ArrowLeftSLineIcon__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _search_result__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1522);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8942);
/* harmony import */ var _filter_content__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7954);
/* harmony import */ var _utils_hooks_useDebounce__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5053);
/* harmony import */ var _services_auth__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4368);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7821);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(62);
/* harmony import */ var remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_FlashlightFillIcon__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3006);
/* harmony import */ var _category__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1226);
/* harmony import */ var _form_select_address__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1536);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_search_result__WEBPACK_IMPORTED_MODULE_10__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_11__, _filter_content__WEBPACK_IMPORTED_MODULE_12__, _services_auth__WEBPACK_IMPORTED_MODULE_14__, _category__WEBPACK_IMPORTED_MODULE_19__, _form_select_address__WEBPACK_IMPORTED_MODULE_20__]);
([_search_result__WEBPACK_IMPORTED_MODULE_10__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_11__, _filter_content__WEBPACK_IMPORTED_MODULE_12__, _services_auth__WEBPACK_IMPORTED_MODULE_14__, _category__WEBPACK_IMPORTED_MODULE_19__, _form_select_address__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const SerachFilter = ({ className  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_16__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { isOpen , setIsOpen , shop  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_11__/* .MainContext */ .T);
    const { 0: searchTerm , 1: setSearchTerm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: searchResult , 1: setSearchResult  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: isSearching , 1: setIsSearching  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const debouncedSearchTerm = (0,_utils_hooks_useDebounce__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(searchTerm, 1000);
    function searchProduct(search) {
        return (0,_services_auth__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(`/api/v1/rest/products/paginate`, {
            params: {
                search,
                perPage: 50
            }
        }).then((r)=>r.data).catch((error)=>{
            console.error(error);
            return [];
        });
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (debouncedSearchTerm) {
            setIsSearching(true);
            searchProduct(debouncedSearchTerm).then((results)=>{
                setIsSearching(false);
                setSearchResult(results);
            });
        } else {
            setSearchResult([]);
        }
    }, [
        debouncedSearchTerm
    ]);
    const handleClick = (key)=>{
        setIsOpen(key);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setSearchTerm("");
    }, [
        isOpen
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: isOpen === "search" ? "filter-wrapper search-visible" : isOpen === "filter" ? "filter-wrapper filter-visible" : "filter-wrapper",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "search-input-wrapper",
                    children: [
                        router.pathname === "/products/[id]" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: `/stores/${shop.uuid}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "current-store",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "logo",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                            src: _constants__WEBPACK_IMPORTED_MODULE_15__/* .imgBaseUrl */ .XW + shop?.logo_img,
                                            alt: "Logo"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "data",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "name",
                                                children: shop?.translation?.title
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "type",
                                                children: tl("Store")
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `search-filter ${className}`,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Search2LineIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    size: 20,
                                    onClick: ()=>handleClick("search")
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                    value: searchTerm,
                                    onChange: (e)=>setSearchTerm(e.target.value),
                                    onFocus: ()=>handleClick("search"),
                                    placeholder: tl("Search products")
                                }),
                                searchResult?.data && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "search-result-count",
                                    children: searchResult?.data?.length
                                }),
                                (router.route === "/stores/[id]/news" || router.route === "/stores/[id]/top-sales" || router.route === "/stores/[id]/sales" || router.route === "/stores/[id]/all-product") && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_EqualizerFillIcon__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    className: "filter-icon",
                                    onClick: ()=>handleClick("filter"),
                                    size: 20
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_search_result__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    isSearching: isSearching,
                                    searchResult: searchResult,
                                    setSearchTerm: setSearchTerm,
                                    setIsOpen: setIsOpen
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "filter-links"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_select_address__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {})
            ]
        })
    });
};
const getButton = (tl, router)=>{
    const pathname = router.pathname;
    if (pathname === "/") {
        return /*#__PURE__*/ _jsx(Link, {
            href: "/view-in-map",
            children: /*#__PURE__*/ _jsxs("a", {
                className: "btn-view",
                children: [
                    /*#__PURE__*/ _jsx(MapPinLineIcon, {
                        size: 20
                    }),
                    /*#__PURE__*/ _jsx("span", {
                        children: tl("View in map")
                    })
                ]
            })
        });
    } else if (pathname === "/view-in-map") {
        return /*#__PURE__*/ _jsx(Link, {
            href: "/",
            children: /*#__PURE__*/ _jsxs("a", {
                className: "btn-view",
                children: [
                    /*#__PURE__*/ _jsx(FileListFillIcon, {
                        size: 20
                    }),
                    /*#__PURE__*/ _jsx("span", {
                        children: tl("View in List")
                    })
                ]
            })
        });
    } else if (pathname === "/stores/[id]") {
        return /*#__PURE__*/ _jsx(Link, {
            href: "/",
            children: /*#__PURE__*/ _jsxs("a", {
                className: "btn-view bg-white",
                children: [
                    /*#__PURE__*/ _jsx(Store3FillIcon, {
                        size: 20
                    }),
                    /*#__PURE__*/ _jsx("span", {
                        children: tl("Back all store")
                    })
                ]
            })
        });
    } else {
        return /*#__PURE__*/ _jsxs("div", {
            onClick: ()=>router.back(),
            className: "btn-view bg-white",
            children: [
                /*#__PURE__*/ _jsx(ArrowLeftSLineIcon, {
                    size: 20
                }),
                /*#__PURE__*/ _jsx("span", {
                    children: tl("Back")
                })
            ]
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SerachFilter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1522:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3006);
/* harmony import */ var _empty_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1478);
/* harmony import */ var _products_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9237);
/* harmony import */ var _products_section__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9253);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_products_section__WEBPACK_IMPORTED_MODULE_6__]);
_products_section__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const SerachResult = ({ isSearching , searchResult , setSearchTerm , setIsOpen ,  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const suggestionList = searchResult?.data?.map((item)=>item.translation.title);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "search-result-wrapper",
        children: isSearching ? `${tl("searching")}...` : !searchResult?.data?.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_empty_data__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            image: _constants_images__WEBPACK_IMPORTED_MODULE_3__/* .images.SearchEmpty */ .Wc.SearchEmpty,
            text1: "No search results"
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "product-box",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_products_section__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        title: "Products",
                        children: searchResult?.data?.map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_products_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                setIsOpen: setIsOpen,
                                product: product
                            }, key))
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "suggestion",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "title",
                            children: tl("Suggestions")
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "suggestion-item",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("ul", {
                                children: suggestionList?.map((suggestion, key)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        onClick: ()=>setSearchTerm(suggestion),
                                        children: suggestion
                                    }, key);
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SerachResult);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5827:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8942);
/* harmony import */ var remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1406);
/* harmony import */ var remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_ArrowRightSLineIcon__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__]);
_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const LaptopCategory = ()=>{
    const router = useRouter();
    const { 0: currentId , 1: setCurrentId  } = useState(0);
    const category = useSelector((state)=>state.category.categoryList);
    const { setIsOpenDropdown  } = useContext(MainContext);
    const handleHover = (id)=>{
        setCurrentId(id);
    };
    const handleLink = (id)=>{
        setIsOpenDropdown(false);
        router.push(`/all-product?category_id=${id}`);
    };
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "parent-category",
                children: /*#__PURE__*/ _jsx("ul", {
                    children: category?.map((item, key)=>{
                        return /*#__PURE__*/ _jsxs("li", {
                            className: `${key === currentId && "active"}`,
                            onMouseOver: ()=>handleHover(key),
                            children: [
                                /*#__PURE__*/ _jsx("label", {
                                    children: item?.translation?.title
                                }),
                                /*#__PURE__*/ _jsx(ArrowRightSLineIcon, {
                                    size: 20
                                })
                            ]
                        });
                    })
                })
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "child-category",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "title",
                        children: category[currentId]?.translation?.title
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "category-items",
                        children: category[currentId]?.children.map((item)=>{
                            if (item?.children?.length) {
                                return /*#__PURE__*/ _jsxs("div", {
                                    className: "item",
                                    children: [
                                        /*#__PURE__*/ _jsx("div", {
                                            className: "item-title",
                                            onClick: ()=>handleLink(item.id),
                                            children: item?.translation?.title
                                        }),
                                        /*#__PURE__*/ _jsx("ul", {
                                            children: item?.children?.map((item)=>{
                                                return /*#__PURE__*/ _jsx("li", {
                                                    onClick: ()=>handleLink(item.id),
                                                    children: item?.translation?.title
                                                });
                                            })
                                        })
                                    ]
                                });
                            } else {
                                return /*#__PURE__*/ _jsx("div", {
                                    className: "item single",
                                    children: /*#__PURE__*/ _jsx("ul", {
                                        children: /*#__PURE__*/ _jsx("li", {
                                            onClick: ()=>handleLink(item.id),
                                            children: item?.translation?.title
                                        })
                                    })
                                });
                            }
                        })
                    })
                ]
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (LaptopCategory)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5622:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8942);
/* harmony import */ var _accordion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7952);
/* harmony import */ var _accordion_accordion_details__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4021);
/* harmony import */ var _accordion_accordion_summary__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6694);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__]);
_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const MobileCategory = ()=>{
    const router = useRouter();
    const { 0: idList , 1: setIdList  } = useState([]);
    const category = useSelector((state)=>state.category.categoryList);
    const { setIsOpenDropdown  } = useContext(MainContext);
    const handleClick = (key)=>{
        const includes = idList.includes(key);
        if (includes) {
            setIdList(idList.filter((item)=>item !== key));
        } else {
            setIdList([
                ...idList,
                key
            ]);
        }
    };
    const handleLink = (id)=>{
        setIsOpenDropdown(false);
        router.push(`/all-product?category_id=${id}`);
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "footer",
        children: /*#__PURE__*/ _jsx("div", {
            className: "content",
            children: category?.map((child, id)=>{
                return /*#__PURE__*/ _jsxs(Accordion, {
                    idList: idList,
                    id: id,
                    children: [
                        /*#__PURE__*/ _jsx(AccordionSummary, {
                            handleClick: handleClick,
                            idList: idList,
                            y: child,
                            id: id,
                            children: child?.translation?.title
                        }),
                        /*#__PURE__*/ _jsx(AccordionDetails, {
                            children: child?.children?.map((child, key)=>{
                                return /*#__PURE__*/ _jsx("div", {
                                    className: router?.query?.category_id == child.id ? "item selected" : "item",
                                    onClick: ()=>handleLink(child.id),
                                    children: child.translation?.title
                                }, key);
                            })
                        })
                    ]
                });
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (MobileCategory)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_4__);





const Sidebar = ({ setOpen  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const cookie = (0,nookies__WEBPACK_IMPORTED_MODULE_4__.parseCookies)();
    const handleClick = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "sidebar",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "close-btn",
                onClick: handleClick
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "sider-links",
                children: [
                    cookie?.access_token && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/order-history",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Order history")
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/stores/discount-product",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Discount")
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/stores/viewed-product",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Viwed Products")
                        })
                    }),
                    cookie?.access_token && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/wallet-history",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Wallet history")
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/blog",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Blog")
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/settings",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            onClick: handleClick,
                            className: "link",
                            children: tl("Settings")
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);


/***/ }),

/***/ 4740:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _form_input_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8999);




const AddWallet = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "add-wallet-wrapper",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "add-wallet",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "wallet-amount",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Amount")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                                children: "$0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "add-wallet-form",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        className: "card-number",
                                        label: "Card Number",
                                        placeholder: "0000 0000 0000 0000"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        className: "card-name",
                                        label: "Card Name",
                                        placeholder: "Cardholder name"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        className: "expire",
                                        label: "Expiry date",
                                        placeholder: "00/00"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        className: "cvc",
                                        label: "CVC",
                                        placeholder: "000"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                className: "btn-success",
                children: tl("Top up wallet")
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddWallet);


/***/ }),

/***/ 6461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _form_input_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8999);




const TransferWallet = ()=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "add-wallet-wrapper",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "add-wallet",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "wallet-amount",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: tl("Amount")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                                children: "$0"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "add-wallet-form",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_input_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            className: "card-number",
                            label: "User ID",
                            placeholder: "ID12345"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                className: "btn-success",
                children: tl("Transfer money")
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransferWallet);


/***/ }),

/***/ 7821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XW": () => (/* binding */ imgBaseUrl)
/* harmony export */ });
/* unused harmony exports storeFilter, image, color, text */
const imgBaseUrl = `${"https://admin.rentinn.uz"}/storage/images/`;
const storeFilter = [
    {
        id: "all",
        value: "All"
    },
    {
        id: "open",
        value: "Open now"
    },
    {
        id: "always_open",
        value: "Work 24/7"
    },
    {
        id: "new",
        value: "New"
    },
    {
        id: "delivery",
        value: "Pickup"
    }, 
];
const image = "image";
const color = "color";
const text = "text";


/***/ }),

/***/ 5356:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_address_enter_delivery_address__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5080);
/* harmony import */ var _components_drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7671);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4684);
/* harmony import */ var _components_navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5229);
/* harmony import */ var _components_order_list__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9695);
/* harmony import */ var _components_wallet_add__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4740);
/* harmony import */ var _components_wallet_history__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7617);
/* harmony import */ var _components_wallet_transfer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6461);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8942);
/* harmony import */ var _components_looks_detail__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1716);
/* harmony import */ var _components_navbar_BrandList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7586);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_address_enter_delivery_address__WEBPACK_IMPORTED_MODULE_2__, _components_drawer__WEBPACK_IMPORTED_MODULE_3__, _components_navbar__WEBPACK_IMPORTED_MODULE_5__, _components_order_list__WEBPACK_IMPORTED_MODULE_6__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__, _components_looks_detail__WEBPACK_IMPORTED_MODULE_11__, _components_navbar_BrandList__WEBPACK_IMPORTED_MODULE_12__]);
([_components_address_enter_delivery_address__WEBPACK_IMPORTED_MODULE_2__, _components_drawer__WEBPACK_IMPORTED_MODULE_3__, _components_navbar__WEBPACK_IMPORTED_MODULE_5__, _components_order_list__WEBPACK_IMPORTED_MODULE_6__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__, _components_looks_detail__WEBPACK_IMPORTED_MODULE_11__, _components_navbar_BrandList__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Layout = ({ children  })=>{
    const { isOpen , setIsOpen , open , setOpen , content , setContent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_10__/* .MainContext */ .T);
    const handleContent = (key)=>{
        setContent(key);
        setOpen(true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!content) setOpen(false);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_navbar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        handleContent: handleContent
                    }),
                    children,
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_drawer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        title: "Top up wallet",
                        open: open,
                        setOpen: setOpen,
                        children: [
                            content === "add-wallet" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_wallet_add__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                            content === "transfer-wallet" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_wallet_transfer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                            content === "wallet-history" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_wallet_history__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                            content === "order-list" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_order_list__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                setOpen: setOpen
                            }),
                            isOpen === "enter-address" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_address_enter_delivery_address__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                setIsOpen: setIsOpen,
                                setOpen: setOpen
                            }),
                            content === "show-look" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_looks_detail__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                open: open
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                onClick: ()=>setIsOpen(null),
                className: isOpen ? "backdrop" : "d-none"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2969);
/* harmony import */ var _layouts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5356);
/* harmony import */ var _components_loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4213);
/* harmony import */ var _components_push_notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5529);
/* harmony import */ var _components_loader_ripple_btn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(552);
/* harmony import */ var _components_drawer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7671);
/* harmony import */ var _components_chat_chat__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1434);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9054);
/* harmony import */ var _services_i18next__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3224);
/* harmony import */ var _services_informationService__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5464);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_provider__WEBPACK_IMPORTED_MODULE_4__, _layouts__WEBPACK_IMPORTED_MODULE_5__, _components_push_notification__WEBPACK_IMPORTED_MODULE_7__, _components_loader_ripple_btn__WEBPACK_IMPORTED_MODULE_8__, _components_drawer__WEBPACK_IMPORTED_MODULE_9__, _components_chat_chat__WEBPACK_IMPORTED_MODULE_10__, _services_i18next__WEBPACK_IMPORTED_MODULE_12__, _services_informationService__WEBPACK_IMPORTED_MODULE_13__]);
([_components_provider__WEBPACK_IMPORTED_MODULE_4__, _layouts__WEBPACK_IMPORTED_MODULE_5__, _components_push_notification__WEBPACK_IMPORTED_MODULE_7__, _components_loader_ripple_btn__WEBPACK_IMPORTED_MODULE_8__, _components_drawer__WEBPACK_IMPORTED_MODULE_9__, _components_chat_chat__WEBPACK_IMPORTED_MODULE_10__, _services_i18next__WEBPACK_IMPORTED_MODULE_12__, _services_informationService__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















const WithOutLayout = [
    "/settings",
    "/order-history",
    "/checkout",
    "/auth/sign-in",
    "/auth/sign-up",
    "/be-seller",
    "/invite",
    "/payment",
    "/forget-password", 
];
if (true) {
    console.log = ()=>{};
    console.error = ()=>{};
    console.debug = ()=>{};
}
function MyApp({ Component , pageProps  }) {
    const cookie = (0,nookies__WEBPACK_IMPORTED_MODULE_14__.parseCookies)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const windowSize = (0,_utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { 0: loader , 1: setLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const { 0: openChat , 1: setOpenChat  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    next_router__WEBPACK_IMPORTED_MODULE_2__.Router.events.on("routeChangeStart", ()=>setLoader(true));
    next_router__WEBPACK_IMPORTED_MODULE_2__.Router.events.on("routeChangeComplete", ()=>setLoader(false));
    next_router__WEBPACK_IMPORTED_MODULE_2__.Router.events.on("routeChangeError", ()=>setLoader(false));
    const isWithOutLayout = WithOutLayout.find((item)=>router.pathname.includes(item));
    function fetchTranslations() {
        const lang = cookie.language_locale || "en";
        const params = {
            lang
        };
        setLoader(true);
        _services_informationService__WEBPACK_IMPORTED_MODULE_13__/* ["default"].translations */ .Z.translations(params).then(({ data  })=>{
            _services_i18next__WEBPACK_IMPORTED_MODULE_12__/* ["default"].addResourceBundle */ .Z.addResourceBundle(lang, "translation", data.data);
            _services_i18next__WEBPACK_IMPORTED_MODULE_12__/* ["default"].changeLanguage */ .Z.changeLanguage(lang);
        }).finally(()=>setLoader(false));
    }
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        fetchTranslations();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        window.scrollTo(0, 0);
    }, [
        pathname
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_i18next__WEBPACK_IMPORTED_MODULE_15__.I18nextProvider, {
        i18n: _services_i18next__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_provider__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            setLoader: setLoader,
            children: [
                cookie.access_token && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_push_notification__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                loader && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                !isWithOutLayout ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_layouts__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Component, {
                        setLoader: setLoader,
                        ...pageProps
                    })
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Component, {
                    setOpenChat: setOpenChat,
                    setLoader: setLoader,
                    ...pageProps
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_ripple_btn__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    onClick: setOpenChat
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_drawer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    header: windowSize.width > 768 ? false : true,
                    size: windowSize.width > 768 ? 400 : null,
                    direction: windowSize.width > 768 ? "right" : "bottom",
                    open: openChat,
                    setOpen: setOpenChat,
                    className: "chat-drawer",
                    title: false,
                    children: openChat && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_chat_chat__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        windowSize: windowSize
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5464:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4368);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth__WEBPACK_IMPORTED_MODULE_0__]);
_auth__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const informationService = {
    translations: (params)=>_auth__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/api/v1/rest/translations/paginate", {
            params
        }),
    settingsInfo: (params)=>request.get("/api/v1/rest/settings", {
            params
        })
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (informationService);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ getMessages)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

function getMessages(chat) {
    const { messages , currentChat  } = chat;
    if (!currentChat) return [];
    const groups = messages.filter((item)=>item.chat_id === currentChat.id).reduce((groups, item)=>{
        const date = moment__WEBPACK_IMPORTED_MODULE_0___default()(new Date(item.created_at)).format("DD-MM-YYYY");
        if (!groups[date]) {
            groups[date] = [];
        }
        groups[date].push(item);
        return groups;
    }, {});
    const groupArrays = Object.keys(groups).map((date)=>{
        return {
            date,
            messages: groups[date]
        };
    });
    return groupArrays;
}


/***/ }),

/***/ 3536:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ getNotification)
/* harmony export */ });
/* harmony import */ var firebase_messaging__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3512);
/* harmony import */ var _api_main_user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4827);
/* harmony import */ var _services_firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6813);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_messaging__WEBPACK_IMPORTED_MODULE_0__, _services_firebase__WEBPACK_IMPORTED_MODULE_2__]);
([firebase_messaging__WEBPACK_IMPORTED_MODULE_0__, _services_firebase__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getNotification = ({ vapid_key , setNotificationData  })=>{
    const messaging = (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_0__.getMessaging)(_services_firebase__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP);
    (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_0__.getToken)(messaging, {
        vapid_key
    }).then((currentToken)=>{
        if (currentToken) {
            _api_main_user__WEBPACK_IMPORTED_MODULE_1__/* .UserApi.firebaseTokenUpdate */ .W.firebaseTokenUpdate({
                firebase_token: currentToken
            }).then(()=>{}).catch((error)=>{
                console.log(error);
            });
            (0,firebase_messaging__WEBPACK_IMPORTED_MODULE_0__.onMessage)(messaging, (payload)=>{
                setNotificationData(payload.notification);
            });
        } else {
            console.log("No registration token available. Request permission to generate one.");
        }
    }).catch((err)=>{
        console.log("An error occurred while retrieving token. ", err);
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8237:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8942);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__]);
_contexts_MainContext__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * Hook that alerts clicks outside of the passed ref
 */ function useOutsideAlerter(ref) {
    const { setIsOpenDropdown , isOpenDropdown  } = useContext(MainContext);
    useEffect(()=>{
        /**
     * Alert if clicked on outside of element
     */ function handleClickOutside(event) {
            if (ref.current && !ref.current.contains(event.target)) {
                if (!isOpenDropdown) setIsOpenDropdown(false);
            }
        }
        // Bind the event listener
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            // Unbind the event listener on clean up
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ref
    ]);
}
/**
 * Component that alerts if you click outside of it
 */ function OutsideAlerter(props) {
    const wrapperRef = useRef(null);
    useOutsideAlerter(wrapperRef);
    return /*#__PURE__*/ _jsx("div", {
        ref: wrapperRef,
        children: props.children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ scrollTo)
/* harmony export */ });
function scrollTo(element, to, duration) {
    var start = element.scrollTop, change = to - start, currentTime = 0, increment = 20;
    var animateScroll = function() {
        currentTime += increment;
        var val = Math.easeInOutQuad(currentTime, start, change, duration);
        element.scrollTop = val;
        if (currentTime < duration) {
            setTimeout(animateScroll, increment);
        }
    };
    animateScroll();
}
//t = current time
//b = start value
//c = change in value
//d = duration
Math.easeInOutQuad = function(t, b, c, d) {
    t /= d / 2;
    if (t < 1) return c / 2 * t * t + b;
    t--;
    return -c / 2 * (t * (t - 2) - 1) + b;
};


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 1380:
/***/ ((module) => {

"use strict";
module.exports = require("@chatscope/chat-ui-kit-react");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 4573:
/***/ ((module) => {

"use strict";
module.exports = require("google-maps-react");

/***/ }),

/***/ 5448:
/***/ ((module) => {

"use strict";
module.exports = require("hex-color-to-color-name");

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 7104:
/***/ ((module) => {

"use strict";
module.exports = require("qs");

/***/ }),

/***/ 1817:
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

"use strict";
module.exports = require("react-content-loader");

/***/ }),

/***/ 7276:
/***/ ((module) => {

"use strict";
module.exports = require("react-google-autocomplete");

/***/ }),

/***/ 9709:
/***/ ((module) => {

"use strict";
module.exports = require("react-i18next");

/***/ }),

/***/ 4108:
/***/ ((module) => {

"use strict";
module.exports = require("react-modern-drawer");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4161:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ 1127:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 8936:
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 160:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/AddCircleFillIcon");

/***/ }),

/***/ 5265:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/AddLineIcon");

/***/ }),

/***/ 4237:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ArrowDownSLineIcon");

/***/ }),

/***/ 1116:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ArrowLeftSLineIcon");

/***/ }),

/***/ 1406:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ArrowRightSLineIcon");

/***/ }),

/***/ 5225:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Bookmark3LineIcon");

/***/ }),

/***/ 991:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CheckDoubleLineIcon");

/***/ }),

/***/ 97:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CheckboxBlankLineIcon");

/***/ }),

/***/ 266:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CheckboxFillIcon");

/***/ }),

/***/ 1060:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CloseFillIcon");

/***/ }),

/***/ 4926:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/CustomerService2LineIcon");

/***/ }),

/***/ 6449:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/DeleteBin3LineIcon");

/***/ }),

/***/ 8553:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/DeleteBinLineIcon");

/***/ }),

/***/ 865:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/EqualizerFillIcon");

/***/ }),

/***/ 2394:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/EyeLineIcon");

/***/ }),

/***/ 3843:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/FileListFillIcon");

/***/ }),

/***/ 9418:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/FileListLineIcon");

/***/ }),

/***/ 2595:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Filter3LineIcon");

/***/ }),

/***/ 62:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/FlashlightFillIcon");

/***/ }),

/***/ 1257:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Heart3FillIcon");

/***/ }),

/***/ 9348:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Heart3LineIcon");

/***/ }),

/***/ 6582:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/HeartLineIcon");

/***/ }),

/***/ 1967:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ImageLineIcon");

/***/ }),

/***/ 9090:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/LayoutGridLineIcon");

/***/ }),

/***/ 4565:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/LinksLineIcon");

/***/ }),

/***/ 8743:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/LoginCircleLineIcon");

/***/ }),

/***/ 2324:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/LogoutCircleRLineIcon");

/***/ }),

/***/ 1713:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/MapPinLineIcon");

/***/ }),

/***/ 2182:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Message3LineIcon");

/***/ }),

/***/ 6977:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/NavigationFillIcon");

/***/ }),

/***/ 4078:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Notification4LineIcon");

/***/ }),

/***/ 6982:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/PauseFillIcon");

/***/ }),

/***/ 2271:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/PercentLineIcon");

/***/ }),

/***/ 6292:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/QrScanLineIcon");

/***/ }),

/***/ 8428:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Search2LineIcon");

/***/ }),

/***/ 3455:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/SendPlaneLineIcon");

/***/ }),

/***/ 7481:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/ShoppingCartLineIcon");

/***/ }),

/***/ 8244:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/StarFillIcon");

/***/ }),

/***/ 6359:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Store3FillIcon");

/***/ }),

/***/ 8249:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/StoreLineIcon");

/***/ }),

/***/ 3132:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/SubtractLineIcon");

/***/ }),

/***/ 2923:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/TimeLineIcon");

/***/ }),

/***/ 3596:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/UserSearchLineIcon");

/***/ }),

/***/ 3281:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/UserSettingsLineIcon");

/***/ }),

/***/ 4136:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Wallet2LineIcon");

/***/ }),

/***/ 907:
/***/ ((module) => {

"use strict";
module.exports = require("remixicon-react/Wallet3LineIcon");

/***/ }),

/***/ 3745:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ 401:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/auth");;

/***/ }),

/***/ 1492:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ }),

/***/ 3512:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/messaging");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 4009:
/***/ ((module) => {

"use strict";
module.exports = import("react-intersection-observer");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,1664,5675,3181,2622,4527,8942,3006,7671,1478,9919,1323,9253,9237,3788,3604,1835,8999,9054,2045,6931,2231,7291,5080,5913,7586,7617], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();