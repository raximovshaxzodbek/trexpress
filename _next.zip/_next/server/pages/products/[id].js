"use strict";
(() => {
var exports = {};
exports.id = 9304;
exports.ids = [9304];
exports.modules = {

/***/ 2197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ CommentApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class CommentApi {
    static endpoint = "/api/v1/rest/products/review";
    static create(data, uuid) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(`${this.endpoint}/${uuid}`, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
}


/***/ }),

/***/ 4901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ UploadApi)
/* harmony export */ });
/* harmony import */ var _mainCaller__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2622);
/* harmony import */ var _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9722);


class UploadApi {
    static endpoint = "/api/v1/dashboard/galleries";
    static create(data) {
        return (0,_mainCaller__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this.endpoint, _HTTPMethods__WEBPACK_IMPORTED_MODULE_1__/* ["default"].POST */ .ZP.POST, data);
    }
}


/***/ }),

/***/ 9315:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9054);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7821);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ImgMagnify = ({ galleries =[] , targetImg ={} , direction  })=>{
    const { 0: thumbsSwiper , 1: setThumbsSwiper  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: gallery , 1: setGallery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(galleries);
    const windowSize = (0,_utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const index = galleries.findIndex((item)=>item.path === targetImg?.value);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (index < 0 && targetImg?.value) {
            galleries.splice(1, 1, {
                path: targetImg.value
            });
        }
        setGallery(galleries);
    }, [
        targetImg?.value,
        galleries
    ]);
    if (!targetImg) {
        return "";
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "img-magnify",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                onSwiper: setThumbsSwiper,
                spaceBetween: 16,
                slidesPerView: 10,
                freeMode: true,
                watchSlidesProgress: true,
                modules: [
                    swiper__WEBPACK_IMPORTED_MODULE_3__.FreeMode,
                    swiper__WEBPACK_IMPORTED_MODULE_3__.Thumbs
                ],
                className: "swiper-sm",
                direction: direction ? direction : windowSize?.width >= 960 ? "vertical" : "horizontal",
                children: gallery?.map((img, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: _constants__WEBPACK_IMPORTED_MODULE_5__/* .imgBaseUrl */ .XW + img.path
                        })
                    }, key))
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                slidesPerView: 2,
                spaceBetween: 10,
                thumbs: {
                    swiper: thumbsSwiper
                },
                modules: [
                    swiper__WEBPACK_IMPORTED_MODULE_3__.FreeMode,
                    swiper__WEBPACK_IMPORTED_MODULE_3__.Thumbs
                ],
                className: "swiper-lg",
                breakpoints: {
                    360: {
                        slidesPerView: 1,
                        spaceBetween: 0
                    },
                    1200: {
                        slidesPerView: 2
                    }
                },
                children: gallery?.map((img, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: _constants__WEBPACK_IMPORTED_MODULE_5__/* .imgBaseUrl */ .XW + img.path
                        })
                    }, key))
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                id: "myPortal"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgMagnify);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2630:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3006);
/* harmony import */ var remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9112);
/* harmony import */ var remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6487);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5265);
/* harmony import */ var remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3132);
/* harmony import */ var remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6419);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_rating__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _accordion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7952);
/* harmony import */ var _accordion_accordion_summary__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6694);
/* harmony import */ var _accordion_accordion_details__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4021);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3788);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7821);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3590);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8942);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _utils_getPrice__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6520);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_15__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_15__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const ProductData = ({ setOpen , product , setTargetImgExtra , properties , description ,  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_17__.useTranslation)();
    const { setDrawerTitle , setShop  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_16__/* .MainContext */ .T);
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.cart);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useDispatch)();
    const { 0: idList , 1: setIdList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: extras , 1: setExtras  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: reviewCount , 1: setReviewCount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(3);
    const { 0: stock , 1: setStock  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: showExtras , 1: setShowExtras  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: extrasIds , 1: setExtrasIds  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const targetProductImg = extrasIds.find((item)=>item.group.type === "image");
    const currentProduct = cart.cartItems.find((item)=>item?.stockId?.id === showExtras?.stock?.id);
    const handleClick = (key)=>{
        const includes = idList.includes(key);
        if (includes) {
            setIdList(idList.filter((item)=>item !== key));
        } else {
            setIdList([
                ...idList,
                key
            ]);
        }
    };
    const handelAddToCart = ()=>{
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .addToCart */ .Xq)({
            product_id: product.id,
            id: showExtras?.stock.id,
            translation: product.translation,
            extras: extrasIds,
            img: targetProductImg ? targetProductImg.value : product.img,
            stockId: showExtras?.stock,
            min_qty: product.min_qty,
            max_qty: product.max_qty,
            tax: product.tax,
            price: showExtras?.stock.price,
            shop_tax: product.shop.tax,
            discount: showExtras?.stock.discount ? showExtras?.stock.discount : 0,
            stocks: product.stocks,
            shop: {
                id: product.shop.id,
                translation: product.shop.translation,
                logo: product.shop.logo_img,
                tax: product.shop.tax,
                close_time: product.shop.close_time,
                open_time: product.shop.open_time,
                location: product.shop.location
            }
        }));
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .getTotals */ .j_)());
    };
    const handleDec = ()=>{
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .decreaseCart */ .Bq)(currentProduct));
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .getTotals */ .j_)());
    };
    const handleInc = ()=>{
        if (currentProduct.qty >= product.max_qty || currentProduct.qty >= showExtras?.stock?.quantity) {
            react_toastify__WEBPACK_IMPORTED_MODULE_15__.toast.warn(`${tl("You can buy only")} ${product.max_qty > showExtras?.stock?.quantity ? showExtras?.stock?.quantity : product.max_qty} ${tl("products")}`);
        } else dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .addToCart */ .Xq)(currentProduct));
        dispatch((0,_redux_slices_cart__WEBPACK_IMPORTED_MODULE_13__/* .getTotals */ .j_)());
    };
    function sortExtras(object) {
        var extras = [];
        var stocks = [];
        var up = "";
        for(var i = 0; i < object["stocks"].length; i++){
            up = "";
            for(var k = 0; k < object["stocks"][i]["extras"].length; k++){
                var extra = Object.assign({}, object["stocks"][i]["extras"][k]);
                var index = extras.findIndex((item)=>item["id"] == extra["id"]);
                if (index == -1) {
                    extra["level"] = k;
                    extra["up"] = [
                        up
                    ];
                    extras.push(extra);
                    up += extra["id"].toString();
                } else {
                    extras[index]["up"].push(up);
                    up += extra["id"].toString();
                }
            }
            var mdata = {
                id: object["stocks"][i]["id"],
                extras: up,
                price: object["stocks"][i]["price"],
                quantity: object["stocks"][i]["quantity"],
                countable_id: object["stocks"][i]["countable_id"],
                discount: object["stocks"][i]["discount"],
                total_price: object["stocks"][i]["total_price"]
            };
            stocks.push(mdata);
        }
        return {
            stock: stocks,
            extras: extras
        };
    }
    function getExtras(extrasIdsArray, extras, stocks) {
        var splitted = extrasIdsArray == "" ? [] : extrasIdsArray.split(",");
        var result = [];
        var up = [];
        for(var i = 0; i <= splitted.length; i++){
            if (i - 1 >= 0) up[up.length] = splitted[i - 1].toString();
            var filtered = extras.filter((item)=>{
                var mySet = new Set(item["up"]);
                if (mySet.has(up.join(""))) return item;
            });
            if (filtered.length > 0) result.push(filtered);
        }
        var i = 0;
        if (up.length < result.length) while(i < extras.length){
            up[up.length] = result[result.length - 1][0]["id"].toString();
            var filtered = extras.filter((item)=>{
                var mySet = new Set(item["up"]);
                if (mySet.has(up.join(""))) return item;
            });
            if (filtered.length == 0) {
                break;
            }
            result.push(filtered);
            i++;
        }
        var index = stocks.findIndex((item)=>item["extras"] == up.join(""));
        return {
            stock: stocks[index],
            extras: result
        };
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const myData = sortExtras(product);
        setExtras(myData.extras);
        setStock(myData.stock);
        setShowExtras(getExtras("", myData.extras, myData.stock));
        getExtras("", myData.extras, myData.stock).extras?.forEach((element)=>{
            setExtrasIds((prev)=>[
                    ...prev,
                    element[0]
                ]);
            setTargetImgExtra((prev)=>[
                    ...prev,
                    element[0]
                ]);
        });
        setShop(product.shop);
    }, [
        product
    ]);
    const handleExtrasClick = (e)=>{
        const index = extrasIds.findIndex((item)=>item.extra_group_id === e.extra_group_id);
        const array = extrasIds;
        if (index > -1) array = array.slice(0, index);
        array.push(e);
        const nextIds = array.map((item)=>item.id).join(",");
        var extrasData = getExtras(nextIds, extras, stock);
        setShowExtras(extrasData);
        extrasData.extras?.forEach((element)=>{
            const index = extrasIds.findIndex((item)=>element[0].extra_group_id != e.extra_group_id ? item.extra_group_id === element[0].extra_group_id : item.extra_group_id === e.extra_group_id);
            if (element[0].level >= e.level) {
                var itemData = element[0].extra_group_id != e.extra_group_id ? element[0] : e;
                if (index == -1) array.push(itemData);
                else {
                    array[index] = itemData;
                }
            }
        });
        setExtrasIds(array);
        setTargetImgExtra(array);
    };
    const click = ()=>{
        setOpen(true);
        setDrawerTitle("Write a feedback");
    };
    const getRating = (key)=>{
        return product?.rating_percent[key]?.toFixed(1);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "product-data",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "color-size",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "price",
                        children: showExtras?.stock?.discount ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "current-price",
                                    children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_18__/* .getPrice */ .a)(showExtras?.stock?.price - showExtras?.stock?.discount)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "old-price",
                                    children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_18__/* .getPrice */ .a)(showExtras?.stock?.price)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "discount",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_constants_images__WEBPACK_IMPORTED_MODULE_2__/* .SaleIcon */ .rG, {}),
                                        `${tl("Sale")} ${(showExtras?.stock?.discount / showExtras?.stock?.price * 100).toFixed(1)} %`
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "current-price",
                            children: (0,_utils_getPrice__WEBPACK_IMPORTED_MODULE_18__/* .getPrice */ .a)(showExtras?.stock?.price)
                        })
                    }),
                    showExtras.extras?.map((item, key)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: item[0]?.group.type === "color" ? "extras color" : "extras",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "title",
                                    children: item[0]?.group.translation.title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "items",
                                    children: item?.map((e, key)=>{
                                        const isActive = extrasIds?.findIndex((item)=>item.id === e.id);
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: isActive >= 0 ? "item active" : "item",
                                            style: e.group.type === "color" ? {
                                                background: e.value
                                            } : {},
                                            onClick: ()=>handleExtrasClick(e),
                                            children: [
                                                isActive >= 0 && e.group.type !== "text" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: "active"
                                                }),
                                                e.group.type === "text" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: e.value
                                                }),
                                                e.group.type === "image" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                                    src: _constants__WEBPACK_IMPORTED_MODULE_14__/* .imgBaseUrl */ .XW + e.value
                                                })
                                            ]
                                        }, key);
                                    })
                                })
                            ]
                        }, key);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "stock",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_constants_images__WEBPACK_IMPORTED_MODULE_2__/* .StockIcon */ .Oc, {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: `${showExtras?.stock?.quantity >= 0 ? showExtras?.stock?.quantity + tl(" in stock") : tl("out of stock")}`
                            })
                        ]
                    })
                ]
            }),
            currentProduct ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "inc-dec",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "inc",
                        onClick: handleDec,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_SubtractLineIcon__WEBPACK_IMPORTED_MODULE_6___default()), {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                        children: `${currentProduct?.qty}  ${tl("items in cart")}`
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "dec",
                        onClick: handleInc,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_AddLineIcon__WEBPACK_IMPORTED_MODULE_5___default()), {})
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                disabled: showExtras?.stock?.quantity >= product?.min_qty ? false : true,
                className: "add-to-card",
                onClick: handelAddToCart,
                children: showExtras?.stock?.quantity >= product?.min_qty ? tl("Add to cart") : tl("out of stock")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flavor-name description",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_accordion__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        idList: idList,
                        id: "description",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_accordion_accordion_summary__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                handleClick: handleClick,
                                idList: idList,
                                id: "description",
                                children: tl("Description")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_accordion_accordion_details__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                children: description
                            })
                        ]
                    }),
                    properties?.map((item, id)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_accordion__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            idList: idList,
                            id: id,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_accordion_accordion_summary__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    handleClick: handleClick,
                                    idList: idList,
                                    id: id,
                                    children: item.key
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_accordion_accordion_details__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    children: item.value
                                })
                            ]
                        }, id);
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "add-review",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "review-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "title",
                                children: tl("Reviews")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "add-comment",
                                onClick: click,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        size: 16
                                    }),
                                    tl("Add comment")
                                ]
                            })
                        ]
                    }),
                    product.reviews.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "slider",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rate-slider",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "label",
                                                children: "5"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                disabled: true,
                                                value: product?.rating_percent[5]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "percent",
                                                children: `${getRating(5) ? getRating(5) : 0}%`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rate-slider",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "label",
                                                children: "4"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                disabled: true,
                                                value: product?.rating_percent[4]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "percent",
                                                children: `${getRating(4) ? getRating(4) : 0}%`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rate-slider",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "label",
                                                children: "3"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                disabled: true,
                                                value: product?.rating_percent[3]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "percent",
                                                children: `${getRating(3) ? getRating(3) : 0}%`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rate-slider",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "label",
                                                children: "2"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                disabled: true,
                                                value: product?.rating_percent[2]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "percent",
                                                children: `${getRating(2) ? getRating(2) : 0}%`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "rate-slider",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "label",
                                                children: "1"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((rc_slider__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                disabled: true,
                                                value: product?.rating_percent[1]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "percent",
                                                children: `${getRating(1) ? getRating(1) : 0}%`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "final-rate",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_rating__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                readonly: true,
                                                className: "rating-star",
                                                initialRating: product?.rating_avg,
                                                emptySymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                                                fullSymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    color: "#FFB800"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    " ",
                                                    `${product?.rating_avg?.toFixed(1)} out of 5.0`
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "comment-items",
                                children: product?.reviews?.slice(0, reviewCount)?.sort((a, b)=>b.id - a.id)?.map((item, key)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "item",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "comment-header",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "user",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: "name",
                                                                children: `${item.user.firstname} ${item.user.lastname}`
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                className: "time",
                                                                children: item.created_at
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "rate",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                size: 18,
                                                                color: "#FFB800"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                                children: item?.rating
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "example-images",
                                                children: item.galleries?.map((img, key)=>{
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                                        src: _constants__WEBPACK_IMPORTED_MODULE_14__/* .imgBaseUrl */ .XW + img.path,
                                                        alt: "product"
                                                    }, key);
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "comment-text",
                                                children: item.comment
                                            })
                                        ]
                                    }, key);
                                })
                            }),
                            product.reviews.length > 3 && reviewCount < product.reviews.length && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "load-more",
                                onClick: ()=>setReviewCount(product.reviews.length),
                                children: tl("Load more")
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6487);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var remixicon_react_UploadCloud2LineIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8280);
/* harmony import */ var remixicon_react_UploadCloud2LineIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_UploadCloud2LineIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var remixicon_react_DeleteBin5LineIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4713);
/* harmony import */ var remixicon_react_DeleteBin5LineIcon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_DeleteBin5LineIcon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6419);
/* harmony import */ var react_rating__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_rating__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _form_msg_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7317);
/* harmony import */ var _api_main_upload__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4901);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3590);
/* harmony import */ var _api_main_comment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2197);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_8__]);
react_toastify__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const ProductRate = ({ uuid , setOpen , getProduct  })=>{
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)();
    const { 0: file , 1: setFile  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: gallery , 1: setGallery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: rating , 1: setRating  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: comment , 1: setComment  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: uploadImages , 1: setUploadImages  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fileSelectedHandler = (event)=>{
        if (event.target.files[0].type === "image/jpeg" || event.target.files[0].type === "image/png" || event.target.files[0].type === "image/svg") {
            setFile([
                ...file,
                event.target.files[0]
            ]);
            const images = new FormData();
            images.append("image", event.target.files[0]);
            images.append("type", "reviews");
            _api_main_upload__WEBPACK_IMPORTED_MODULE_7__/* .UploadApi.create */ .t.create(images).then((res)=>{
                setUploadImages([
                    ...uploadImages,
                    res.data.title
                ]);
            }).catch((error)=>{
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error("Error");
            });
            const reader = new FileReader();
            reader.onload = ()=>{
                if (reader.readyState === 2) {
                    setGallery([
                        ...gallery,
                        reader.result
                    ]);
                }
            };
            reader.readAsDataURL(event.target.files[0]);
        } else {
            react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(tl("You need to select jpeg, png or svg file"));
        }
    };
    const onSubmit = (e)=>{
        e.preventDefault();
        if (rating || comment) {
            _api_main_comment__WEBPACK_IMPORTED_MODULE_9__/* .CommentApi.create */ .W.create({
                rating,
                comment,
                images: uploadImages
            }, uuid).then(()=>{
                react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.success("Success");
                handleClear();
            }).catch((error)=>{
                console.log(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(error.response.data.message);
            }).finally(()=>{
                getProduct(uuid);
            });
        } else {
            react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error(tl("Please write a review first"));
        }
    };
    const handleDelete = (key)=>{
        gallery.splice(key, 1);
        uploadImages.splice(key, 1);
        file.splice(key, 1);
        setGallery([
            ...gallery
        ]);
        setUploadImages([
            ...uploadImages
        ]);
        setFile([
            ...file
        ]);
    };
    const handleClear = ()=>{
        setOpen(false);
        setComment("");
        setRating(0);
        setGallery([]);
        setFile([]);
        setUploadImages([]);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "product-rate",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "content",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "left",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_form_msg_input__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    value: comment,
                                    onChange: (e)=>setComment(e.target.value)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "add-rate",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "add-rating",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_rating__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            className: "rating-star",
                                            initialRating: rating,
                                            emptySymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {}),
                                            fullSymbol: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                color: "#FFB800"
                                            }),
                                            onClick: (value)=>setRating(value)
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "upload-wrapper",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                            type: "file",
                                            style: {
                                                display: "none"
                                            },
                                            onChange: fileSelectedHandler,
                                            required: true,
                                            multiple: true,
                                            disabled: file?.length > 3 ? true : false
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "upload-image",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_UploadCloud2LineIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    size: 30
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                                    children: tl("Upload product photo")
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("small", {
                                                    children: tl("Max 4 photo")
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "images",
                                    children: gallery?.map((src, key)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "img-wrapper",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                                    src: src,
                                                    alt: "product"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                    className: "remove-img",
                                                    onClick: ()=>handleDelete(key),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_DeleteBin5LineIcon__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        size: 32,
                                                        color: "#fff"
                                                    })
                                                })
                                            ]
                                        }, key);
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "btn-group",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "btn-dark",
                        onClick: onSubmit,
                        children: tl("Send")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                        className: "btn-default",
                        onClick: handleClear,
                        children: tl("Clear")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductRate);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8278:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_drawer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7671);
/* harmony import */ var _components_products_detail_img_magnify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9315);
/* harmony import */ var _components_products_detail_product_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2630);
/* harmony import */ var _components_products_detail_rate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5458);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9348);
/* harmony import */ var remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1257);
/* harmony import */ var remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6487);
/* harmony import */ var remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9112);
/* harmony import */ var remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_axios__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3181);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7169);
/* harmony import */ var _components_products_section__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9253);
/* harmony import */ var _components_products_card__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9237);
/* harmony import */ var _components_empty_data__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1478);
/* harmony import */ var _constants_images__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3006);
/* harmony import */ var _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8942);
/* harmony import */ var _api_main_product__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4391);
/* harmony import */ var _utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9054);
/* harmony import */ var _components_seo__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3304);
/* harmony import */ var _components_loader_product__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(6634);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_drawer__WEBPACK_IMPORTED_MODULE_3__, _components_products_detail_img_magnify__WEBPACK_IMPORTED_MODULE_4__, _components_products_detail_product_data__WEBPACK_IMPORTED_MODULE_5__, _components_products_detail_rate__WEBPACK_IMPORTED_MODULE_6__, _components_products_section__WEBPACK_IMPORTED_MODULE_15__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_19__]);
([_components_drawer__WEBPACK_IMPORTED_MODULE_3__, _components_products_detail_img_magnify__WEBPACK_IMPORTED_MODULE_4__, _components_products_detail_product_data__WEBPACK_IMPORTED_MODULE_5__, _components_products_detail_rate__WEBPACK_IMPORTED_MODULE_6__, _components_products_section__WEBPACK_IMPORTED_MODULE_15__, _utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
























const ProductDetail = ({ productData  })=>{
    const windowSize = (0,_utils_hooks_useWindowSize__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z)();
    const { t: tl  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)();
    const { setDrawerTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_contexts_MainContext__WEBPACK_IMPORTED_MODULE_19__/* .MainContext */ .T);
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(productData);
    const { 0: relatedProduct , 1: setRelatedProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: targetImgExtra , 1: setTargetImgExtra  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useDispatch)();
    const likedProducts = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.savedProduct.savedProductList);
    const viewedProduct = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)((state)=>state.viewedProduct.viewedProductList);
    const isLiked = likedProducts.find((lp)=>lp.id === data?.id);
    const getProduct = (uuid)=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_20__/* .ProductApi.getId */ .y.getId(uuid).then((res)=>{
            setData(res.data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    const click = ()=>{
        setOpen(true);
        setDrawerTitle("Write a feedback");
    };
    const getRelatedProduct = ()=>{
        _api_main_product__WEBPACK_IMPORTED_MODULE_20__/* .ProductApi.get */ .y.get({
            brand_id: productData?.brand_id,
            category_id: productData?.category_id,
            perPage: 3
        }).then((res)=>{
            setRelatedProduct(res.data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setData(productData);
    }, [
        productData.id
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getRelatedProduct();
    }, []);
    const targetImg = targetImgExtra.find((item)=>item?.group?.type === "image");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_seo__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                title: productData?.translation?.title,
                description: productData?.translation?.description,
                keywords: productData?.translation?.description
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "product-detail",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "detail-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "product-name",
                                children: data.translation.title
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "left",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "reviews",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_StarSmileFillIcon__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                size: 18,
                                                color: "#FFB800"
                                            }),
                                            `${data?.rating_avg ? data?.rating_avg?.toFixed(1) : 0} (${data?.reviews_count ? data.reviews_count : 0} ${tl("reviews")})`
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "add-comment",
                                        onClick: click,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Message2FillIcon__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                size: 16
                                            }),
                                            tl("Add comment")
                                        ]
                                    }),
                                    isLiked ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "liked",
                                        onClick: ()=>dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_14__/* .removeFromSaved */ .YH)(data)),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3FillIcon__WEBPACK_IMPORTED_MODULE_8___default()), {
                                            size: 24
                                        })
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                        className: "liked",
                                        onClick: ()=>dispatch((0,_redux_slices_savedProduct__WEBPACK_IMPORTED_MODULE_14__/* .addToSaved */ .IV)(data)),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((remixicon_react_Heart3LineIcon__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            size: 24
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "detail-content",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "magnify-wrapper",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_detail_img_magnify__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        targetImg: targetImg,
                                        galleries: data.galleries
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "store-description",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "description",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                        className: "title",
                                                        children: tl("Description")
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                                        children: data.translation.description
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                className: "information",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "items",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                            className: "title",
                                                            children: tl("Additional information")
                                                        }),
                                                        data.properties?.map((item, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: item?.value?.length > 28 ? "item column" : "item",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: "key",
                                                                        children: item.key
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                                                        className: "value link",
                                                                        children: item.value
                                                                    })
                                                                ]
                                                            }, key))
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    windowSize.width > 768 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_products_section__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                title: "Releted products",
                                                children: [
                                                    relatedProduct ? relatedProduct.filter((item)=>item.id !== productData.id).map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_card__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                            product: product
                                                        }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_loader_product__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {})
                                                        ]
                                                    }),
                                                    relatedProduct?.length < 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                        image: _constants_images__WEBPACK_IMPORTED_MODULE_18__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                                        text1: "There are no items in the related products"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_section__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                title: "Viewed products",
                                                href: "/stores/viewed-product",
                                                children: viewedProduct.length > 0 ? viewedProduct.slice(0, 3).map((product, key)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_card__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                        product: product
                                                    }, key)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_empty_data__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    image: _constants_images__WEBPACK_IMPORTED_MODULE_18__/* .images.ViewedProduct */ .Wc.ViewedProduct,
                                                    text1: "There are no items in the viewed products",
                                                    text2: "To select items, go to the stores"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                className: "product-data-wrapper",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_detail_product_data__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    product: data,
                                    setOpen: setOpen,
                                    setTargetImgExtra: setTargetImgExtra,
                                    properties: data.properties,
                                    description: data.translation.description
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_drawer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        open: open,
                        setOpen: setOpen,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_products_detail_rate__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            getProduct: getProduct,
                            setOpen: setOpen,
                            uuid: data.uuid
                        })
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { query  } = ctx;
    const cookies = nookies__WEBPACK_IMPORTED_MODULE_2___default().get(ctx);
    const currency_id = cookies?.currency_id;
    const language_id = cookies?.language_id;
    const language_locale = cookies?.language_locale;
    const res = await _services_axios__WEBPACK_IMPORTED_MODULE_12__/* ["default"].get */ .Z.get(`/api/v1/rest/products/${query.id}`, {
        params: {
            currency_id,
            language_id,
            lang: language_locale
        }
    });
    const productData = await res.data.data;
    return {
        props: {
            productData
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDetail);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 3612:
/***/ ((module) => {

module.exports = require("autosize");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 1817:
/***/ ((module) => {

module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 4108:
/***/ ((module) => {

module.exports = require("react-modern-drawer");

/***/ }),

/***/ 6419:
/***/ ((module) => {

module.exports = require("react-rating");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5265:
/***/ ((module) => {

module.exports = require("remixicon-react/AddLineIcon");

/***/ }),

/***/ 8710:
/***/ ((module) => {

module.exports = require("remixicon-react/Chat1FillIcon");

/***/ }),

/***/ 97:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxBlankLineIcon");

/***/ }),

/***/ 266:
/***/ ((module) => {

module.exports = require("remixicon-react/CheckboxFillIcon");

/***/ }),

/***/ 1060:
/***/ ((module) => {

module.exports = require("remixicon-react/CloseFillIcon");

/***/ }),

/***/ 4713:
/***/ ((module) => {

module.exports = require("remixicon-react/DeleteBin5LineIcon");

/***/ }),

/***/ 2595:
/***/ ((module) => {

module.exports = require("remixicon-react/Filter3LineIcon");

/***/ }),

/***/ 1257:
/***/ ((module) => {

module.exports = require("remixicon-react/Heart3FillIcon");

/***/ }),

/***/ 9348:
/***/ ((module) => {

module.exports = require("remixicon-react/Heart3LineIcon");

/***/ }),

/***/ 9112:
/***/ ((module) => {

module.exports = require("remixicon-react/Message2FillIcon");

/***/ }),

/***/ 6982:
/***/ ((module) => {

module.exports = require("remixicon-react/PauseFillIcon");

/***/ }),

/***/ 8244:
/***/ ((module) => {

module.exports = require("remixicon-react/StarFillIcon");

/***/ }),

/***/ 6487:
/***/ ((module) => {

module.exports = require("remixicon-react/StarSmileFillIcon");

/***/ }),

/***/ 3132:
/***/ ((module) => {

module.exports = require("remixicon-react/SubtractLineIcon");

/***/ }),

/***/ 2923:
/***/ ((module) => {

module.exports = require("remixicon-react/TimeLineIcon");

/***/ }),

/***/ 8280:
/***/ ((module) => {

module.exports = require("remixicon-react/UploadCloud2LineIcon");

/***/ }),

/***/ 2021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,1664,3181,3304,2622,4527,8942,3006,7671,1478,9919,1323,9253,9237,3788,9054,6634,7317], () => (__webpack_exec__(8278)));
module.exports = __webpack_exports__;

})();